/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */
#ifndef TREE_H
#define TREE_H

#include <stack>
#include "core.h"
#include "db.h"

using namespace std;

class EnvParameters : public ElementParameters
{
public:
        EnvParameters(void);

        int tex_ground;
        int mask_ground;
        int tex_sky;
        int mask_sky;

        double startx,endx,startz,endz;
        double partx,partz;

        //coded in db.cpp need for saving and opening
        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);
};

class TreeParameters : public ElementParameters
{
public:
        TreeParameters(void);

        int tex_leaf;
        int mask_leaf;
        int tex_trunk;
        int mask_trunk;

        //Branch parameters
        Vertex	startpos;
        Vertex	treestartpos;
        Vertex	startdirection;
        Vertex	treestartdirection;
        Vertex	directionVar;
        Vertex	directionVarLength;
        double  dirGenFactorHeiht;
        double  dirGenFactorWidth;
        double  dirGenFactorFlat;

        double	treestartradius;
        double	trunkstartradius;
        double  minimumradius;
        double	trunkthinfactor;
        double	trunkfullness; // pointnum:= trunkfullness * radius;

        double	segmentlength; // height of segment = rad*segmentlength
        double  rootminheight;
        double  rootmaxheight;
        double	minsegmentnum;
        double	maxsegmentnum;
        double	branchShorteningFactor;

        double  knob_plusrad;
        double  knob_centerheight;
        double  knob_length;

        double  globalMinBranchLength; // minsegmentnum:= globalMinBranchLength * radius

        double  hashFactor;
        double	branchFactor;
        double  dirChFactor;
        double  smallBranchEndFactor;

        double  endingBranchRadius;

        double  branchingMinRadFactor;
        double  branchingMaxRadFactor;
        double	maxLeafBranchRadius;
        double  leafFactor;

        int	ttex_fullupnum;

        //Global parameters
        int	maxdeep;

        int     leaftype;
        void *  leafObject; //leaftype 1 => (LeafParameters *) , leaftype 2 => (BigLeafParameters *)

        //=== output parameters
        int    deep;
        Vertex endpos;
        Vertex enddir;
        double endradius;

        //coded in db.cpp need for saving and opening
        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);

};

class PalmTreeParameters : public TreeParameters
{
public:
    PalmTreeParameters() : TreeParameters()   {  }


        //coded in db.cpp need for saving and opening
        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);

};

class GrassParameters : public ElementParameters
{
public:
        GrassParameters(void);

        int tex_grass;
        int mask_grass;

        double sx,sz,ex,ez,y;
        double density;

        int number,maxNumber,minNumber;
        Vertex startpos;
        Vertex dir;
        Vertex sidedir;
        double height;
        double minHeight;
        double maxHeight;
        double startthick;
        double endthick;
        double segmentlength;

        double plusflexfactor;

        Vertex	directionVar;
        Vertex	directionVarGenMin;
        Vertex	directionVarGenMax;

        void resetVarValues(void);
        void genVar(void);
        void genSideDir(void);
        void genHeight(void);
        void genNumber(void);

        void genAll()
        {
                resetVarValues();
                genVar();
                genSideDir();
                genHeight();
                genNumber();
        }

        //coded in db.cpp need for saving and opening
        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);

};

class LeafParameters
{
public:
        LeafParameters() {}

        Vertex leafstartpos;
        Vertex branchcenter;
        Vertex branchdir;

        double	leafRootLength;
        double  leafLength;
        double  leafWidth;

        double  globalflex;
};

#define TEXMODE_FULL	0
#define TEXMODE_PART	1
class BigLeafParameters : public ElementParameters
{
public:
        BigLeafParameters(void);

        int tex_leaf;
        int mask_leaf;

        int texmode;

        Vertex startpos;
        Vertex updir;
        int number,maxNumber,minNumber;
        Vertex leandir;
        double alpha;
        double beta;
        double startangle;
        double minStartangle;
        double maxStartangle;
        double endangle;
        double minEndangle;
        double maxEndangle;
        double length;
        double minLength;
        double maxLength;
        double width;
        double segmentlength;

        double plusflexfactor_all;
        double plusflexfactor_leafend;

        //------------------
        void resetVarValues();
        void genLeanDir();
        void genLength();
        void genNumber();
        void genAngles();

        void genAll()
        {
                resetVarValues();
                genAngles();
                genLeanDir();
                genLength();
                genNumber();
        }

        //coded in db.cpp need for saving and opening
        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);

};

class GLData
{
        public:

        TextureDatabase textures;


        int shader_wind;
        int shader_globalflex;
        int shader_localflex;
        int shader_shaking;
        int shader_shakedir;
        int shader_t1,shader_t2;
        int univ_1;
        int unif_1;
        QGLShaderProgram *sprogram;

        void setTextures(int colortex,int masktex);

};

class TreeGenerator
{
public:
        GLData *gldata;
        long triangles;
public:

        TreeGenerator(GLData *gldata_par)
        {
                gldata = gldata_par;
                branch_stack = NULL;
                leaf_stack = NULL;
                triangles = 0;
        }

        void buildSky(EnvParameters *ep);
        void buildGround(EnvParameters *ep);
        void buildTree(TreeParameters *p);
        void buildGrass(GrassParameters *gp);
        void generateGrass(GrassParameters *gp);
        void generateBigLeaf(BigLeafParameters *lp);


private:
        void buildBranch(TreeParameters *p);
        void makeHash(TreeParameters *p);
        void makeBranch(TreeParameters *p);
        void makeDirChange(TreeParameters *p);
        void makeLeaf(Vertex *leafstartpos,Vertex *branchcenter,Vertex *branchdir,double globalflex,TreeParameters *p);
        void generteLeaf(LeafParameters *lp);

        void generateSingleGrass(GrassParameters *gp);
        void generateSingleBigLeaf(BigLeafParameters *lp);

private:
        stack<TreeParameters *> *branch_stack;
        stack<LeafParameters *> *leaf_stack;
        BigLeafParameters *     delayed_draw;
};


#endif
//end.
