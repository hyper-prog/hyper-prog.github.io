/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2009 Peter Deak  (hyper80@gmail.com)

	xmlolib.h
*/
#ifndef GSAFE__XML_OUTPUT_LIB_HEADER_FILE_X_
#define GSAFE__XML_OUTPUT_LIB_HEADER_FILE_X_

#include <QtCore>
#include <QtGui>

#include <datalib.h>

class HXmloTable : public QDialog
{
    Q_OBJECT

    private:
        QLineEdit  *fnedit;
        HBase *data;

        void genXml(QTextStream *out); 

    public:
        HXmloTable(QWidget *parent,HBase *d);
        ~HXmloTable(void);

    public slots:
        int cf(void);
        int saveButton(void);
        int closeButton(void);
};


#endif
