Unpack this "gSAFE_tutorial" directory into same parent directory where the gSAFE directory paced.
(The gsafe files are searched in ../gSAFE dir)

 
 run "qmake" to generate makefiles.
 
 run "make" or "mingw32-make"
 
 
 
 