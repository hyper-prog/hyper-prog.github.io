/* 
	FAKE Console

   (C) 2005 Peter Deak  (hyper80@gmail.com)

	fcon.h
*/
#ifndef _FAKECONSOLE__HEADER_
#define _FAKECONSOLE__HEADER_

#include "base.h"

#include <QObject>

#ifdef APP_GUI_MODE

#include "dconsole.h"
#include <QtGui>

#else

class QString;	
void sdebug(QString s);

#endif
#endif
