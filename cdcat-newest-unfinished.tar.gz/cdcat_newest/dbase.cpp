/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyperr@freemail.hu)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 
 
  Core DataBase module (dbase.cpp)
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <QtCore>

//Only used in the default actionhandler, oherwise unnecessary
#include <QtGui>

#include <zlib.h>

#include "base.h"
#include "dbase.h"
#include "config.h"
#include "iocore.h"
#include "iecore.h"
#include "mp3tag.h"
#include "tparser.h"

/***************************************************************************/
  
QString DBActionHandler::textQuestion(QString msg)
{
	QMessageBox::question(NULL,"",msg);
	return QString("");
}

int DBActionHandler::chooseQuestion(QString msg,QString a1,QString a2,QString a3)
{
	return QMessageBox::question(NULL,tr("Question"),msg,a1,a2,a3);     
}

void DBActionHandler::warningMessage(QString msg)
{
	QMessageBox::warning(NULL,tr("Warning"),msg); 
}

int DBActionHandler::errorOccured(int code,QString msg,QString a1,QString a2,QString a3) 
{
	return QMessageBox::warning(NULL,tr("Error"),msg+QString("(%1)").arg(code),a1,a2,a3);     
}

/***************************************************************************
 *  DataBase Classes  
 ***************************************************************************/

DBNode::DBNode(void)
{
	type   = HC_UNINITIALIZED;
	next   = NULL;
	child  = NULL;
	parent = NULL;
	DBdata = NULL;
}

DBNode::DBNode(int t,DBNode *p)
{
	type   = t;
	next   = NULL;
	child  = NULL;
	parent = p;
	DBdata = NULL;
}

void DataBase::clear(void)
{
	DBNode *act = NULL;

	d_stack = new QStack<DBNode *>();
	d_stack->push(root);
	while(!d_stack->isEmpty())
	{
		act = d_stack->pop();

		if(act->next != NULL)
			d_stack->push(act->next);
		if(act->child != NULL)
			d_stack->push(act->child);

		act->next = NULL;
		act->child = NULL;
		delete act;
	}
	root = NULL;

	delete d_stack;
}

DBNode::~DBNode(void)
{
	if(DBdata  != NULL)
    {
		switch(type)
		{
            case HC_UNINITIALIZED: 
				break;
			case HC_CATALOG:
				delete qobject_cast<DBCatalog *>(DBdata); 
				break;
			case HC_MEDIA: 
				delete qobject_cast<DBMedia *>(DBdata); 
				break;    
			case HC_DIRECTORY: 
				delete qobject_cast<DBDirectory *>(DBdata); 
				break;
			case HC_FILE: 
				delete qobject_cast<DBFile *>(DBdata); 
				break;
			case HC_MP3TAG: 
				delete qobject_cast<DBMp3Tag *>(DBdata); 
				break;
			case HC_CONTENT: 
				delete qobject_cast<DBContent *>(DBdata); 
				break;
			case HC_CATLNK: 
				delete qobject_cast<DBCatLnk *>(DBdata); 
				break;
		}
	}

	DBdata  = NULL;
} 


QString DBNode::getFullPath(void)
{
	DBNode *up = this;
	QString a("");
	while(up != NULL)
	{
		a.prepend(up->getNameOf());    
		a.prepend("/");
		up = up->parent;
	}
	a.prepend("/");
	return a;
}
 
void DBNode::touchDB(void)
{
    if(type != HC_CATALOG)
		parent->touchDB();
	else
		(qobject_cast<DBCatalog *>(DBdata))->touch();    
}

QString DBNode::getNameOf(void)
{
	switch(type)
	{
		case HC_UNINITIALIZED: 
			return QString("");
		case HC_CATALOG      : 
			return (qobject_cast<DBCatalog *>(DBdata))->name; 
		case HC_MEDIA        : 
			return (qobject_cast<DBMedia *>(DBdata))->name; 
		case HC_DIRECTORY    : 
			return (qobject_cast<DBDirectory *>(DBdata))->name; 
		case HC_FILE         : 
			return (qobject_cast<DBFile *>(DBdata))->name; 
		case HC_MP3TAG       : 
			return QString(""); 
		case HC_CONTENT      : 
			return QString(""); 
		case HC_CATLNK       : 
			return (qobject_cast<DBCatLnk *>(DBdata))->name;  
	}
	return QString("");  
}

QDateTime DBNode::getLastModOf(void)
{
	switch(type)
	{
		case HC_UNINITIALIZED: 
			return QDateTime();
		case HC_CATALOG      : 
			return (qobject_cast<DBCatalog *>(DBdata))->modification; 
		case HC_MEDIA        : 
			return (qobject_cast<DBMedia *>(DBdata))->modification; 
		case HC_DIRECTORY    : 
			return (qobject_cast<DBDirectory *>(DBdata))->modification; 
		case HC_FILE         : 
			return (qobject_cast<DBFile *>(DBdata))->modification; 
		case HC_MP3TAG       : 
			return QDateTime(); 
		case HC_CONTENT      : 
			return QDateTime(); 
		case HC_CATLNK       : 
			return QDateTime();  
	}
	return QDateTime();  
}

QString DBNode::getCommentOf(void)
{
	switch(type)
	{
		case HC_UNINITIALIZED: 
			return QString("");
		case HC_CATALOG      : 
			return (qobject_cast<DBCatalog *>(DBdata))->comment; 
		case HC_MEDIA        : 
			return (qobject_cast<DBMedia *>(DBdata))->comment;
		case HC_DIRECTORY    : 
			return (qobject_cast<DBDirectory *>(DBdata))->comment; 
		case HC_FILE         : 
			return (qobject_cast<DBFile *>(DBdata))->comment;
		case HC_MP3TAG       : 
			return QString(""); 
		case HC_CONTENT      : 
			return QString(""); 
		case HC_CATLNK       : 
			return (qobject_cast<DBCatLnk *>(DBdata))->comment; 
	}
	return QString("");  
}

void DBNode::setCommentOf(QString c)
{
	switch(type)
	{
		case HC_UNINITIALIZED: 
			return;
		case HC_CATALOG      : 
			(qobject_cast<DBCatalog *>(DBdata))->comment = c;
			return;
		case HC_MEDIA        : 
			(qobject_cast<DBMedia *>(DBdata))->comment = c;
			return;
		case HC_DIRECTORY    : 
			(qobject_cast<DBDirectory *>(DBdata))->comment = c; 
			return;
		case HC_FILE         : 
			(qobject_cast<DBFile *>(DBdata))->comment = c;
			return;
		case HC_MP3TAG       : 
			return; 
		case HC_CONTENT      : 
			return; 
		case HC_CATLNK       : 
			(qobject_cast<DBCatLnk *>(DBdata))->comment = c; 
			return;
	}
}

DBMedia *DBNode::getMediaPtr(void)
{
	DBNode *stepup = this;
	
	while(stepup->type != HC_MEDIA)
	{
		if(stepup->parent == NULL)
			return NULL;
		stepup = stepup->parent;
	}
	return qobject_cast<DBMedia *>(stepup->DBdata);
}

QString DBNode::getOwnerOf(void)
{
	DBNode *stepup = this;
	
	do
	{
		if(stepup->type == HC_MEDIA && !((qobject_cast<DBMedia *>(stepup->DBdata))->owner.isEmpty()))
			return (qobject_cast<DBMedia *>(stepup->DBdata))->owner;

		if(stepup->type == HC_CATALOG)
			return (qobject_cast<DBCatalog *>(stepup->DBdata))->owner;

		stepup = stepup->parent;
	}
	while(stepup != NULL);
	//Newer reach this:
	return QString("Unknown");
}

int DBNode::v_idx(bool skip_files)
{
	int idx;
	DBNode *run;

	idx = 0;
	if(parent != NULL) //Only the root element hasn't parent,which is the catalog. But the catalog has no vertical neighbour.
		for(run=parent->child ; run != this ; run=run->next)
		{
			if(!skip_files || run->type != HC_FILE)
				++idx;
			Q_ASSERT(run != NULL);
		}

	return idx;
}

DBNode* DBNode::th_child(int idx,bool skip_files)
{
	DBNode *run;
	int i;

	i=0;
	for(run=child;run != NULL;run=run->next)
	{
		if(idx == i && (!skip_files || run->type != HC_FILE))
			return run;
		if(!skip_files || run->type != HC_FILE)
			++i;
	}
	return run;
}
/*************************************************************************/

DBCatalog::DBCatalog(QString n,QString o,QString c)
{
	name    = n;
	owner   = o;
	comment = c;
	writed  = 1;
	strcpy(filename,"");
	fileversion = "";
	modification = QDateTime::currentDateTime();
}

DBCatalog::DBCatalog(QString n,QString o,QString c,QDateTime mod)
{
	name    = n;
	owner   = o;
	comment = c;
	writed  = 1;
	strcpy(filename,"");
	fileversion = "";
	modification = mod;  
}

DBCatalog::DBCatalog(void)
{
	name    = "";
	owner   = "";
	comment = "";
	writed  = 1;
	strcpy(filename,"");
	modification = QDateTime::currentDateTime();
	fileversion  = "";
}
 
DBCatalog::~DBCatalog(void)
{

}

/*************************************************************************/
  
DBMedia::DBMedia(QString n,int nu,QString o,int t,QString c)
{ 
	name   = n;
	number = nu;
	owner  = o;
	type   = t; 
	modification = QDateTime::currentDateTime();
	comment = c;
	borrowing = "";
}

DBMedia::DBMedia(QString n,int nu,QString o,int t,QString c,QDateTime mod)
{ 
	name    = n;
	number  = nu;
	owner   = o;
	type    = t; 
	modification = mod;  
	comment = c;
	borrowing = "";
}
   
DBMedia::DBMedia(void)
{
	name      = "";
	number    = 0;
	owner     = "";
	type      = 0; 
	modification = QDateTime::currentDateTime();
	comment   = "";
	borrowing = "";
}

QString DBMedia::getMTypeName(void)
{
	switch(type)
	{
		case UNKNOWN : return QString("unknown");
		case CD      : return QString("CD");
		case DVD     : return QString("DVD");
		case HARDDISC: return QString("HardDisc");
		case FLOPPY  : return QString("floppy");
		case NETPLACE: return QString("NetworkPlace");
		case FLASHDRV: return QString("flashdrive");
		case OTHERD  : return QString("other");
		case AUDIOCD : return QString("AudioCD");
	}
	return QString("");  
}

int DBMedia::setMTypeName(QString n)
{
	if(n.isEmpty()) return -1;
	if(n.toLower() == "cd"	        ) { type = CD;        return 0; } 
	if(n.toLower() == "dvd"         ) { type = DVD;       return 0; }
	if(n.toLower() == "harddisc"    ) { type = HARDDISC;  return 0; } 
	if(n.toLower() == "floppy"      ) { type = FLOPPY;    return 0; }
	if(n.toLower() == "networkplace") { type = NETPLACE;  return 0; }  
	if(n.toLower() == "flashdrive"  ) { type = FLASHDRV;  return 0; }
	if(n.toLower() == "other"       ) { type = OTHERD;    return 0; } 
	if(n.toLower() == "audiocd"     ) { type = AUDIOCD;   return 0; }

    type = UNKNOWN;
	return -1;   
}
   
DBMedia::~DBMedia(void)
{

}

/*************************************************************************/

DBDirectory::DBDirectory(QString n,QDateTime mod,QString c)
{
	name         = n;
	modification = mod;
	comment      = c;
}

DBDirectory::DBDirectory(void)
{
	name    = "";
	modification = QDateTime();
	comment = "";
}

DBDirectory::~DBDirectory(void)
{

}

/*************************************************************************/
  
DBFile::DBFile(QString n,QDateTime mod,QString c,float s,int st)
{
	name     = n;
	modification = mod;
	comment  = c;
	size     = s;
	sizeType = st;
	prop     = NULL;
}

DBFile::DBFile(void)
{
	name     = "";
	modification = QDateTime();
	comment  = "";
	size     = 0;
	sizeType = 0;
	prop     = NULL;
}


int DBFile::setSize(float n,int t)
{
	size = n;
	sizeType = t;
	return 0;
}

float DBFile::getSize(void)
{
	return size;
}

int DBFile::getSizeType(void)
{
	return sizeType;
}

QString DBFile::getSizeTypeString(void)
{
	switch(sizeType)
	{
		case BYTE : return QString("byte");
		case KBYTE: return QString("Kb");
		case MBYTE: return QString("Mb");
		case GBYTE: return QString("Gb");
	}
	return QString(""); 
}


QString DBFile::getSizeString(void)
{
	char data[256];
		
	::sprintf(data , "%.3f", size);
	return QString("%1 %2")
			.arg(QString::fromAscii(data))
			.arg(getSizeTypeString());
}

int DBFile::setSize(QString sstr)
{
	char *data;
	char  cbuf[32];
	float fbuf;

	if(sstr.isEmpty())
		return -1;

	data = strdup((sstr.toLocal8Bit()).constData());

	if(sscanf(data,"%f %s",&fbuf,cbuf) != 2) 
		return -2;

	free(data);

	if(!strcmp(cbuf,"byte"))
	{
		size     = fbuf;
		sizeType = BYTE;
		return 0;
	}

	if(!strcmp(cbuf,"Kb"))
	{
		size     = fbuf;
		sizeType = KBYTE;
		return 0;
	}

	if(!strcmp(cbuf,"Mb"))
	{
		size     = fbuf;
		sizeType = MBYTE;
		return 0;
	}

	if(!strcmp(cbuf,"Gb"))
	{
		size     = fbuf;
		sizeType = GBYTE;
		return 0;
	}

	return -3;
}

long DBFile::getSizeBytes(void)
{
	switch(sizeType)
	{
		case BYTE: 
			return (long)(size);
		case KBYTE:
			return (long)(size*1024l);
		case MBYTE:
			return (long)(size*1024l*1024l);
		case GBYTE:
			return (long)(size*1024l*1024l*1024l);
	}
	return 0;
}


DBFile::~DBFile(void)
{
	if(prop != NULL)
		delete prop;
}

/*************************************************************************/

DBMp3Tag::DBMp3Tag(void)
{
	artist   = "";
	title    = "";
	comment  = "";
	album    = ""; 
	year     = "";
	track	 = 0;
}

DBMp3Tag::DBMp3Tag(QString art,QString tit,QString comm,QString alb,QString yea,int tra)
{
	artist   = art; 
	title    = tit;
	comment  = comm;
	album    = alb;
	year     = yea;
	track    = tra;
}

DBMp3Tag::~DBMp3Tag(void)
{

}

/*************************************************************************/

DBContent::DBContent(void)
{
	bytes      = NULL;
	storedSize = 0;
}
  
DBContent::DBContent(unsigned char *pbytes,unsigned long  pstoredSize)
{
	bytes      = pbytes;
	storedSize = pstoredSize;
}

DBContent::~DBContent(void)
{
	if(bytes != NULL) 
	{
		delete[] bytes;
		bytes = NULL;
	}
	storedSize = 0;
}

/*************************************************************************/

DBCatLnk::DBCatLnk(QString pname,const char *plocation,QString pcomment)
{
	name      = pname;
	location  = strdup(plocation);
	comment   = pcomment;
}
   
DBCatLnk::DBCatLnk(void)
{
	location = NULL;
}
   
DBCatLnk::~DBCatLnk(void)
{
	if(location != NULL) 
		free(location);   
}

/*************************************************************************/

DataBase::DataBase(CConfig *configobj)
{
	d_stack          = NULL;
	myhandler		 = nullhandler = new DBActionHandler();
	root             = new DBNode(HC_CATALOG,NULL);
	root->DBdata     = (QObject *) new DBCatalog();
	found_items     = NULL;
	myconfig        = configobj;
}

DataBase::~DataBase(void)
{
	clear();
	root = NULL;
	delete nullhandler;
}

/*************************************************************************/

QString DataBase::date_to_str(QDateTime dt)
{
    QString text;
	text.sprintf("%d-%d-%d %d:%d:%d",dt.date().year(),
										 dt.date().month(),
										 dt.date().day(),
                                         dt.time().hour(),
										 dt.time().minute(),
										 dt.time().second());
	return text;
}

/*************************************************************************/
 
void DataBase::setDBName (QString n)
{
	(qobject_cast<DBCatalog *>(root->DBdata))->name = n;       
}

void DataBase::setDBOwner(QString o)
{
	(qobject_cast<DBCatalog *>(root->DBdata))->owner = o;       
}
 
void DataBase::setComment(QString c) 
{
	(qobject_cast<DBCatalog *>(root->DBdata))->comment = c;       
}
   
QString& DataBase::getDBName(void)
{
	return (qobject_cast<DBCatalog *>(root->DBdata))->name;
}
 
QString& DataBase::getDBOwner(void)
{
	return (qobject_cast<DBCatalog *>(root->DBdata))->owner;
}
 
QString& DataBase::getComment(void)
{
	return (qobject_cast<DBCatalog *>(root->DBdata))->comment;
}
 
/***************************************************************************/

int DataBase::addMedia(QString what,QString name,int number,int type)
{
	return addMedia(what,name,number,type,"");
}

int DataBase::addMedia(QString what,QString name,int number,int type,QString owner)
{
	int returnv=0;
	//Unique check
	DBNode *run_node = root->child;
	 for(;run_node != NULL; run_node = run_node->next)
         {
	     if(run_node->DBdata != NULL)
	         if((qobject_cast<DBMedia *>(run_node->DBdata))->number == number ||
		    (qobject_cast<DBMedia *>(run_node->DBdata))->name   == name     )
	             {
		        myhandler->errorOccured(1015,"Media name or number is not unique!","Ok");
		        return 1;
		     }
	 }
	
	//End unique check

	updateCacheVars();
	
	DBNode *tt = root->child;
		
	emit working();     
	(qobject_cast<DBCatalog *>(root->DBdata))->touch();
	if(root->child == NULL) //It will be the first media in this database
		root->child = tt = new DBNode(HC_MEDIA,root);
	else //There is one more media in the database continue the chain
	{
        while(tt->next != NULL)
            tt = tt->next;
		tt->next = new DBNode(HC_MEDIA,root);
		tt = tt->next;
	}	 
     
	emit working();
        
	/* Fill the media Node (tt) */
	tt->DBdata = (QObject *) new DBMedia(
							name,
							number,
							owner.isEmpty() ? (qobject_cast<DBCatalog *>(root->DBdata))->owner : owner,
							type,
							QString(""));

	emit working();						

	returnv = scanFsToNode(what,tt);  

	return returnv; 
}

/***************************************************************************/ 

int DataBase::saveDB (void)
{
	int i;
	gzFile f=NULL;
	DBFileWriter *fw = NULL;
		
	emit working();
  
	if(strcmp((qobject_cast<DBCatalog *>(root->DBdata))->filename,"") == 0)
	{
		myhandler->seterror();
		return 1;
	}

	f = gzopen((qobject_cast<DBCatalog *>(root->DBdata))->filename,"wb");
	if(f == NULL)
	{
		myhandler->errorOccured(1001,tr("I can't rewrite the file: %1")
					.arg((qobject_cast<DBCatalog *>(root->DBdata))->filename),"Ok");
		myhandler->seterror();
		return 2;    
	}

	emit working();

	fw = new DBFileWriter(f,myconfig->getBoolConfigVal("niceformat")); 
	connect(fw,SIGNAL(working()),this,SIGNAL(working()),Qt::DirectConnection);
		
	emit working();

	i=fw->writeDown(root); 
	(qobject_cast<DBCatalog *>(root->DBdata))->writed = 1;
		
	emit working();
	disconnect(fw,SIGNAL(working()),this,SIGNAL(working()));

	gzclose(f);
	delete fw;
	return 0;
}
/***************************************************************************/
int DataBase::saveAsDB (char *filename)
{
	int i;
	gzFile f=NULL;
	DBFileWriter *fw = NULL;

	emit working();

	/*Check overwriting !!! */
	f = gzopen(filename,"wb");
	if(f==NULL)
	{
		myhandler->errorOccured(1002,QString("I can't create the file: %1").arg(filename),"Ok");
		myhandler->seterror();
		return 1;    
	}

	emit working();
	fw = new DBFileWriter(f,myconfig->getBoolConfigVal("niceformat"));

	connect(fw,SIGNAL(working()),this,SIGNAL(working()),Qt::DirectConnection);

	i=fw->writeDown(root); 

	(qobject_cast<DBCatalog *>(root->DBdata))->writed = 1;
	strcpy((qobject_cast<DBCatalog *>(root->DBdata))->filename,filename);

	emit working();
	disconnect(fw,SIGNAL(working()),this,SIGNAL(working()));

	gzclose(f);
	delete fw;
	return 0;
}

/***************************************************************************/ 

int DataBase::insertDB(char *filename)
{
    int i;
	gzFile f = NULL;
	DBFileReader *fr = NULL;

	if(root == NULL)
	{
		myhandler->errorOccured(1003,tr("No database opened!"),"Ok");
		myhandler->seterror();
		return 1;    
	}
	
	emit working();

	f = gzopen(filename,"rb");
	if(f == NULL)
	{
		myhandler->errorOccured(1004,tr("I can't open the file: %1").arg(filename),"Ok");
		myhandler->seterror();
		return 1;    
	}

	emit working();
	
	fr = new DBFileReader(f,1); 

	connect(fr,SIGNAL(working()),this,SIGNAL(working()),Qt::DirectConnection);
	i=fr->readTo(root); 
	disconnect(fr,SIGNAL(working()),this,SIGNAL(working()));
	if(i == 1) 
	{
		emit working();
		myhandler->errorOccured(1005,fr->errormsg,"Ok");
		myhandler->seterror();
		// cerr <<"error:"<< fr->errormsg <<endl;
		delete fr;
		gzclose(f);
		return 1;
	}
	(qobject_cast<DBCatalog *>(root->DBdata))->touch();
	emit working();
	gzclose(f);
	delete fr;
	return 0;
}

/***************************************************************************/

int DataBase::openDB(char *filename)
{

cerrd(QString("int DataBase::openDB ->")+filename);
	int i;
	gzFile f=NULL;
	DBFileReader *fr = NULL;

	emit working();
	f = gzopen(filename,"rb");
	if(f==NULL)
	{
		myhandler->errorOccured(1006,tr("I can't open the file: %1").arg(filename),"Ok");
		myhandler->seterror();
		return 1;
	}

	emit working();   
	fr = new DBFileReader(f); 

	connect(fr,SIGNAL(working()),this,SIGNAL(working()),Qt::DirectConnection);

	if(root != NULL)
	{
		clear();
		root = NULL; //Free previous database in memory
	}

	emit working();   
	root = new DBNode(HC_CATALOG,NULL); //Malloc root node.
	root->DBdata = (QObject *) new DBCatalog();
	

	i = fr->readTo(root); 
	disconnect(fr,SIGNAL(working()),this,SIGNAL(working()));  
	checkversion();

	if(i==1) 
	{
		myhandler->errorOccured(1007,fr->errormsg,"Ok");
		myhandler->seterror();

		clear();
		root = NULL;
		delete fr;
		gzclose(f);
		return 1;
	}

	
	(qobject_cast<DBCatalog *>(root->DBdata))->writed = 1;

	strcpy((qobject_cast<DBCatalog *>(root->DBdata))->filename,filename);

	emit working();

	gzclose(f);
	delete fr;
	return 0;
}

/***************************************************************************/ 
void DataBase::checkversion(void)
{
	QString fv;

    if(root == NULL)
		return;
	if(root->DBdata == NULL)
		return;
  
	fv = (qobject_cast<DBCatalog *>(root->DBdata))->fileversion;
  
	if(fv.isEmpty()) //vers < 1.2 
		return;

#ifdef KNOWN_VERSION01
	if(fv == KNOWN_VERSION01) return;
#endif
#ifdef KNOWN_VERSION02
	if(fv == KNOWN_VERSION02) return;
#endif
#ifdef KNOWN_VERSION03
	if(fv == KNOWN_VERSION03) return;
#endif
#ifdef KNOWN_VERSION04
	if(fv == KNOWN_VERSION04) return;
#endif
#ifdef KNOWN_VERSION05
	if(fv == KNOWN_VERSION05) return;
#endif
#ifdef KNOWN_VERSION06
	if(fv == KNOWN_VERSION06) return;
#endif
#ifdef KNOWN_VERSION07
	if(fv == KNOWN_VERSION07) return;
#endif
#ifdef KNOWN_VERSION08
	if(fv == KNOWN_VERSION08) return;
#endif
#ifdef KNOWN_VERSION09
	if(fv == KNOWN_VERSION09) return;
#endif
#ifdef KNOWN_VERSION10
	if(fv == KNOWN_VERSION10) return;
#endif

	myhandler->warningMessage(tr(
			"The database file has newer version than this version of cdcat can work with:\n"
			"I understand maximum %1 datafile version but readed %2\n\n"
			"Strongly recommended to upgrade your cdcat!!!\n"
			"Homepage: %3")
				.arg(DVERS)
				.arg(fv)
				.arg(HOMEPAGE));
}

/***************************************************************************/ 

void DBCatalog::touch(void)
{
	writed = 0;
	modification = QDateTime::currentDateTime();
}

/*************************************************************************/

void DataBase::updateCacheVars(void)
{
	cache_storeMp3tags       = myconfig->getBoolConfigVal  ("store_mp3tag"     );
	cache_v1_over_v2         = myconfig->getBoolConfigVal  ("mp3tag_v1_default");
	cache_storeMp3techinfo   = myconfig->getBoolConfigVal  ("store_mp3techinfo");
	cache_storeAvitechinfo   = myconfig->getBoolConfigVal  ("store_avitechinfo");
	cache_storeContent       = myconfig->getBoolConfigVal  ("store_content"    );
	cache_storedFiles        = myconfig->getStringConfigVal("stroe_contfiles");
	cache_storeLimit		 = myconfig->getIntConfigVal   ("store_contlimi");
}

/*************************************************************************/

int DataBase::scanFsToNode(QString what,DBNode *to)
{
	//cerr <<"Loading directory:"<< what <<endl;

	int ret;
	QString comm("");
	QDir *dir = NULL;
	
	QFileInfoList dirlist;
	ret=0;
	dir = new QDir(what);
	if(!dir->isReadable())
	{
    		int i;
		i = 1 + myhandler->chooseQuestion(tr("Cannot read directory: %1").arg(what),
						  tr("Ignore directory"),tr("Cancel scanning"));     
		return i;
	}

	dirlist = dir->entryInfoList(QDir::Dirs|QDir::Files|QDir::Hidden|QDir::System,QDir::Name);
	QListIterator<QFileInfo> it(dirlist);
	QFileInfo fileInfo;
	it.toFront();
	for(;it.hasNext();)
	{
		fileInfo = it.next();
		//Skip . and .. directory
		if(fileInfo.fileName() == "." || fileInfo.fileName() == "..")
			continue; 

		//I ignore the symlink direcoryes
		if(fileInfo.isDir() && fileInfo.isSymLink())
			continue; /* Or do something else, later...*/	   
 
		/* Make a new node */
		DBNode *tt = to->child;
		if(to->child == NULL)
			to->child = tt = new DBNode(fileInfo.isDir() ? HC_DIRECTORY : HC_FILE,to);
		else
		{
			while(tt->next != NULL) 
				tt = tt->next;
			tt->next = new DBNode(fileInfo.isDir() ? HC_DIRECTORY : HC_FILE,to);
			tt = tt->next;
		}	 
		
		/*Fill the data field */
		if(fileInfo.isFile()) /* FILE */
		{
			uint size = fileInfo.size();
			float s;
			int   st;
			if(size > (uint)(1024u*1024u*1024u*2u))
			{
				s = (double)size / (double)(1024u*1024u*1024u);
				st = GBYTE;
			}
			else if(size > (uint)(1024u*1024u)) 
			{
				s  = (double)size / (double)(1024u*1024u);
				st = MBYTE;
			}
			else if(size > (uint)1024u)
			{
				s  = (double)size / (double)1024u;
				st = KBYTE;
			}
			else
			{
				s  = size;
				st = BYTE;
			}
 
			emit working();  
		
			if(fileInfo.isSymLink())
			{
				comm = tr("Symbolic link#Points to:") + QString("") + fileInfo.readLink();
			} 
			tt->DBdata=(QObject *)new DBFile(fileInfo.fileName(),fileInfo.lastModified(),
										comm,s,st);
			
			scanFileProp(&fileInfo,(DBFile *)tt->DBdata); 
		}
		else /* DIRECTORY */ 
		{
			emit working();
			tt->DBdata=(QObject *)new DBDirectory(fileInfo.fileName(),
								fileInfo.lastModified(),
								NULL);
			/* Start recursion: */
			QString thr(what);		     
			thr = thr.append("/");
			thr = thr.append(fileInfo.fileName());
			
			if((ret=scanFsToNode(thr,tt)) == 2)
			 {
				return ret;
			 }	
		}
	}/*end of for,..next directory entry*/ 
	return ret; 
}

/***************************************************************************/

int DataBase::scanFileProp(QFileInfo *fi,DBFile *fc)
{
	QString ext;

	//cerr <<"Scan file prop:"<<fi->absoluteFilePath().toLocal8Bit().constData()<<endl;

	ext = fi->suffix();
	/***MP3 tag scanning */
	if(cache_storeMp3tags || cache_storeMp3techinfo)
		if(ext.toLower() ==  "mp3" ||
		   ext.toLower() ==  "mp2"   )
		{
			ReadMp3Tag *reader =
				new ReadMp3Tag((const char *)QFile::encodeName(fi->absoluteFilePath()),cache_v1_over_v2);
			if(cache_storeMp3tags && reader->readed() && reader->exist())
			{
				DBNode *tt = fc->prop;
				if(tt == NULL)
					fc->prop = tt = new DBNode(HC_MP3TAG,NULL);
				else
				{
					while(tt->next != NULL) 
						tt = tt->next;
					tt->next = new DBNode(HC_MP3TAG,fc->prop);
					tt = tt->next; //make the previusly alloced node to actual
				}
				
				/*Fill the fields:*/	
				tt->DBdata = (QObject *) new DBMp3Tag(
								QString::fromLocal8Bit(reader->artist() ),
								QString::fromLocal8Bit(reader->title()  ),
								QString::fromLocal8Bit(reader->comment()),
								QString::fromLocal8Bit(reader->album()  ),
								QString::fromLocal8Bit(reader->year()   ),
								reader->tnum()	);      
				  
			}//needstore & readed & exist if

			// Put some technical info to comment
			if(cache_storeMp3techinfo)
			{
                const char *info = reader->gettechinfo();
				if(info != NULL)
				{
                    if(!fc->comment.isEmpty())
						fc->comment.append("#"); 
					fc->comment.append(info);
				}
			}//storeinfo-if
    
			if(reader != NULL) 
			{
				delete reader; 
				reader = NULL; 
			}    	
		}//if mp3

	/* Avi techinfo reading */
	if(cache_storeAvitechinfo)
		if(ext.toLower() == "avi")
		{
			FILE* filePTR;
			filePTR=fopen((const char *)QFile::encodeName(fi->absoluteFilePath()),"r");
			if(filePTR!=NULL)
			{
				QString got = parseAviHeader(filePTR).replace(QRegExp("\n"),"#");
				fclose(filePTR);
   
				//store it as comment
				if(!got.isEmpty())
				{
					if(!fc->comment.isEmpty())
						fc->comment.append("#");
					fc->comment.append(got);
				}
			}
		}//if avi file & store avi techinfo																																		    

	/* File content scanning */
	if(cache_storeContent)
	{
		QRegExp regex("",Qt::CaseInsensitive,QRegExp::Wildcard);

		bool match = false;

		QStringList exts = cache_storedFiles.split(";",QString::SkipEmptyParts);
		QStringList::Iterator it = exts.begin();

		for (;it != exts.end(); ++it )  // stepping on the ; separated patterns
		{
			regex.setPattern(*it);
			if(regex.exactMatch(fi->fileName()))
			{
                match = true;
				break;
			}
		}

		if(match) // The file need to be read
		{
			FILE *f;
			bool success = true;
			unsigned long rsize=0,rrsize;
			unsigned char *rdata=0;
			DBNode *tt = fc->prop;
 
			if(cache_storeLimit > MAX_STORED_SIZE)
				cache_storeLimit = MAX_STORED_SIZE;
			//read the file
			if( (rsize = fi->size()) > cache_storeLimit )
				rsize = cache_storeLimit;
			f = fopen((const char *)QFile::encodeName(fi->absoluteFilePath()),"rb");
			if(f == NULL)
			{
				myhandler->errorOccured(1009,QString("I couldn't open the \"%1\" file. (content read 1)\n")
											.arg(fi->absoluteFilePath()),"Ok");
				myhandler->seterror();
				success = false;
			}
 
			rdata = new unsigned char[rsize + 1];	 
			fseek(f,0,SEEK_SET);
			rrsize = fread(rdata,sizeof(unsigned char),rsize,f);
			if(rsize != rrsize)
			{
				myhandler->errorOccured(1010,QString("I couldn't correctly read the content of file \"%1\" . (content read 2)\n"
									"size difference %2 != %3\n")
								.arg(fi->absoluteFilePath())
								.arg(rsize)
								.arg(rrsize)
								,"Ok");
				myhandler->seterror();
				success = false;
			}

			fclose(f);
			rdata[rsize] = '\0'; 
 
			//make the node in the db
			if(success)
			{
				if(tt == NULL) 
					fc->prop = tt = new DBNode(HC_CONTENT,NULL);
				else
				{
					while(tt->next != NULL) 
						tt = tt->next;
					tt->next = new DBNode(HC_CONTENT,fc->prop);
					tt = tt->next;
				}
				/*Fill the fields:*/	
				tt->DBdata = (QObject *) new DBContent(rdata,rsize);
			}	 
		}//end of if(match)								 
	}//end of if(storeContent)

	/***Other properties: */

	return 0;
}

/***************************************************************************/
 
void DataBase::addLnk(const char *loc)
{
    QString catname;
	gzFile f=NULL;
	DBFileReader *fr = NULL;

	DBNode *tmp=root->child,
		   *n = new DBNode(HC_CATLNK,root);

	/* Reading database name from the pointed file */ 
	f = gzopen(loc,"rb");
	if(f==NULL)
	{
		myhandler->errorOccured(1011,tr("I can't open the file: %1").arg(loc),"Ok");
		myhandler->seterror();
		return;
	}

	fr = new DBFileReader(f); 
	catname = fr->getCatName(); 
	if(catname.isEmpty()) 
	{
		myhandler->errorOccured(1012,tr("Error while parsing file: %1").arg(loc),"Ok");
		myhandler->seterror();
		delete fr;
		gzclose(f);
		return;
	}
	gzclose(f);
	delete fr;
	/* end reading from the file */

	catname.prepend("@");

	n->DBdata = new DBCatLnk(catname,loc,"");

	if(root->child == NULL)
	{
		root->child = n;
	}    
	else
	{
		while(tmp->next != NULL) 
			tmp = tmp->next;
		tmp->next = n;
	}    
	root->touchDB();
} 

/***************************************************************************/

void DataBase::deleteNode(DBNode *d)
{
    DBNode *p;    
	
	if(d == NULL) 
		return;

	p = d->parent;
	if(p->child == d)
	{
		p->child = p->child->next;
		d->next = NULL;
		delete d;
	}
	else
	{
		p = p->child; 
		while(p->next != d)
			p = p->next;
		p->next = p->next->next;
		d->next = NULL;
		delete d;  
	} 
	(qobject_cast<DBCatalog *>((getRootNode())->DBdata))->touch(); 
}

/***************************************************************************/ 

double DataBase::getSize(DBNode *s,int level)
{
	double v = 0.0l;
	if(s->type == HC_FILE)
	{
		switch((qobject_cast<DBFile *>(s->DBdata))->sizeType)
		{
			case 0: 
				v += ((qobject_cast<DBFile *>(s->DBdata))->size)/(1024*1024);      
				break; //byte
			case 1: 
				v += ((qobject_cast<DBFile *>(s->DBdata))->size)/1024;             
				break; //Kb	
			case 2: 
				v += ((qobject_cast<DBFile *>(s->DBdata))->size);                  
				break; //Mb	
			case 3: 
				v += ((qobject_cast<DBFile *>(s->DBdata))->size)*1024;             
				break; //Gb	
		}
	} 
	if(s->child != NULL) 
		v += getSize(s->child,level+1);      
	if(level != 0)
		if(s->next  != NULL) 
			v += getSize(s->next,level+1);      
	return v;
}

/***************************************************************************/

unsigned long DataBase::getCountDirs(DBNode *s,int level)
{
	unsigned long v=0;
	if(s->type == HC_DIRECTORY)
		v=1;
	if(s->child != NULL) 
		v += getCountDirs(s->child,level+1);      
	if(level != 0)
        if(s->next  != NULL) 
			v += getCountDirs(s->next,level+1);      
	return v;
}

/***************************************************************************/

unsigned long DataBase::getCountFiles(DBNode *s,int level)
{
	unsigned long v=0;
	if(s->type == HC_FILE)
		v=1;
	if(s->child != NULL) 
		v += getCountFiles(s->child,level+1);      
	if(level != 0)
		if(s->next  != NULL) 
			v += getCountFiles(s->next,level+1);      
	return v;
}

/***************************************************************************/

DBNode * DataBase::getMOnPos(int p)
{
	int i; 
	DBNode *step;

	step=root->child;
	for(i=0 ; i<p ; i++)
		step = step->next;
	return step;
} 

/***************************************************************************/

void DataBase::sortM(int mode)
{
	DBNode *step;
	QObject *data;

	int length; 
	int type;
	int i,j;

	if(root==NULL) 
		return;
	length = 0;
	step = root->child;
	while(step != NULL) 
	{ 
		length++;
		step = step->next;
	}

	for(i=0;i<length;i++)
		for(j=i;j<length;j++)
		{
			if(getMOnPos(i)->type == HC_CATLNK )
				continue;
			else if (getMOnPos(j)->type == HC_CATLNK)
				; /* nothing */ 	 
			else
			{ 
				switch(mode)
				{
					case NUMBER: 
						if((qobject_cast<DBMedia *>(getMOnPos(i)->DBdata))->number < 
						   (qobject_cast<DBMedia *>(getMOnPos(j)->DBdata))->number)
								continue;
						break;
   
					case NAME: 
						if(0 < QString::localeAwareCompare(
										(qobject_cast<DBMedia *>(getMOnPos(i)->DBdata))->name , 
										(qobject_cast<DBMedia *>(getMOnPos(j)->DBdata))->name))
								continue;
						break;
   
					case TYPE: 
						if((qobject_cast<DBMedia *>(getMOnPos(i)->DBdata))->type <= 
						   (qobject_cast<DBMedia *>(getMOnPos(j)->DBdata))->type )
								continue;
						break;

					case TIME:
						if((qobject_cast<DBMedia *>(getMOnPos(i)->DBdata))->modification <
						   (qobject_cast<DBMedia *>(getMOnPos(j)->DBdata))->modification   )
								continue;
						break;
				}
			}
			//swap
			step = getMOnPos(i)->child;
			data = getMOnPos(i)->DBdata ;
			type = getMOnPos(i)->type;

			getMOnPos(i)->child = getMOnPos(j)->child;
			getMOnPos(i)->DBdata  = getMOnPos(j)->DBdata;
			getMOnPos(i)->type  = getMOnPos(j)->type;

			getMOnPos(j)->child = step;
			getMOnPos(j)->DBdata  = data;
			getMOnPos(j)->type  = type;
		}
	root->touchDB();     
}

/*************************************************************************/

const char *shortMonthName0(int i)
{
    switch(i)
    {
        case 1:  return "Jan";
		case 2:  return "Feb";
		case 3:  return "Mar";
		case 4:  return "Apr";
		case 5:  return "May";
		case 6:  return "Jun";
		case 7:  return "Jul";
		case 8:  return "Aug";
		case 9:  return "Sep";
		case 10: return "Oct";
		case 11: return "Nov";
		case 12: return "Dec";
    }
	return "Err";
}

/*********************************************************************************
Search
*********************************************************************************/
/** Search in the database. 
	 pattern => the pattern of the search
	 start => "" -> ROOT ; Media name -> A selected media 
	 owner => "" -> ALL OWNER ; Name -> Search in a property of the specified owner 
	 wildcart => Search with wildcard instead of regex
	 casesens => Case sensitive or not.
	 search_in => Combination of "X" - Search for everything
				                 "m" - media name
								 "d" - directory name
								 "f" - file name
								 "c" - comment 
								 "o" - content
								 "a" - tag artist
								 "t" - tag title
								 "b" - tag album 
								 "n" - tag comment
							eg: "fat" - Serach in file name, artist and title */

QList<QPointer<DBNode> > *DataBase::find(QString pattern,QString start,QString owner,
							bool wildcard,bool casesens,QString search_in)
{
	QStack<DBNode *> *stack = NULL;
	DBNode *act = NULL,*sub = NULL;
	QRegExp *reg = NULL;
	bool f=false;

	bool rmedia = false,
		 rdir   = false,
		 rfile  = false,
		 rcomm  = false,
		 rcont  = false,
		 rtart  = false,
		 rttit  = false,
		 rtalb  = false,
		 rtcomm = false;
	
	if(getRootNode() == NULL)
		return NULL;

	emit working();
	if(search_in.contains(QChar('m'),Qt::CaseInsensitive))	rmedia = true;
	if(search_in.contains(QChar('d'),Qt::CaseInsensitive))	rdir   = true;
	if(search_in.contains(QChar('f'),Qt::CaseInsensitive))	rfile  = true;
	if(search_in.contains(QChar('c'),Qt::CaseInsensitive))	rcomm  = true;
	if(search_in.contains(QChar('o'),Qt::CaseInsensitive))	rcont  = true;
	if(search_in.contains(QChar('a'),Qt::CaseInsensitive))	rtart  = true;
	if(search_in.contains(QChar('t'),Qt::CaseInsensitive))	rttit  = true;
	if(search_in.contains(QChar('b'),Qt::CaseInsensitive))	rtalb  = true;
	if(search_in.contains(QChar('n'),Qt::CaseInsensitive))	rtcomm = true;

	if(search_in.contains(QChar('x'),Qt::CaseInsensitive))
	{
        rmedia = true;
		rdir   = true;
		rfile  = true;
		rcomm  = true;
		rcont  = true;
		rtart  = true;
		rttit  = true;
		rtalb  = true;
		rtcomm = true;
	}
	//------//
    found_items =new QList<QPointer<DBNode> >();
	reg = new QRegExp(pattern ,
				casesens ? Qt::CaseSensitive : Qt::CaseInsensitive ,
				wildcard ? QRegExp::Wildcard : QRegExp::RegExp    );

	stack = new QStack<DBNode *>();
	stack->push(getRootNode());
	while(!stack->isEmpty())
	{
		emit working();

		act = stack->pop();
		if(act->next != NULL)
			stack->push(act->next);
		if(act->child != NULL)
		{
			if(act->type != HC_MEDIA)
				stack->push(act->child);
			else
			{
				if( ( start.isEmpty() || start == (qobject_cast<DBMedia *>(act->DBdata))->name  ) &&
					( owner.isEmpty() || owner == (qobject_cast<DBMedia *>(act->DBdata))->owner )   )
					stack->push(act->child);
			}
		}

		//is it match? :
		switch(act->type)
		{
			case HC_MEDIA: 
					if(rmedia && reg->indexIn(act->getNameOf()) != -1 )
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}

					if(rcomm && !(    (qobject_cast<DBMedia *>(act->DBdata))->comment.isEmpty()) &&
						reg->indexIn( (qobject_cast<DBMedia *>(act->DBdata))->comment          ) != -1 )
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}
					
				break;
			case HC_DIRECTORY: 
					if(rdir && reg->indexIn(act->getNameOf()) != -1)
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}

					if(rcomm && !(    (qobject_cast<DBDirectory *>(act->DBdata))->comment.isEmpty()) &&
						reg->indexIn( (qobject_cast<DBDirectory *>(act->DBdata))->comment          ) != -1 )
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}
	
				break;
			case HC_FILE: 
					if(rfile && reg->indexIn(act->getNameOf()) != -1)
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}
					if(rcomm && !(    (qobject_cast<DBFile *>(act->DBdata))->comment.isEmpty()) &&
						reg->indexIn( (qobject_cast<DBFile *>(act->DBdata))->comment          ) != -1 )
					{
						found_items->append( QPointer<DBNode>(act) );
						continue;
					}
					
					//Scan file properties...
					f = false;
					sub = (qobject_cast<DBFile *>(act->DBdata))->prop;
					for(; sub != NULL && !f; sub = sub->next )
					{
						switch(sub->type)
						{
							case HC_MP3TAG:
								if(rtart && !(    (qobject_cast<DBMp3Tag *>(sub->DBdata))->artist.isEmpty()) &&
									reg->indexIn( (qobject_cast<DBMp3Tag *>(sub->DBdata))->artist          ) != -1 )
								{
									found_items->append( QPointer<DBNode>(act) );
									f = true;
									break;
								}
								if(rttit && !(    (qobject_cast<DBMp3Tag *>(sub->DBdata))->title.isEmpty()) &&
									reg->indexIn( (qobject_cast<DBMp3Tag *>(sub->DBdata))->title          ) != -1 )
								{
									found_items->append( QPointer<DBNode>(act) );
									f = true;
									break;
								}
								if(rtalb && !(    (qobject_cast<DBMp3Tag *>(sub->DBdata))->album.isEmpty()) &&
									reg->indexIn( (qobject_cast<DBMp3Tag *>(sub->DBdata))->album          ) != -1 )
								{
									found_items->append( QPointer<DBNode>(act) );
									f = true;
									break;
								}
								if(rtcomm && !(   (qobject_cast<DBMp3Tag *>(sub->DBdata))->comment.isEmpty()) &&
									reg->indexIn( (qobject_cast<DBMp3Tag *>(sub->DBdata))->comment          ) != -1 )
								{
									found_items->append( QPointer<DBNode>(act) );
									f = true;
									break;
								}

								break; //DBMp3Tag break
							case HC_CONTENT:
								if(rcont && strcmp((const char *)(qobject_cast<DBContent *>(sub->DBdata))->bytes,"") &&
									reg->indexIn( QString::fromLocal8Bit((const char *)(qobject_cast<DBContent *>(sub->DBdata))->bytes)) != -1 )
								{
									found_items->append( QPointer<DBNode>(act) );
									f = true;
									break;
								}
								break; //DBContent break.
							default: break;
						}//end of switch
					}//end of for
		


				break; //DBFile break.
			default: continue; //We not search in CATLNK,CATALOG
		}

	}

	delete stack;
	delete reg;
	return found_items;
}

/*********************************************************************************
Import Export functions:
*********************************************************************************/
DBNode * DataBase::getMediaNode(QString name)
{
	DBNode *t=NULL;

	t = root->child; //first media  
	while(t != NULL)
	{
		if(t->type != HC_MEDIA) 
			continue;
		if(t->getNameOf() == name)
			return t;
		t=t->next;
	}
	return NULL;    
}
 
DBNode * DataBase::putMediaNode(QString name,int number,QString owner,int type,QString comment)
{
	DBNode *t=NULL,*n=NULL;

	n = new DBNode(HC_MEDIA,root);
	n->DBdata = (QObject *) new DBMedia(name,number,owner,type,comment);

	if(root->child == NULL) 
		root->child = n;
	else
	{
		t=root->child; //first media  
		while(t->next != NULL) 
			t=t->next;
		t->next = n;
	} 
	return n;
}
 
DBNode * DataBase::getMediaNode(int id)
{
	DBNode *t=NULL;

	t = root->child; //first media  
	while(t != NULL)
	{
		if(((DBMedia *)(t->DBdata))->number == id)
			return t;
		t=t->next;
	}
	return NULL;    
}

DBNode * DataBase::getDirectoryNode(DBNode *meddir,QString name)
{
	DBNode *t=NULL;

	t=meddir->child;   
	while(t != NULL)
	{
		if(t->type != HC_DIRECTORY)
		{
			t=t->next;
			continue;
		} 
		if(t->getNameOf() == name)
			return t;
		t=t->next;
	}
	return NULL;    
}
 
DBNode * DataBase::putDirectoryNode(DBNode *meddir,QString name,QDateTime modification,QString comment)
{
	DBNode *t=NULL,*n=NULL;

	n = new DBNode(HC_DIRECTORY,meddir);
	n->DBdata = (QObject *) new DBDirectory(name,modification,comment);
 
	if(meddir->child == NULL) 
		meddir->child = n;
	else
	{
		t=meddir->child;   
		while(t->next != NULL)
			t=t->next;
		t->next = n;
	} 
	return n;
}

DBNode * DataBase::getFileNode(DBNode *directory,QString name)
{
	DBNode *t=NULL;

	t = directory->child;   
	while(t != NULL)
	{
		if(t->type != HC_FILE) 
		{
			t = t->next;
			continue;
		} 
		if(t->getNameOf() == name)
			return t;
		t = t->next;
	}
	return NULL;    
}
 
DBNode * DataBase::putFileNode(DBNode *directory,QString name,QDateTime modification,QString comment,int sizeType,float size)
{
	DBNode *t=NULL,*n=NULL;

	n = new DBNode(HC_FILE,directory);
	n->DBdata = (QObject *)new DBFile(name,modification,comment,size,sizeType);
 
	if(directory->child == NULL) 
		directory->child = n;
	else
	{
		t=directory->child;   
		while(t->next != NULL)
			t=t->next;
		t->next = n;
	} 
	return n;
}
 
DBNode * DataBase::putTagInfo(DBNode *file,QString artist,QString title,QString comment,QString album,QString year,int track)
{
	DBNode *t=NULL,*n=NULL;

	n = new DBNode(HC_MP3TAG,NULL);
	n->DBdata = (QObject *)new DBMp3Tag(artist,title,comment,album,year,track);
 
	if((qobject_cast<DBFile *>(file->DBdata))->prop == NULL) 
		(qobject_cast<DBFile *>(file->DBdata))->prop = n;
	else
	{
		t=(qobject_cast<DBFile *>(file->DBdata))->prop;   
		while(t->next != NULL)
			t=t->next;
		t->next = n;
	} 
	return n; 
}
/*************************************************************************************
* Custom Import Export
*************************************************************************************/
int DataBase::exportHtml(QString file,bool monly,QString medialist,QString show)
{
	int i;
	DBExportEngine *ee = NULL;

	ee = new DBExportEngine(this);
	i = ee->writeDB(file,EXP_HTML,monly,medialist,show);
	delete ee;

	return i;
}

int DataBase::exportTxt(QString file,bool monly,QString medialist,QString show)
{
	int i;
	DBExportEngine *ee = NULL;

	ee = new DBExportEngine(this);
	i = ee->writeDB(file,EXP_TXT,monly,medialist,show);
	delete ee;

	return i;
}

int DataBase::exportCsv(QString file,bool monly,QString medialist,QString show)
{
	int i;
	DBExportEngine *ee = NULL;

	ee = new DBExportEngine(this);
	i = ee->writeDB(file,EXP_CSV,monly,medialist,show);
	delete ee;

	return i;
}
//end code.
