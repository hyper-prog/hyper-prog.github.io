/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Info viewer of catalog items (hcinfo.cpp)
****************************************************************************/
#include "base.h"

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

#include "hcinfo.h"
#include "main_run.h"
#include "config.h"

HCatInfoDWidget::HCatInfoDWidget(QWidget * parent)
: QDockWidget(tr("Item info"),parent,0)
{
	setObjectName("HCatInfoDWidget");
	dwf=new InfoFrame(this);
	dwf->setObjectName("HCatInfoDWidget-f");
	QVBoxLayout *vlay = new QVBoxLayout(dwf);
	vlay->setObjectName("HCatInfoDWidget-f-Lay");

	setWidget(dwf);
}

int HCatInfoDWidget::ceToolPress(void)
{
	emit ceEventReq();
	return 0;
}

int HCatInfoDWidget::coToolPress(void)
{
	emit coEventReq();
	return 0;
}

int HCatInfoDWidget::showNode(DBNode *n,bool pnode)
{
	dwf->showNode(n,pnode);
	return 0;
}

HCatInfoDWidget::~HCatInfoDWidget(void)
{

}

/////////////////////////////////////////////////////////////////

InfoFrame::InfoFrame(QWidget *parent)
: QFrame(parent)
{
	a = NULL;
	type = false;
	updateColors();

	setMinimumWidth(150);
	setMinimumHeight(200);

	mx = 0;
	my = 0;

	c1t = new QToolButton(this);
	c1t->setIcon(QIcon("images/commentedit.png"));
	c2t = new QToolButton(this);
	c2t->setIcon(QIcon("iamges/sowcontent.png"));

	c1t->setGeometry(15,height()-35,22,22);
	c2t->setGeometry(40,height()-35,22,22);

	c1t->setToolTip(tr( "Edit and refresh the actual comment page." ));
	c2t->setToolTip(tr( "Shows the content of the file." ));

	connect(c1t,SIGNAL(clicked()),parent,SLOT(ceToolPress()));
	connect(c2t,SIGNAL(clicked()),parent,SLOT(coToolPress()));
}

void InfoFrame::resizeEvent(QResizeEvent *re)
{
	c1t->setGeometry(15,((re->size()).height())-35,22,22);
	c2t->setGeometry(40,((re->size()).height())-35,22,22);
}

InfoFrame::~InfoFrame(void)
{
}

int InfoFrame::updateColors(void)
{
	bgcolor   = QColor(GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_r"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_g"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_b"));

	linecolor = QColor(GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_linecolor_r"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_linecolor_g"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_linecolor_b"));

	ctxtcolor = QColor(GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_ctxtcolor_r"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_ctxtcolor_g"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_ctxtcolor_b"));

	vtxtcolor = QColor(GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_vtxtcolor_r"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_vtxtcolor_g"),
					   GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_vtxtcolor_b"));
	return 0;
}


void  InfoFrame::enterEvent(QEvent *e)
{
	//QApplication::setOverrideCursor(Qt::PointingHandCursor);
}
 
void  InfoFrame::leaveEvent(QEvent *e)
{
	//QApplication::setOverrideCursor(Qt::ArrowCursor);
}

void InfoFrame::mouseMoveEvent(QMouseEvent *me)
{
	mx -= ox - me->x();
	my -= oy - me->y();
	ox = me->x();
	oy = me->y(); 
	repaint();
}

void InfoFrame::mousePressEvent(QMouseEvent *me)
{
	ox = me->x();
	oy = me->y();
	mx = 0;
	my = 0;
	repaint();
}

void InfoFrame::mouseReleaseEvent(QMouseEvent *me)
{
	ox = mx = 0;
	oy = my = 0;
	repaint();
}


int InfoFrame::showNode(DBNode *n,bool pnode)
{
	type = pnode;
	a = n;
	update();
	return 0;
}

void InfoFrame::paintEvent(QPaintEvent *e)
{
	QRectF rect;
	int y;
	QString str;
	QFontMetrics fm = QApplication::fontMetrics();
	int textH = fm.height();
	int ispace=1;
	bool hasContent;

	hasContent = false;
	y = 25;

	QPainter p(this);

	p.setPen(linecolor);
	p.fillRect(10,10,width()-20,height()-20,bgcolor);
	p.drawRect(10,10,width()-20,height()-20);
	p.setClipRect(10,10,width()-20,height()-20);

	if(a == NULL)
	{
		c1t->setEnabled(false);
		c1t->setHidden(true);
        p.setPen(ctxtcolor);
        p.drawText(mx+15,my+25,tr("There is no selected element.")); 
	}
	else
	{
		c1t->setEnabled(true);
		c1t->setHidden(false);
        if(type == true)
		{
			p.setPen(ctxtcolor);
			p.drawText(mx+15,my+y,tr("Upper container! (..)")); 
			y+=textH+10;
		} 
		//name
		p.setPen(ctxtcolor);
		p.drawText(mx+15,my+y,tr("Name:"));
		p.setPen(vtxtcolor);
		rect = p.boundingRect(mx+20,my+y,width()-(mx+30),textH,Qt::AlignBottom|Qt::TextWordWrap,a->getNameOf());
        p.drawText(mx+20,my+y,width()-(mx+30),rect.height(),Qt::TextWordWrap,a->getNameOf()); 
		y+=rect.height()+textH-2;	

       //type
        p.setPen(ctxtcolor);	
        p.drawText(mx+15,my+y,tr("Type:")); 
        switch(a->type)
		{
			case HC_CATALOG  : str = tr(" CdCat Catalog root"); break;
			case HC_CATLNK   : str = tr(" Link to a CdCat catalog"); break;	  
			case HC_DIRECTORY: str = tr(" Directory"); break;	  
			case HC_FILE     : str = tr(" File"); break;	  
			case HC_MEDIA    : str = QString(" %1 (%2)")
										.arg(tr("Media"))
										.arg((qobject_cast<DBMedia *>(a->DBdata))->getMTypeName()); 
                             break;	  	  
		}
		p.setPen(vtxtcolor); 
		p.drawText(mx+20+fm.width(tr("Type:")),my+y,str); y+=textH+ispace;   

		// -->HC_FILE
		if(a->type == HC_FILE)
		{
			p.setPen(ctxtcolor);
			p.drawText(mx+15,my+y,tr("Size:"));   
			p.setPen(vtxtcolor);
			p.drawText(mx+20+fm.width(tr("Size:")),my+y,(qobject_cast<DBFile *>(a->DBdata))->getSizeString() );  y+=textH+ispace;       
		}
		
		// -->HC_CATLNK
		if(a->type == HC_CATLNK)
		{
			p.setPen(ctxtcolor);
			p.drawText(mx+15,my+y,tr("Location:")); y+=textH;        	  
			p.setPen(vtxtcolor);	  
			p.drawText(mx+15,my+y,QString(" %1").arg((qobject_cast<DBCatLnk *>(a->DBdata))->location));  y+=textH+ispace;       
		}
		
		if(a->getLastModOf().isValid())
        {
			p.setPen(ctxtcolor);
			p.drawText(mx+15,my+y,tr("Last modification:"));  y+=textH;              
			p.setPen(vtxtcolor);
			p.drawText(mx+15,my+y, a->getLastModOf().toString(Qt::LocalDate)); y+=textH+ispace;               	
		}
		
		//owner	
		p.setPen(ctxtcolor);
		p.drawText(mx+15,my+y,tr("Owner:"));       
		p.setPen(vtxtcolor);
		p.drawText(mx+20+fm.width(tr("Owner:")),my+y,a->getOwnerOf()); y+=textH+ispace;
	 
        //media	
		DBMedia *m_of_node;
		m_of_node = a->getMediaPtr();
		if(m_of_node != NULL)
		{
			p.setPen(ctxtcolor);
			p.drawText(mx+15,my+y,tr("Media (number/name):"));  y+=textH;       
			p.setPen(vtxtcolor);
			p.drawText(mx+15,my+y,QString(" %1 / %2")
							.arg(m_of_node->number)
							.arg(m_of_node->name));
				y+=textH+ispace;

			if(!m_of_node->borrowing.isEmpty())
			{
				p.setPen(QPen(QColor(255,0,0),2));
				p.drawLine(width()-24,14,width()-14,24);
				p.drawLine(width()-14,14,width()-24,24);
			}
		}

		y+=2;
		
        // -->HC_FILE
		if(a->type == HC_FILE && (qobject_cast<DBFile *>(a->DBdata))->prop != NULL) //The file has other info
		{
			DBNode *p_node;

			p_node=(qobject_cast<DBFile *>(a->DBdata))->prop;
			while(p_node != NULL)
			{
                if(p_node->type == HC_MP3TAG)
				{
					p.setPen(linecolor);
					p.drawLine(12,my+y-textH,width()-12,my+y-textH);	  	   
					p.setPen(ctxtcolor);
					p.drawText(mx+12,my+y,tr("Mp3-Tag:"));                         y+=textH;
					p.drawText(mx+12,my+y,tr("(Art/Tit/Alb/Ye/Tr/Comm)"));         y+=textH+2;              
					p.setPen(vtxtcolor);
					p.drawText(mx+20,my+y,(qobject_cast<DBMp3Tag *>(p_node->DBdata))->artist);  y+=textH;              
					p.drawText(mx+20,my+y,(qobject_cast<DBMp3Tag *>(p_node->DBdata))->title);   y+=textH;              	    
					p.drawText(mx+20,my+y,(qobject_cast<DBMp3Tag *>(p_node->DBdata))->album);   y+=textH;              	    
					p.drawText(mx+20,my+y,QString("%1 (%2)")
											.arg((qobject_cast<DBMp3Tag *>(p_node->DBdata))->year)
											.arg((qobject_cast<DBMp3Tag *>(p_node->DBdata))->track));   y+=textH;              	    
					p.drawText(mx+20,my+y,(qobject_cast<DBMp3Tag *>(p_node->DBdata))->comment); y+=textH+2;              	    	    
				}
				if(p_node->type == HC_CONTENT)
				{
					hasContent = true;
				}
				p_node = p_node->next; 
			}
		}
		p.setPen(linecolor);
		p.drawLine(12,my+y-textH,width()-12,my+y-textH);	
		p.setPen(ctxtcolor);
		y++;
		
		p.drawText(mx+15,my+y,tr("Comment:"));  
		p.setPen(vtxtcolor);  
		p.drawText(mx+20,my+y,width()-(mx+30),height()-(my+y),
				Qt::TextWordWrap | Qt::AlignLeft ,
				QString(a->getCommentOf()).replace("#","\n") );
		y+=textH;
	}

	if(hasContent)	
	{
		c2t->setEnabled(true);
		c2t->setHidden(false);
	}
	else
	{
		c2t->setEnabled(false);
		c2t->setHidden(true);
	}
}

#endif
//end code.
