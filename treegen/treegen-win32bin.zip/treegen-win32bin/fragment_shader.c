/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */
  
/* FRAGMENT SHADER CODE */
uniform float uf1;													

varying vec4 diffuse,ambientGlobal, ambient;
varying vec3 normal,lightDir,halfVector;
varying float dist;

uniform sampler2D Texture0;
uniform sampler2D Texture1;

void main()
{
	vec3 n,halfV,viewV,ldir;
	float NdotL,NdotHV;
	vec4 color = ambientGlobal;
	vec4 tcolor;
	vec4 tmask;
	float att;
	
	/* a fragment shader can't write a varying variable, hence we need
	a new variable to store the normalized interpolated normal */
	n = normalize(normal);
	
	/* compute the dot product between normal and normalized lightdir */
	NdotL = max(dot(n,normalize(lightDir)),0.0);

	if (NdotL > 0.0) {
	
		att = 1.0 / (gl_LightSource[0].constantAttenuation +
				gl_LightSource[0].linearAttenuation * dist +
				gl_LightSource[0].quadraticAttenuation * dist * dist);
		color += att * (diffuse * NdotL + ambient);
	
		
		halfV = normalize(halfVector);
		NdotHV = max(dot(n,halfV),0.0);
		color += att * gl_FrontMaterial.specular * gl_LightSource[0].specular * 
						pow(NdotHV,gl_FrontMaterial.shininess);
	}

	tcolor = texture2D(Texture0, gl_TexCoord[0].xy);
	tmask = texture2D(Texture1, gl_TexCoord[0].xy);

	if( tmask.r==0.0 && tmask.g==0.0 && tmask.b==0.0 )
	{
		discard;
	}

	
	gl_FragColor = color * tcolor;
}



												
/*END*/
