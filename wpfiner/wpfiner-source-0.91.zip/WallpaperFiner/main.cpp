/*
  Wallpaper Finer

  Webpage: http://hyperprog.com
  (C) 2012 Peter Deak  (hyper80@gmail.com)

  License: GPL v2.
*/

#include <QtGui/QApplication>
#include "wpfiner.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    WpFinerMainWidget w;
    w.show();
    
    return a.exec();
}
