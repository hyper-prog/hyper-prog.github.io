/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  List browser of catalog structure (hclist.cpp)
****************************************************************************/
#include "base.h"

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

#include "dbase.h"
#include "main_run.h"
#include "hclist.h"
#include "guicore.h"
#include "icons.h"
#include "config.h"

#include "fcon.h"

int  DBListItem::sortc = 0;
bool DBListItem::order = true;
bool DBListItem::clplaceu = true; //t:up f:down

DBListItem::DBListItem(DBNode *connection,int _ntype)
{
	ntype = _ntype;
	dbnode = connection;
	sortmod = 0;

	if(ntype == PD_NODE)
	{
		c[0] = QString("..");
		c[1] = QString("");
		c[2] = GuiApp::guiAppPo->guicore->getTypeStrOFNode(dbnode);
		sortmod = 1;
	}
	else
	{
		c[0] = dbnode->getNameOf();
		c[2] = GuiApp::guiAppPo->guicore->getTypeStrOFNode(dbnode);

		if(dbnode->type == HC_MEDIA)
		{
			c[1] =  QString("%1").arg((qobject_cast<DBMedia *>(dbnode->DBdata))->number);
			sortmod = 4;
		}
		if(dbnode->type == HC_DIRECTORY)
		{
			c[1] = QString("");
			sortmod = 5;
			c[2].append("("+dbnode->getLastModOf().toString()+")");
		}
		if(dbnode->type == HC_FILE)
		{
			c[1] = (qobject_cast<DBFile *>(dbnode->DBdata))->getSizeString();
			sortmod = 6;
			c[2].append("("+dbnode->getLastModOf().toString()+")");

		}
		if(dbnode->type == HC_CATLNK)
		{
			c[1] = QString("");
			if(DBListItem::clplaceu) sortmod = 3;
			else					 sortmod = 7;
		}

	}
}

DBListItem::~DBListItem(void)
{

}

/***************************************************/

DBNodeListModel::DBNodeListModel(DBNode *start,MyListView *parent)
: QAbstractItemModel(parent)
{
	sumRows = 0;
	lst = new QList<DBListItem *>();
	n_root = start;
	treeview = parent;
}

DBNodeListModel::~DBNodeListModel(void)
{
    while(!lst->isEmpty())
        delete lst->takeFirst();
	delete lst;
}

void DBNodeListModel::clear(void)
{
	bool sendsignal;
	int old_srow;

	sendsignal = false;
	
	cerrd("DBNodeListModel::clear");
	
	if(sumRows !=  0)
	{
		emit rowsAboutToBeRemoved(QModelIndex(),0,old_srow = sumRows);
		beginRemoveRows(QModelIndex(),0,sumRows);
		sendsignal = true;
	}

	sumRows = 0;
	lst->clear();
	n_parent = NULL;
	n_current = NULL;

	if(sendsignal)
	{
		emit rowsRemoved(QModelIndex(),0,old_srow);
		endRemoveRows();
	}
cerrd("DBNodeListModel::clear END");
}

void DBNodeListModel::addItem(DBListItem *item)
{

cerrd("DBNodeListModel::addItem");
beginInsertRows(QModelIndex(),sumRows,sumRows+1);

	lst->push_back(item);
	++sumRows;

	endInsertRows();
cerrd("DBNodeListModel::addItem END");
}


void DBNodeListModel::update(void)
{
	cerrd("DBNodeListModel::update");
	if(lst->isEmpty())
		return;

	emit dataChanged(createIndex(0,0,lst->first()),createIndex( lst->size() ,2,lst->last()));
	cerrd("DBNodeListModel::update END");
}



int DBNodeListModel::rowCount(const QModelIndex& parent) const
{
//	cerrd("DBNodeListModel::rowCount - " << sumRows );
	return sumRows;
	
}

QModelIndex DBNodeListModel::index(int row,int column,const QModelIndex& parent) const
{
//	cerrd("DBNodeListModel::index");
	DBListItem *item;

	if ( !parent.isValid() && 
		  row < sumRows &&
		  (item = lst->at(row)) != NULL )
	{
//		cerrd( " ("<<row<<","<<column<<")ok:"<<item->dbnode->getFullPath().toLocal8Bit().constData());
    	    return createIndex(row,column,item);
	}
        else
	{
//		cerrd(" null");
	    return QModelIndex();
	}

}

QModelIndex DBNodeListModel::parent(const QModelIndex& index) const
{
    return QModelIndex();
}

int DBNodeListModel::columnCount(const QModelIndex& parent) const
{
	return 3; //Name | Size | Type
}

bool DBNodeListModel::hasChildren(const QModelIndex& parent) const
{
	cerrd("DBNodeListModel::hasChildren");
	
	if(n_parent == NULL)
		return false;

	if(parent.isValid())
		return false;
	else
	    return true;
}

QVariant DBNodeListModel::data(const QModelIndex& index,int role) const
{


//	cerrd("DBNodeListModel::data");
	DBListItem *n;

	n = static_cast<DBListItem *>(index.internalPointer());

//	sdebug("DBNodeListModel::data --"+n->dbnode->getNameOf());

    if(role == Qt::DisplayRole)
	{
	    if(index.column() == 0)
			return n->c[0];
		if(index.column() == 1)
			return n->c[1];
		if(index.column() == 2)
			return n->c[2];
	}

	if(role == Qt::DecorationRole && index.column() == 0)
	{
		if(n->ntype == PD_NODE)
			return QIcon("images/type_back.png");
		return GuiApp::guiAppPo->guicore->getIconOfNode(n->dbnode);
	}
	//cerrd("DBNodeListModel::data - rossz vege");	
	return QVariant();
}

Qt::ItemFlags DBNodeListModel::flags(const QModelIndex& index) const
{
	return Qt::ItemIsEnabled | Qt::ItemIsSelectable;

}

QVariant DBNodeListModel::headerData(int section,Qt::Orientation orientation,int role) const
{
	if(section == 0)
		return QObject::tr("Name");
	if(section == 1)
		return QObject::tr("Size");
	if(section == 2)
		return QObject::tr("Type");

	return QString("");
}

QModelIndex DBNodeListModel::getIndexOfNode(DBNode *n)
{
	int idx;
	QList<DBListItem *>::iterator it;

	idx = 0;
	for(it = lst->begin() ; it != lst->end() ; ++it )
	{
		if((*it)->dbnode == n)
			return createIndex(idx,0,(*it));
		++idx;
	}
	return QModelIndex();
}

bool compareDBListItem(const DBListItemPtr &s1,const DBListItemPtr &s2) //The Key of sorting
{
	if(s1->sortmod < s2->sortmod)
		return true;
	if(s1->sortmod > s2->sortmod)
		return false;

	if(DBListItem::sortc == 2 && (s1->dbnode->type == HC_FILE || s1->dbnode->type == HC_DIRECTORY))
	{
		if(s1->dbnode->getLastModOf() < s2->dbnode->getLastModOf())
				return DBListItem::order ? true : false;

		if(s1->dbnode->getLastModOf() > s2->dbnode->getLastModOf())
				return DBListItem::order ? false : true;
	}

	if(DBListItem::sortc == 1 && s1->dbnode->type == HC_MEDIA)
	{

		if((qobject_cast<DBMedia *>(s1->dbnode->DBdata))->number < 
		   (qobject_cast<DBMedia *>(s2->dbnode->DBdata))->number )
				return DBListItem::order ? true : false;

		if((qobject_cast<DBMedia *>(s1->dbnode->DBdata))->number > 
		   (qobject_cast<DBMedia *>(s2->dbnode->DBdata))->number)
				return DBListItem::order ? false : true;
	}


	if(DBListItem::sortc == 1 && s1->dbnode->type == HC_FILE)
	{

		if((qobject_cast<DBFile *>(s1->dbnode->DBdata))->getSizeBytes() < 
		   (qobject_cast<DBFile *>(s2->dbnode->DBdata))->getSizeBytes())
				return DBListItem::order ? true : false;

		if((qobject_cast<DBFile *>(s1->dbnode->DBdata))->getSizeBytes() > 
		   (qobject_cast<DBFile *>(s2->dbnode->DBdata))->getSizeBytes())
				return DBListItem::order ? false : true;
	}

	if(0 > QString::localeAwareCompare(s1->c[0],s2->c[0]))
			return DBListItem::order ? true : false;
	if(0 > QString::localeAwareCompare(s2->c[0],s1->c[0]))
			return DBListItem::order ? false : true;

	return false; //Totally euqal
}

void DBNodeListModel::sort(int column,Qt::SortOrder order)
{
	bool found;
	int i;
        //DBNode *c_node;
	QList<DBListItem *>::iterator it;

cerrd("DBNodeListModel::sort");

	QList<DBListItem *>::iterator begin_sort,end_sort;

	if(sumRows == 0)
		return;

	DBListItem::sortc = column;
	DBListItem::order = ( order == Qt::AscendingOrder ? false : true );
	begin_sort = lst->begin();
	end_sort = lst->end(); 
	if((*begin_sort)->ntype == PD_NODE)
		++begin_sort; 
	qSort(begin_sort,end_sort,compareDBListItem);

	treeview->reset();
cerrd("sort afterwork... Mark the old current item to current...");

	//Mark the old current item to current...
	found = true;
	i = 0;
	it = lst->begin();
	while((*it)->dbnode != n_current)
	{
		if(it == lst->end())
		{
			found = false;
			break;
		}
		++it;
		++i;
	} 
	if(found)
	{
		treeview->setCurrentIndex(createIndex(i,0,(*it)));
		treeview->emitItemCh();
	}

cerrd("DBNodeListModel::sort END");

}

/**********************************************************/

MyListView::MyListView(DBNode *start,QWidget *parent)
:QTreeView(parent)
{
	setObjectName("DBListView");
	model = new DBNodeListModel(start,this);

	DBListItem::clplaceu = GuiApp::guiAppPo->ccfg->getBoolConfigVal("catlnk_come_up");
	setSelectionMode(QAbstractItemView::SingleSelection);
	setSelectionBehavior(QAbstractItemView::SelectRows);
	setRootIsDecorated(false);
	header()->setSortIndicatorShown(true);
	header()->setSortIndicator(0,Qt::DescendingOrder);
	header()->setClickable(true);
	
	//setSortingEnabled(this);
	setModel(model);
	model->n_root = start;
	model->n_parent = start;
	model->n_current = NULL;
	
	if( nread(start) == 1)
		cerrd("Konstruktor: can't read node! (1)");

	connect(this,SIGNAL(doubleClicked(const QModelIndex &)),this,SLOT(mdClick(const QModelIndex &)));

}

int MyListView::emitItemCh(void)
{

cerrd("MyListView::emitItemCh");
cerrd("a");
	if(currentIndex().isValid())
	{
		cerrd("b");

		if(currentIndex().internalPointer() != NULL)
		{
			cerrd("c");

			emit currItemChanged( (static_cast<DBListItem *>(currentIndex().internalPointer()))->dbnode );
		}
	}
cerrd("");
cerrd("MyListView::emitItemCh END");
return 0;
}


int MyListView::stepUp(void)
{
cerrd("MyListView::stepUp");
	DBListItem *curr_n;
	QModelIndex curr_i;

	curr_i = currentIndex();
	curr_n = static_cast<DBListItem *>(curr_i.internalPointer());
	if(curr_n != model->firstNode())
	{
		setCurrentIndex(indexAbove(curr_i));
		model->n_current = (static_cast<DBListItem *>(currentIndex().internalPointer()))->dbnode;
		emitItemCh();
	}
	cerrd("MyListView::stepUp END");

	return 0;
}

int MyListView::stepDown(void)
{
cerrd("MyListView::stepDown");
	DBListItem *curr_n;
	QModelIndex curr_i;

	curr_i = currentIndex();
	curr_n = static_cast<DBListItem *>(curr_i.internalPointer());
	if(curr_n != model->lastNode())
	{
		setCurrentIndex(indexBelow(curr_i));
		model->n_current = (static_cast<DBListItem *>(currentIndex().internalPointer()))->dbnode;
		emitItemCh();
	}
cerrd("MyListView::stepDown END");

	return 0;
}

int MyListView::setCurrent_byPoint(QPoint p)
{
	QModelIndex idx;

	idx = indexAt(p);
	if(!idx.isValid())
	{
		cerrd("MyListView::setCurrent_byPoint: not valid index....");
		return 1;
	}
	clearSelection();	
	setCurrentIndex(idx);
	model->n_current = (static_cast<DBListItem *>(currentIndex().internalPointer()))->dbnode;
	emitItemCh();
	return 0;
}

void MyListView::mousePressEvent(QMouseEvent *e)
{
	setCurrent_byPoint(e->pos());
}

void MyListView::mouseDoubleClickEvent(QMouseEvent *e)
{
	QModelIndex idx;

	setCurrent_byPoint(e->pos());
	idx = currentIndex();

	if(!idx.isValid())
	{
		cerrd("MyListView::mouseDoubleClickEvent: not valid index....");
		return;
	}
	
	cerrd(QString("valid index come....")+idx.row()+","+idx.column());
	cerrd("Executing it...");

	DBListItem *i;
	i = static_cast<DBListItem *>(idx.internalPointer());
	if(i != NULL && i->dbnode != NULL)
		{
			if(i->ntype == PD_NODE)
			{
				if(nread(i->dbnode->parent,i->dbnode) == 1)
							cerrd("mm 1 suck!");
			}
			else
			{
				if(nread(i->dbnode) == 1)
							cerrd("mm 2 suck!");
			}
		}

	return;
}
void MyListView::mouseMoveEvent(QMouseEvent *e)
{
	return;
}
void MyListView::mouseReleaseEvent(QMouseEvent *e)
{
	return;
}


void MyListView::keyPressEvent(QKeyEvent *e)
{
	DBListItem *i;

	if(e->key() == Qt::Key_Return || e->key() == Qt::Key_Right)
	{
		i = static_cast<DBListItem *>(currentIndex().internalPointer());
		if(i != NULL && i->dbnode != NULL)
		{
			if(i->ntype == PD_NODE)
			{
				if(nread(i->dbnode->parent,i->dbnode) == 1)
							cerrd("Key 1 suck!");
			}
			else
			{
				if(nread(i->dbnode) == 1)
							cerrd("Key2 suck!");
			}
		}
		return;
 	}
	
	if(e->key() == Qt::Key_Left)
	{
		i = static_cast<DBListItem *>(currentIndex().internalPointer());
		if(i != NULL && i->dbnode != NULL)
		{
			DBNode *p;

			if(i->ntype == PD_NODE)
				p = i->dbnode;
			else
				p = i->dbnode->parent;

			if(p == NULL || p->parent == NULL)
				return;

			if(nread(p->parent,p) == 1)
						cerrd("Key 3 suck!");
		}
		return;
 	}

	if(e->key() == Qt::Key_Up)
	{
		stepUp();
		return;
 	}

	if(e->key() == Qt::Key_Down)
	{
		stepDown();
		return;
 	}

	if(e->key() == Qt::Key_Space)
	{
		//Show statistics of node...

	}
	QTreeView::keyPressEvent(e);
}



void MyListView::wheelEvent(QWheelEvent *e)
{
	if(e->delta() > 0)
		stepUp();
	else
		stepDown();
}


int MyListView::mdClick(const QModelIndex & index)
{
	cerrd("MyListView::mdClick");
	DBListItem *i;

	if(!index.isValid())
		return 0;

	i = static_cast<DBListItem *>(index.internalPointer());
	if(i != NULL && i->dbnode != NULL)
	{
		if(i->ntype == PD_NODE)
		{
			if(nread(i->dbnode->parent,i->dbnode) == 1)
						cerrd("mclick1 suck!");
		}
		else
		{
			if(nread(i->dbnode) == 1)
						cerrd("mclick2 suck!");
		}
	}

	cerrd("MyListView::mdClick END");
	return 0;
}

bool MyListView::isParent(DBNode *n)
{
	if(model->n_parent == n )
		return true;
	return false;
}

int MyListView::nread(DBNode *n,DBNode *setselected)
{

	cerrd("MyListView::nread ");

	bool setci;
	DBNode *first,*c;
	DBNode *step;

	if(n == NULL)
	{
		model->clear();
		model->n_parent = NULL;
		clearSelection();
		reset();
		emit currItemChanged(model->n_current);
		cerrd("MyListView::nread - empty database;");
		return 1;
	}

	if( n->type != HC_CATALOG &&
		n->type != HC_MEDIA   && 
		n->type != HC_DIRECTORY )
	{
		cerrd("MyListView::nread -not cat/med/dir node");
		return 1;
	}

    model->clear();
	setci = false; //set the current(get as parameter) or not?
	first = NULL;

	if(n != model->n_root && n->parent != NULL)
		model->addItem(new DBListItem(first = n,PD_NODE));

	step=n->child;
	while(step != NULL)
	{
        model->addItem(new DBListItem(c = step));
		if(first == NULL)
			first = c;
		if(setselected != NULL && setselected == step)
		{
			model->n_current = c;
			setci = true;
		}
		step = step->next;
	}
	if(!setci && first != NULL)
		model->n_current = first; //if the current wasn't set, set the first

//if(model->n_current!= NULL) cerrd("------------1 "<<model->n_current->getNameOf().toLocal8Bit().constData());

	model->n_parent = n;
	model->sort(DBListItem::sortc,DBListItem::order ? Qt::DescendingOrder : Qt::AscendingOrder );
	
	model->update();
	clearSelection();
	reset();

//cerrd("------------2 "<<model->n_current->getNameOf().toLocal8Bit().constData() );

	if(model->n_current != NULL)
		setCurrentIndex(model->getIndexOfNode(model->n_current));
	update();
//cerrd("------------3 "<<model->n_current->getNameOf().toLocal8Bit().constData() );
	emit openedItem(n);
//cerrd("------------4"<<model->n_current->getNameOf().toLocal8Bit().constData() );
	emit currItemChanged(model->n_current);
cerrd("MyListView::nread END (successfull)");
	return 0;
}

int MyListView::setRoot(DBNode *newroot)
{
	clearSelection();

	model->n_root = newroot;
	model->n_parent = newroot;
	model->n_current = NULL;
	
	if( nread(model->n_root) == 1)
		cerrd("Konstruktor: can't read node! (2)");

	reset();
	return 0;
}

MyListView::~MyListView(void)
{
}

/**********************************************************************************
* HCatListDWidget class                                                           *
***********************************************************************************/

HCatListDWidget::HCatListDWidget(QWidget * parent)
: QDockWidget(tr("Browser"),parent,0)
{
	DBNode *pass_root;
	//::fconsole_start();

	setObjectName("HCatListDWidget");
	eAction = false;
	QFrame *dwf=new QFrame(this);
	dwf->setObjectName("HCatListDWidget-f");
	QVBoxLayout *vlay = new QVBoxLayout(dwf);
	vlay->setObjectName("HCatListDWidget-f-Lay");

	pass_root = NULL;
	if(GuiApp::guiAppPo->cdb != NULL)
		pass_root = GuiApp::guiAppPo->cdb->getRootNode();
	mlv = new MyListView(pass_root,dwf);
        vlay->addWidget(mlv);
	
	connect(mlv,SIGNAL(clicked(const QModelIndex&)),this,SLOT(mClick(const QModelIndex&)));
	connect(mlv,SIGNAL(openedItem(DBNode *)),this,SLOT(nodeSuccesfullOpened(DBNode *)));
	connect(mlv,SIGNAL(currItemChanged(DBNode *)),this,SLOT(itemChanged(DBNode *)));

	setWidget(dwf);
	refreshColor();
}

int HCatListDWidget::setRoot(DBNode *newroot)
{
	disableReceiveAction();
	mlv->setRoot(newroot);
	enableReceiveAction();
	return 0;
}

int HCatListDWidget::refreshColor(void)
{
	QPalette newpalette;
	newpalette = mlv->palette();
	newpalette.setColor(QPalette::Active,QPalette::Highlight,
		QColor( GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_r"),
				GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_g"),
				GuiApp::guiAppPo->ccfg->getIntConfigVal("infow_bgcolor_b"))
		);
	mlv->setPalette(newpalette);
	return 0;
}

int HCatListDWidget::nodeSuccesfullOpened(DBNode *n)
{
	eAction = true;
	emit openedItem(n);
	eAction = false;
	return 0;
}

int HCatListDWidget::openNode(DBNode *n)
{
	if(eAction)
		return 0;

    if(n != NULL)
	{
        if(mlv->nread(n) == 1)
					cerrd("openNode suck!");
	}
    return 0;
}

int HCatListDWidget::itemChanged(DBNode *n)
{  
cerrd("HCatListDWidget::itemChanged");
//cerrd(n->getNameOf().toLocal8Bit().constData());
	if(n != NULL)
	{
		eAction = true;
        emit hitItem(n,mlv->isParent(n));
		eAction = false;
	}
	else
	{
		eAction = true;
        emit hitItem(NULL,false);
		eAction = false;
	}
	cerrd("HCatListDWidget::itemChanged END");
    return 0;
	
}


int HCatListDWidget::mClick(const QModelIndex & index)
{
    DBNode *n;
    if(!index.isValid())
	return 0;
	
    n = ( static_cast<DBListItem *>(mlv->currentIndex().internalPointer()))->dbnode;
    if(n != NULL)
	{
		eAction = true;
        emit hitItem(n,mlv->isParent(n));
		eAction = false;
	}
    return 0;
}


HCatListDWidget::~HCatListDWidget(void)
{
}

#endif
//end code.
