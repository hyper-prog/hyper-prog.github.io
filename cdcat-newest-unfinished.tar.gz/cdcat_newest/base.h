/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Global

  Parameter Header (base.h)
****************************************************************************/

#ifndef CDCAT_CDCAT_SET_MAIN_H_
#define CDCAT_CDCAT_SET_MAIN_H_

#include <fcon.h>

using namespace std;
#define cerrd(a) { sdebug(a); }
//#define cerrd(a) ;

//#ifndef _WIN32
//#define Q_ASSERT(a) if(a) { cerr <<"ASSERT"<<endl;}
//#endif


//#define APP_CONSOLE_MODE
#define APP_GUI_MODE
//#define APP_MIXED_MODE

// CdCat version text:
#define VERSION  "Reborn 0.1 (Qt4/Unicode)"

 // CdCat homepage location:
#define HOMEPAGE "http://cdcat.sf.net"
 // + help.ui

// Datafile version:
#define DVERS    "2.1"   

//Known datafile versions (max 10)
#define KNOWN_VERSION01 "1.2"
#define KNOWN_VERSION02 "1.3"
#define KNOWN_VERSION03 "1.4"
#define KNOWN_VERSION04 "2.0"
#define KNOWN_VERSION05 "2.1"

//Config file name and place
#ifdef _WIN32
 #define CONFIGFILE "cdcat.cfg"
#else
 #define CONFIGFILE "/tmp/cdcat.conf"
#endif

//Config items (max 50)
#define C01B_VAL	"niceformat"			,true
#define C02B_VAL	"store_mp3techinfo"		,true
#define C03B_VAL	"store_mp3tag"			,true
#define C04B_VAL	"mp3tag_v1_default"		,false
#define C05B_VAL	"store_avitechinfo"		,true
#define C06B_VAL	"store_content"			,true
#define C07S_VAL	"stroe_contfiles"		,"*.nfo;*.diz;*.url;readme.txt;read.me"
#define C08I_VAL	"store_contlimit"		,32*1024
#define C09S_VAL	"mainwstate"			,""

#define C10B_VAL	"toolbar_cat"			,true
#define C11B_VAL	"toolbar_act"			,true
#define C12B_VAL	"toolbar_seek"			,true
#define C13B_VAL	"toolbar_other"			,true
#define C14B_VAL	"toolbar_help"			,true
#define C15B_VAL	"win_dbtree"			,true
#define C16B_VAL	"win_dblist"			,true
#define C17B_VAL	"win_dbinfo"			,true

#define C18I_VAL	"mwindow_posx"			,20
#define C19I_VAL	"mwindow_posy"			,20
#define C20I_VAL	"mwindow_sizex"			,500
#define C21I_VAL	"mwindow_sizey"			,400

#define C22B_VAL	"catlnk_come_up"		,false

#define C30I_VAL	"infow_bgcolor_r"		,125
#define C31I_VAL	"infow_bgcolor_g"		,125
#define C32I_VAL	"infow_bgcolor_b"		,255
#define C33I_VAL	"infow_linecolor_r"		,0
#define C34I_VAL	"infow_linecolor_g"		,0
#define C35I_VAL	"infow_linecolor_b"		,0
#define C36I_VAL	"infow_ctxtcolor_r"		,0
#define C37I_VAL	"infow_ctxtcolor_g"		,0
#define C38I_VAL	"infow_ctxtcolor_b"		,0
#define C39I_VAL	"infow_vtxtcolor_r"		,255
#define C40I_VAL	"infow_vtxtcolor_g"		,255
#define C41I_VAL	"infow_vtxtcolor_b"		,100

#endif
//end code.
