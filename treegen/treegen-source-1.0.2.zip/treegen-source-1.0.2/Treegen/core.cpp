/*
  TreeGenerator
  (OpenGL GLSL Environment generator)

  Copyright (C) Peter Deak (hyper80@gmail.com)
  http://hyperprog.com

  Platform: C++ Qt (http://qt.nokia.com)

  License GPL

  This program is only for test & education pusposely & fun ;-) */
#include "core.h"

#include <QtCore>
#include <QtGui>
#include <QtOpenGL>

#include "dconsole.h"

void Vertex::toOpenGL(void)
{
	//sdebug(QString("Vertex(%1,%2,%3)").arg(X()).arg(Y()).arg(Z()));
	glVertex3f(X(),Y(),Z());
}

void Vertex::setNormalThisMinus(Vertex *v)
{
	Vertex n;

	n.x = x - v->x;
	n.y = y - v->y;
	n.z = z - v->z;
	n.normalizeXYZvect();
	glNormal3d(n.x,n.y,n.z); 
}

void Vertex::normalizeXYZvect(void)
{
	double l = sqrt( X()*X() + Y()*Y() + Z()*Z());
	l *= w;
	x = x/l;  
	y = y/l;  
	z = z/l;  
	w = 1;
}

void Vertex::addVectWithLength(Vertex *v,double length)
{
	Vertex nv;
	nv = v;
	nv.normalizeXYZvect();
	x += nv.x * length;
	y += nv.y * length;
	z += nv.z * length;
}

void Vertex::add(Vertex *v)
{
	x += v->x;
	y += v->y;
	z += v->z;
}

#ifdef CORE_DEBUG
void Vertex::toSDebug(void)
{
	sdebug(QString("Vertex: %1 , %2 , %3 , 1").arg(X()).arg(Y()).arg(Z()));
}
#endif //CORE_DEBUG

Matrix4x4::Matrix4x4(void)
{
	d[0*4+0] = 1;  d[0*4+1] = 0;  d[0*4+2] = 0;  d[0*4+3] = 0; 
	d[1*4+0] = 0;  d[1*4+1] = 1;  d[1*4+2] = 0;  d[1*4+3] = 0; 
	d[2*4+0] = 0;  d[2*4+1] = 0;  d[2*4+2] = 1;  d[2*4+3] = 0; 
	d[3*4+0] = 0;  d[3*4+1] = 0;  d[3*4+2] = 0;  d[3*4+3] = 1; 

}

void Matrix4x4::mulVertex(Vertex* v)
{
	double ovx = v->x , ovy = v->y , ovz=v->z , ovw = v->w;

	v->x = d[0*4+0] * ovx  +  d[1*4+0] * ovy  +  d[2*4+0] * ovz  +  d[3*4+0] * ovw;
	v->y = d[0*4+1] * ovx  +  d[1*4+1] * ovy  +  d[2*4+1] * ovz  +  d[3*4+1] * ovw;
	v->z = d[0*4+2] * ovx  +  d[1*4+2] * ovy  +  d[2*4+2] * ovz  +  d[3*4+2] * ovw;
	v->w = d[0*4+3] * ovx  +  d[1*4+3] * ovy  +  d[2*4+3] * ovz  +  d[3*4+3] * ovw;
	if(v->w != 1.0)
		{
			v->x /= v->w;
			v->y /= v->w;
			v->z /= v->w;
			v->w = 1;
		}
}

void Matrix4x4::setTo(Matrix4x4* m)
{
	memcpy((void *)d,(void *)m->d,sizeof(double)*16);
}

void Matrix4x4::setColTo(int col,Vertex *v)
{
	d[0*4+col] = v->X();
	d[1*4+col] = v->Y();
	d[2*4+col] = v->Z();
}

Vertex *Matrix4x4::getCol(int col)
{
	Vertex *v = new Vertex(d[0*4+col],d[1*4+col],d[2*4+col]);
	return v;
}

void Matrix4x4::mulMe(Matrix4x4* m)
{
	Matrix4x4 *o = new Matrix4x4();
	o->setTo(this);
	int r,c;
	for(r=0;r<4;++r)
		for(c=0;c<4;++c)
		{
            d[r*4+c] =	o->d[r*4+0] * m->d[0*4+c]  +
						o->d[r*4+1] * m->d[1*4+c]  +  
						o->d[r*4+2] * m->d[2*4+c]  +  
						o->d[r*4+3] * m->d[3*4+c];
		}
	delete o;
}

#ifdef CORE_DEBUG
void Matrix4x4::toSDebug(void)
{
	sdebug("Matrix4x4:");
	sdebug(QString("%1  %2  %3  %4").arg(d[0*4+0]).arg(d[0*4+1]).arg(d[0*4+2]).arg(d[0*4+3]));
	sdebug(QString("%1  %2  %3  %4").arg(d[1*4+0]).arg(d[1*4+1]).arg(d[1*4+2]).arg(d[1*4+3]));
	sdebug(QString("%1  %2  %3  %4").arg(d[2*4+0]).arg(d[2*4+1]).arg(d[2*4+2]).arg(d[2*4+3]));
	sdebug(QString("%1  %2  %3  %4").arg(d[3*4+0]).arg(d[3*4+1]).arg(d[3*4+2]).arg(d[3*4+3]));
	sdebug("--------END--------");
}
#endif //CORE_DEBUG

Vertex* ringGenerator(int n,Vertex *cen,Vertex *dir,double r,int m)
{
	int i;
	double step=2.0f*M_PI / (double)n;
	double curr=0; //0 

	Matrix4x4 tr;
	Vertex d,d_onXZ;

	d = dir;
	d_onXZ = dir;
	
	d_onXZ.y=0;
	d.normalizeXYZvect();
	d_onXZ.normalizeXYZvect();
	if(d.x != 0.0f || d.z != 0.0f) 
	{
		double e = sqrt(d.x*d.x + d.z*d.z);
		double dox2=d_onXZ.x*d_onXZ.x , doz2=d_onXZ.z*d_onXZ.z , doxz=d_onXZ.x*d_onXZ.z;

		tr.set(0,0,-d.y*dox2-doz2);	tr.set(0,1,e*d_onXZ.x);		tr.set(0,2,doxz-d.y*doxz);	tr.set(0,3,0);
		tr.set(1,0,e*d_onXZ.x);		tr.set(1,1,d.y);			tr.set(1,2,e*d_onXZ.z);		tr.set(1,3,0);
		tr.set(2,0,d.y*doxz-doxz);	tr.set(2,1,-e*d_onXZ.z);	tr.set(2,2,d.y*doz2+dox2);	tr.set(2,3,0);
		tr.set(3,0,0);				tr.set(3,1,0);				tr.set(3,2,0);				tr.set(3,3,1);
	}

	tr.set(3,0,cen->x);
	tr.set(3,1,cen->y);
	tr.set(3,2,cen->z);

	Vertex *array=new Vertex[n];
	for(i=0;i<n;++i)
	{
		array[i].y =  0;
		array[i].x =  r*cos(curr); 
		array[i].z =  r*sin(curr);
		tr.mulVertex(array+i);

		curr += step;
	}
	return array;
	/*	//Old counting method: For debug
    //This is not perfekt, but good enough, the running code (not commented) is the multiplication of this matrix
	Matrix4x4 tr;
	Matrix4x4 m0,m1,m2;

	Vertex d,d_onXZ;

	d = dir;
	d_onXZ = dir;
	
	d_onXZ.y=0;
	d.normalizeXYZvect();
	d_onXZ.normalizeXYZvect();
	if(d.x != 0.0f || d.z != 0.0f) 
	{
		double e,f;
		e = sqrt(d.x*d.x + d.z*d.z);

		//0. (pre)rotation. for that reason the "unrotate" finish points. Rotate around the Y axis
	
		m0.set(0,0,d_onXZ.x);	m0.set(0,1,0);			m0.set(0,2,d_onXZ.z);	m0.set(0,3,0);
		m0.set(1,0,0);			m0.set(1,1,1);			m0.set(1,2,0);			m0.set(1,3,0);
		m0.set(2,0,-d_onXZ.z);	m0.set(2,1,0);			m0.set(2,2,d_onXZ.x);	m0.set(2,3,0);
		m0.set(3,0,0);			m0.set(3,1,0);			m0.set(3,2,0);			m0.set(3,3,1);
	
		//Flip out from the plain, rotation around the Z axis. e > 0 so if x<0 it works opposite, but the last transformation willturn it back
		//The base vector is normalized so i can work with that
		m1.set(0,0,-d.y);		m1.set(0,1,e);			m1.set(0,2,0);			m1.set(0,3,0);
		m1.set(1,0,e);			m1.set(1,1,d.y);		m1.set(1,2,0);			m1.set(1,3,0);
		m1.set(2,0,0);			m1.set(2,1,0);			m1.set(2,2,1);			m1.set(2,3,0);
		m1.set(3,0,0);			m1.set(3,1,0);			m1.set(3,2,0);			m1.set(3,3,1);

		//Flip outed plane will routate to the finish position (rotation around the Y axis)
		m2.set(0,0,d_onXZ.x);	m2.set(0,1,0);			m2.set(0,2,d_onXZ.z);	m2.set(0,3,0);
		m2.set(1,0,0);			m2.set(1,1,1);			m2.set(1,2,0);			m2.set(1,3,0);
		m2.set(2,0,-d_onXZ.z);	m2.set(2,1,0);			m2.set(2,2,d_onXZ.x);	m2.set(2,3,0);
		m2.set(3,0,0);			m2.set(3,1,0);			m2.set(3,2,0);			m2.set(3,3,1);

		if(m==0 || m==-1)	tr.mulMe(&m0);
		if(m==0 || m==1)	tr.mulMe(&m1);
		if(m==0 || m==2)	tr.mulMe(&m2);
	}*/
}
/////////////////////////////////////////////////////////////////////////////////////////////////
void setNormalFrom3Vertex(Vertex *a,Vertex *b,Vertex *c)
{
	double qx,qy,qz,px,py,pz,nx,ny,nz;
	qx = b->x - a->x;
	qy = b->y - a->y;
	qz = b->z - a->z;
	px = c->x - a->x;
	py = c->y - a->y;
	pz = c->z - a->z;
	
	nx = py*qz - pz*qy;
	ny = pz*qx - px*qz;
	nz = px*qy - py*qx;

	glNormal3d(nx,ny,nz); 
}

Vertex* normalFrom3Vertex(Vertex *a,Vertex *b,Vertex *c)
{
	Vertex *n=new Vertex();
	double qx,qy,qz,px,py,pz;

	qx = b->x - a->x;
	qy = b->y - a->y;
	qz = b->z - a->z;
	px = c->x - a->x;
	py = c->y - a->y;
	pz = c->z - a->z;
	
	n->x = py*qz - pz*qy;
	n->y = pz*qx - px*qz;
	n->z = px*qy - py*qx;
	return n;
}

QString Vertex::toString(void)
{
	return QString("x:%1 y:%2 z:%3 w:%4").arg(x).arg(y).arg(z).arg(w);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
Vertex*	getRandomDirection(Vertex *parentdir,Vertex *dlen,Vertex *startpoint,Vertex *treestartpoint,double parentradius,double hfactor,double wfactor,double tfactor)
{
	Vertex *cDir = new Vertex();

	double cH,cR;
	double sx,sy,sz,ex,ey,ez, dx,dy,dz;

	double xPar	 =  sqrt( (startpoint->y - treestartpoint->y)*(startpoint->y - treestartpoint->y) + 
						  (startpoint->x - treestartpoint->x)*(startpoint->x - treestartpoint->x) +
		                  (startpoint->z - treestartpoint->z)*(startpoint->z - treestartpoint->z) );

	cH = startpoint->y - treestartpoint->y;
	cR = sqrt( (startpoint->x - treestartpoint->x)*(startpoint->x - treestartpoint->x) +
		       (startpoint->z - treestartpoint->z)*(startpoint->z - treestartpoint->z)   );


	dx = dlen->x; dy = dlen->y; dz = dlen->z;

	dy = dy * (parentradius / (parentradius + tfactor));

    sx = parentdir->x - dx/2;	ex = parentdir->x + dx/2;
	sz = parentdir->z - dz/2;	ez = parentdir->z + dz/2;

	double multiplier = 2.0f;
	sy = parentdir->y - (dy/2 + dy*(cH/hfactor) + dy*multiplier*(cR/wfactor));	
	ey = parentdir->y + dy/2 + dy*(xPar/hfactor) + dy*multiplier*(cR/wfactor);
	
	cDir->x = sx + ((double)(rand()%1000)/1000) * (ex-sx);
	cDir->y = sy + ((double)(rand()%1000)/1000) * (ey-sy);
	cDir->z = sz + ((double)(rand()%1000)/1000) * (ez-sz);

	cDir->normalizeXYZvect();

	return cDir;
}

//end.
