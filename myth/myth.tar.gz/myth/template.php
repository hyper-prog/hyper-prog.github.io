<?php

/**
 * Add body classes if certain regions have content.
 */
function myth_preprocess_html(&$variables) {
}

/**
 * Override or insert variables into the page template for HTML output.
 */
function myth_process_html(&$variables) {
  if (module_exists('color')) {
    _color_html_alter($variables);
  }
}

/**
 * Override or insert variables into the page template.
 */
function myth_process_page(&$variables) {
  // Hook into color.module.
  if (module_exists('color')) {
    _color_page_alter($variables);
  }
}
