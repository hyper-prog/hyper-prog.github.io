/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

    License: GPLv2  http://www.gnu.org/licenses/gpl-2.0.html

    guilib
*/

#ifndef GSAFE__TEXTS_HEADER_FILE_X_
#define GSAFE__TEXTS_HEADER_FILE_X_

/** \defgroup texts texts */
/*  @{  */

#ifdef GSAFETEXT_LANG_HU
//===========================================================================================//
// begin GSAFETEXT_LANG_HU

/** Unknown text (lowercase) "unknown" */
#define GSAFETEXT_UNKNOWN       "ismeretlen"
/** Unknown text "Unknown" */
#define GSAFETEXT_TEXT_UNKNOWN  "Ismeretlen"

/** The default text of the HCheck checked "Yes" */
#define GSAFETEXT_YES_HAVE      "igen/van"
/** The default text of the HCheck unchecked "No" */
#define GSAFETEXT_NO_HAVENOT    "nem/nincs"

/** The title of HShowPrintHtml external program calling dialog. "Calling external program..." */
#define GSAFETEXT_CALLEXTERNAL  "K�ls� program h�v�sa..."

/** The text of the HShowPrintHtml external program calling dialog 1. 
 *  "External program is started!("  */
#define GSAFETEXT_STARTDIATEXT1 "K�ls� program elind�tva! ("
/** The text of the HShowPrintHtml external program calling dialog 2.. 
 *  ")\nDon't close this window, it will disappear automatically, if you exit from the external program!"  */
#define GSAFETEXT_STARTDIATEXT2 ")\nEzt az ablakot ne z�rd be, mag�t�l el fog t�nni, ha a k�ls� programb�l kil�pt�l!"

/** SqlChooseDialog select button text "Select" */
#define GSAFETEXT_DISPSQLCH_SELECTBUTTON    "Kiv�laszt"
/** SqlChooseDialog select dialog title "Select a value" */
#define GSAFETEXT_DISPSQLCH_TITLE           "�rt�k kiv�laszt�sa"

// end of GSAFETEXT_LANG_HU
//===========================================================================================//

#else
//===========================================================================================//
// begin GSAFETEXT_LANG_ENG

/** Unknown text (lowercase) "unknown" */
#define GSAFETEXT_UNKNOWN       "unknown"
/** Unknown text "Unknown" */
#define GSAFETEXT_TEXT_UNKNOWN  "Unknown"

/** The default text of the HCheck checked "Yes" */
#define GSAFETEXT_YES_HAVE      "yes/have"
/** The default text of the HCheck unchecked "No" */
#define GSAFETEXT_NO_HAVENOT    "no/haven't"

/** The title of HShowPrintHtml external program calling dialog. "Calling external program..." */
#define GSAFETEXT_CALLEXTERNAL  "Calling external program..."

/** The text of the HShowPrintHtml external program calling dialog 1. 
 *  "External program is started!("  */
#define GSAFETEXT_STARTDIATEXT1 "External program is started! ("
/** The text of the HShowPrintHtml external program calling dialog 2. 
 *  ")\nDon't close this window, it will disappear automatically, if you exit from the external program!"  */
#define GSAFETEXT_STARTDIATEXT2 ")\nDon't close this window, it will disappear automatically, if you exit from the external program!"

/** SqlChooseDialog select button text "Select" */
#define GSAFETEXT_DISPSQLCH_SELECTBUTTON    "Select"
/** SqlChooseDialog select dialog title "Select a value" */
#define GSAFETEXT_DISPSQLCH_TITLE           "Select a value"

// end GSAFETEXT_LANG_ENG
//===========================================================================================//
#endif // else branch 

/*  @}  */

#endif
//end.
