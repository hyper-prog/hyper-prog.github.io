/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

	dconsole.h
*/
#ifndef GSAFE_DCONSOLE__HEADER_
#define GSAFE_DCONSOLE__HEADER_


#include <QtCore>

#ifndef GSAFE_DISABLE_DEBUG

#ifdef FORMS_HAS_UI_PREFIX
#include "ui_debugwidgetbase.h"
#else
#include "debugwidgetbase.h"
#endif

#endif //GSAFE_DISABLE_DEBUG

void sqldebug(QString s);
void sdebug(QString s);
void dconsole(void);
void dconsole_close(void);
void dconsole_popup(QString t,QString txt);

class DConsoleCommandHolder
{
	public:
		virtual QString donsole_command_interpreter(QString commandString) = 0;
};

/** Beregisztr�l a egy egyedi parancsot */
void register_dconsole_command(QString command,DConsoleCommandHolder *interpreter,QString descr="");
void unregister_dconsole_command(QString command);
void clear_dconsole_commands();

#ifndef GSAFE_DISABLE_DEBUG
class QCloseEvent;
class DebugConsole : public QWidget , public Ui::DebugWidgetBase
 {
    
	Q_OBJECT
	public:
		static DebugConsole *myself;

	public:
		QString pre;
		DebugConsole(QWidget *parent);
		~DebugConsole(void);
		void add_text(QString s,int type); //0-sql,1-txt
		

		static void debug_sql(QString s);
		static void debug_txt(QString s);

		static void popup(QString title,QString str);

	protected:
		void closeEvent(QCloseEvent *e);

	public slots:
		int execSql(void);

 };
#endif //GSAFE_DISABLE_DEBUG

#endif
