using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace SplitView
{
    public partial class SplitView : Form
    {
        string dir;
        List<INode> gridinfo;
        int nullX, nullY;
        int viewStartX, viewStartY, viewEndX, viewEndY;
        int sliceX, sliceY;
        int deltaX, deltaY;

        bool drag;
        int mmX, mmY;
        int msX, msY;

        Image[] cacheB;
        int  [] cacheI;

        private void Show(int nX,int nY)
        {
            int idx;
            int[] needI = new int[4];

            viewStartX = nX;
            viewStartY = nY;
            viewEndX = viewStartX + pBox.Width;
            viewEndY = viewEndY + pBox.Height;

            if (gridinfo == null || gridinfo.Count == 0)
            {
                pBox.Refresh();
                return;
            }

            idx = 0;
            needI[0] = needI[1] = needI[2] = needI[3] = -1;
            foreach (INode run in gridinfo)
            {
                if (run.startX <= viewStartX && run.endX > viewStartX &&
                    run.startY <= viewStartY && run.endY > viewStartY)
                {
                    needI[0] = idx;
                    deltaX = viewStartX - run.startX;
                    deltaY = viewStartY - run.startY;
                }
                if (run.startX <= viewStartX + sliceX * 1 && run.endX > viewStartX + sliceX * 1 &&
                    run.startY <= viewStartY + sliceY * 0 && run.endY > viewStartY + sliceY * 0)
                        needI[1] = idx;
                if (run.startX <= viewStartX + sliceX * 0 && run.endX > viewStartX + sliceX * 0 &&
                    run.startY <= viewStartY + sliceY * 1 && run.endY > viewStartY + sliceY * 1)
                        needI[2] = idx;
                if (run.startX <= viewStartX + sliceX * 1 && run.endX > viewStartX + sliceX * 1 &&
                    run.startY <= viewStartY + sliceY * 1 && run.endY > viewStartY + sliceY * 1)
                        needI[3] = idx;

                ++idx;
            }
          
            //Loading
            int i, j;
            Image[] oldCacheB = new Image[4];
            bool[] ok = new bool[4];
            for (i = 0; i < 4; i++)
            {
                oldCacheB[i] = cacheB[i];
                ok[i] = false;
            }
            for (i = 0; i < 4; ++i)
                for (j = 0; j < 4; ++j)
                    if (needI[i] == cacheI[j])
                    {
                        cacheB[i] = oldCacheB[j];                        
                        ok[i] = true;
                    }

            cacheI[0] = needI[0];
            cacheI[1] = needI[1];
            cacheI[2] = needI[2];
            cacheI[3] = needI[3];

            if (!ok[0] && cacheI[0] != -1)
                cacheB[0] = Bitmap.FromFile(dir + "/" + gridinfo[needI[0]].filename);

            if (!ok[1] && cacheI[1] != -1)
                cacheB[1] = Bitmap.FromFile(dir + "/" + gridinfo[needI[1]].filename);

            if (!ok[2] && cacheI[2] != -1)
                cacheB[2] = Bitmap.FromFile(dir + "/" + gridinfo[needI[2]].filename);

            if (!ok[3] && cacheI[3] != -1)
                cacheB[3] = Bitmap.FromFile(dir + "/" + gridinfo[needI[3]].filename);

            pBox.Refresh();
        }

        private void pBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics graph = e.Graphics;

            
            if (cacheI[0] != -1)
                graph.DrawImageUnscaledAndClipped(cacheB[0], 
                    new Rectangle(0-deltaX,0-deltaY, sliceX, sliceY));
            if (cacheI[1] != -1)
                graph.DrawImageUnscaledAndClipped(cacheB[1], 
                    new Rectangle(0-deltaX+sliceX,0-deltaY, sliceX, sliceY));
            if (cacheI[2] != -1)
                graph.DrawImageUnscaledAndClipped(cacheB[2], 
                    new Rectangle(0-deltaX,0-deltaY+sliceY, sliceX, sliceY));
            if (cacheI[3] != -1)
                graph.DrawImageUnscaledAndClipped(cacheB[3], 
                    new Rectangle(0-deltaX+sliceX,0-deltaY+sliceY, sliceX, sliceY));

            if (drag)
            {
                graph.DrawLine(new Pen(Color.Black, 3), msX - 8, msY, msX + 8, msY);
                graph.DrawLine(new Pen(Color.Black, 3), msX, msY - 8, msX, msY + 8);
                graph.DrawLine(new Pen(Color.Black, 3), mmX - 8, mmY, mmX + 8, mmY);
                graph.DrawLine(new Pen(Color.Black, 3), mmX, mmY - 8, mmX, mmY + 8);
                graph.DrawLine(new Pen(Color.Black, 3), msX, msY, mmX, mmY);

                graph.DrawLine(new Pen(Color.White, 1), msX - 8, msY, msX + 8, msY);
                graph.DrawLine(new Pen(Color.White, 1), msX, msY - 8, msX, msY + 8);
                graph.DrawLine(new Pen(Color.White, 1), mmX - 8, mmY, mmX + 8, mmY);
                graph.DrawLine(new Pen(Color.White, 1), mmX, mmY - 8, mmX, mmY + 8);
                graph.DrawLine(new Pen(Color.White, 1), msX, msY, mmX, mmY);
            }
  
        }

        private void pBox_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            msX = e.X;
            msY = e.Y;
        }

        private void pBox_MouseMove(object sender, MouseEventArgs e)
        {
            mmX = e.X;
            mmY = e.Y;
            if (drag)
            {
                int dX=mmX-msX, dY=mmY-msY;
                label.Text = dX.ToString() + "," + dY.ToString();
                pBox.Refresh();
            }
        }

        private void pBox_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;

            nullX += msX - mmX;
            nullY += msY - mmY;

            if (nullX < 0) nullX = 0;
            if (nullY < 0) nullY = 0;

            label.Text = ":-)";
            Show(nullX,nullY);
        }

        private void Open(string file)
        {
            gridinfo = new List<INode>();
           
            label.Text = ":-)";

            sliceX = -1;
            sliceY = -1;
            FileInfo fi = new FileInfo(file);
            if (!fi.Exists)
                return;
            dir = fi.Directory.ToString();
            labelFile.Text = fi.Directory+"\\"+fi.Name;
            using (StreamReader cfile = new StreamReader(file))
            {
                INode i;
                string line;
                string[] parts;
                string[] coordinates;
                while ((line = cfile.ReadLine()) != null)
                {
                    i = new INode();
                    parts = line.Split(new char[] { '=' });
                    if (parts.Length == 2)
                    {
                        i.filename = parts[1];
                        coordinates = parts[0].Split(new char[] { ';' });
                        if (coordinates.Length == 4)
                        {
                            i.startX = Int32.Parse(coordinates[0]);
                            i.startY = Int32.Parse(coordinates[1]);
                            i.endX   = Int32.Parse(coordinates[2]);
                            i.endY   = Int32.Parse(coordinates[3]);
                            if (sliceX == -1 && sliceY == -1)
                            {
                                sliceX = i.endX - i.startX;
                                sliceY = i.endY - i.startY;
                            }
                            else
                              if(sliceX != i.endX - i.startX ||
                                   sliceY != i.endY - i.startY   )
                                {
                                    MessageBox.Show("Tile Error");
                                    label.Text = ":-(";
                                    return;
                                }
                        }
                     }
                     gridinfo.Add(i);
                }//end of while
            }//end of using

            label.Text = gridinfo.Count.ToString() + " part";

            pBox.BackColor = Color.Black;
            nullX = 0;
            nullY = 0;
            drag = false;

            Show(nullX, nullY);
        }

        public SplitView()
        {
            InitializeComponent();
            label.Text = pBox.Width.ToString() + " x " + pBox.Height.ToString();

            cacheB = new Bitmap[4];
            cacheI = new int[4];
            cacheI[0] = -1;
            cacheI[1] = -1;
            cacheI[2] = -1; 
            cacheI[3] = -1; 

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "SplitViewFiles (*.splv)|*.splv";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                Open(ofd.FileName);
            }
        }

    }

    class INode
    {
        public int startX, startY, endX, endY;
        public string filename;
    }

}