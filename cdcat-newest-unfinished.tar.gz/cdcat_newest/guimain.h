/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Main gui module (guimain.h)
****************************************************************************/
#ifndef CDCAT_GUIMAIN_HEADER
#define CDCAT_GUIMAIN_HEADER

#include "base.h"

#include <QObject>

#ifdef APP_GUI_MODE

#include <QtGui>

class HCatTreeDWidget;
class HCatListDWidget;
class HCatInfoDWidget;
class DBNode;
class AppMainWindow : public QMainWindow
{
	Q_OBJECT

	public:
		AppMainWindow();
		~AppMainWindow();

	public slots:
		int showStatusMsg(QString msg);
		int showStatusNode(DBNode *n);

	private:
		QStatusBar *statusbar;

		QMenu *fileMenu;
		QMenu *editMenu;
		QMenu *inoutMenu;
		QMenu *othersMenu;
		QMenu *helpMenu;
		QMenu *viewMenu;
		QMenu *recentMenu;

		QToolBar *ctoolbar;
		QToolBar *mtoolbar;
		QToolBar *stoolbar;
		QToolBar *otoolbar;
		QToolBar *htoolbar;

	protected:
		void closeEvent(QCloseEvent *ce);

};


#endif
#endif
//end code.
