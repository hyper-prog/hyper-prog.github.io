/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

    License: GPLv2  http://www.gnu.org/licenses/gpl-2.0.html

    xmlolib.h
*/
#ifndef GSAFE__XML_OUTPUT_LIB_HEADER_FILE_X_
#define GSAFE__XML_OUTPUT_LIB_HEADER_FILE_X_

#include <QtCore>
#include <QtGui>

/** \defgroup xmlolib xmlolib */
/*  @{  */

#include <datalib.h>

/** HXmloTable class can generate a Microsoft Excel XML calc table format output from
 *  HTable/HList/HPlainDataMatrix objects.  
 *  If you create this class a dialog will appear which ask the file name to save.
 *  If the process is success the file can be opened with excel.\n
 *  This class will generate the document according the meta data class (HTable/HList/HPlainDataMatrix)
 *  and the data will came from these class too. 
  \code
    HTable *mytable=...
    ...
    HXmloTable *d = new HXmloTable(this,mytable);
    d->exec();
    delete d;
    ...
 \endcode
 * or you can print a result of a query
 \code
    HSqlHandler h;
    HPlainDataMatrix *pdm = h.submitNResultQuery(3,"SELECT name,age,address FROM peoples;","Error occured");
    HXmloTable *d = new HXmloTable(this,pdm);
    d->exec();
    delete d;
    delete pdm;
 \endcode
 *  @see HTable @see HList @see HPlainDataMatrix    */
class HXmloTable : public QDialog
{
    Q_OBJECT

    private:
        QLineEdit  *fnedit;
        HBase *data;

        void genXml(QTextStream *out); 

    public:
        /** Creates a HXmloTable object
         *  @param parent the QWidget descendant parent
         *  @param d the meta-data class    */
        HXmloTable(QWidget *parent,HBase *d);
        /** Destructor */
        ~HXmloTable(void);

    public slots:
        int cf(void);
        int saveButton(void);
        int closeButton(void);
};

/* @} */

#endif
