/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2007 Peter Deak  (hyper80@gmail.com)

	hyperdocedit.cpp
*/

#include <QtCore>
#include <QtGui>

#include <dconsole.h>
#include <hyperdocedit.h>
#include <docgen.h>
#include <datalib.h>
#include <dialib.h>


////////////////////////////////////////////////////////////////////////////
// class HyperDocEdit   											      //
////////////////////////////////////////////////////////////////////////////

HyperDocEdit::HyperDocEdit(QWidget *parent,int pdhdoc_del_mode)
: QWidget(parent)
{
	sdebug("*** HyperDocEdit::HyperDocEdit ***");
	setAttribute(Qt::WA_DeleteOnClose);
	
	setupUi(this);
	
	dhdoc_del_mode = pdhdoc_del_mode;
	hypdoc = NULL;
	selectedtext = MODE_HTML;
	nowchaged = false;
	currentField = "";

	selectedHT = NULL;
	selectedHF = NULL;

	textEditPlain->setReadOnly(true);
	textEditHtml->setReadOnly(false);

	checkText->setChecked(false);
	checkHtml->setChecked(true);

//OFF	textEditHtml->setTextFormat(Qt::AutoText);
//OFF	textEditPlain->setTextFormat(Qt::PlainText);

	textEditPlain->setText("<html><head><meta name=\"qrichtext\" content=\"1\"/></head><body></body></html>");

	
	connect(comboTL    ,SIGNAL(activated(int)),this,SLOT(comboTLSlot(int)));
	connect(comboListTL,SIGNAL(activated(int)),this,SLOT(comboListTLSlot(int)));
	connect(comboFields,SIGNAL(activated(int)),this,SLOT(comboFieldsSlot(int)));
    
	connect(textEditPlain,SIGNAL(textChanged()),this,SLOT(text_changed()));
	connect(textEditHtml,SIGNAL(textChanged()),this,SLOT(html_changed()));

	connect(buttonOpen  ,SIGNAL(clicked()),this,SLOT(openReq()));
	connect(buttonSave  ,SIGNAL(clicked()),this,SLOT(saveReq()));
	connect(buttonSaveas,SIGNAL(clicked()),this,SLOT(saveasReq()));
	connect(buttonClose ,SIGNAL(clicked()),this,SLOT(closeReq()));
	
	connect(buttonData ,SIGNAL(clicked()),this,SLOT(toolInsertData()));
	connect(buttonRes  ,SIGNAL(clicked()),this,SLOT(toolInsertRes()));
	connect(buttonIter ,SIGNAL(clicked()),this,SLOT(toolInsertIter()));
	connect(buttonCond ,SIGNAL(clicked()),this,SLOT(toolInsertCond()));
	connect(buttonTable ,SIGNAL(clicked()),this,SLOT(toolInsertTable()));
	connect(buttonClose ,SIGNAL(clicked()),this,SLOT(close()));

	connect(checkHtml,SIGNAL(stateChanged(int)),this,SLOT(checkHtmlChanged(int)));
	connect(checkText,SIGNAL(stateChanged(int)),this,SLOT(checkTextChanged(int)));

	//--------------------------------------------------------
	combo1->addItem("Standard");
    combo1->addItem("Bullet List (Disc)");
    combo1->addItem("Bullet List (Circle)");
    combo1->addItem("Bullet List (Square)");
    combo1->addItem("Ordered List (Decimal)");
    combo1->addItem("Ordered List (Alpha lower)");
    combo1->addItem("Ordered List (Alpha upper)");

	QFontDatabase db;
    combo2->addItems( db.families() );
	combo2->setEditText( QApplication::font().family() );

    QList<int> sizes = db.standardSizes();
    QList<int>::Iterator it = sizes.begin();
    for ( ; it != sizes.end(); ++it )
	combo3->addItem( QString::number( *it ) );
	combo3->setEditText(	QString::number( QApplication::font().pointSize() ) );
	
	//--------------------------------------------------------

	connect(buttonUndo,SIGNAL(clicked()),this,SLOT(etUndo()));
	connect(buttonRedo,SIGNAL(clicked()),this,SLOT(etRedo()));
	
	connect(buttonCopy,SIGNAL(clicked()),this,SLOT(etCopy()));
	connect(buttonCut,SIGNAL(clicked()),this,SLOT(etCut()));
	connect(buttonPaste,SIGNAL(clicked()),this,SLOT(etPaste()));

	connect(buttonStrong,SIGNAL(clicked()),this,SLOT(etStrong()));
	connect(buttonItaly,SIGNAL(clicked()),this,SLOT(etItaly()));
	connect(buttonUnder,SIGNAL(clicked()),this,SLOT(etUnder()));

	connect(buttonLeft,SIGNAL(clicked()),this,SLOT(etLeft()));
	connect(buttonCenter,SIGNAL(clicked()),this,SLOT(etCenter()));
	connect(buttonRight,SIGNAL(clicked()),this,SLOT(etRight()));
	connect(buttonJust,SIGNAL(clicked()),this,SLOT(etJust()));

	connect(combo1,SIGNAL(activated(int)),this,SLOT(textStyle(int)));
	connect(combo2,SIGNAL(activated(const QString &)),this,SLOT(textFamily(const QString &)));
	connect(combo3,SIGNAL(activated(const QString &)),this,SLOT(textSize(const QString &)));

	buttonLeft->setChecked( true );
	buttonCenter->setChecked( false );
    buttonRight->setChecked( false);
	buttonJust->setChecked( false );

	refreshConnections();

	editedname = "";
	sdebug("*** HyperDocEdit::HyperDocEdit ***END");
}

HyperDocEdit::~HyperDocEdit(void)
{
	sdebug("*** HyperDocEdit::~HyperDocEdit ***");
	if(hypdoc != NULL && dhdoc_del_mode == DELETE_HYPDOC)
		delete hypdoc;
	sdebug("*** HyperDocEdit::~HyperDocEdit ***END");
}

int HyperDocEdit::etUndo(void)
{
	if(selectedtext == MODE_HTML)
	{
		textEditHtml->undo();
	}
	return 0; 
}

int HyperDocEdit::etRedo(void)
{
	if(selectedtext == MODE_HTML)
	{
		textEditHtml->redo();
	}
	return 0; 
}

		
int HyperDocEdit::etCopy(void)
{
	if(selectedtext == MODE_HTML)
	{
		textEditHtml->copy();
	}
	return 0; 
}

int HyperDocEdit::etCut(void)
{
	if(selectedtext == MODE_HTML)
	{
		textEditHtml->cut();
	}
	return 0; 
}

int HyperDocEdit::etPaste(void)
{
	if(selectedtext == MODE_HTML)
	{
		textEditHtml->paste();
	}
	return 0; 
}

		
int HyperDocEdit::etStrong(void)
{
	if(selectedtext == MODE_HTML)
	{
//OFF		textEditHtml->setBold( buttonStrong->isChecked() );
	}
	return 0; 
}

int HyperDocEdit::etItaly(void)
{
	if(selectedtext == MODE_HTML)
	{
//OFF		textEditHtml->setItalic( buttonItaly->isChecked() );
	}
	return 0; 
}

int HyperDocEdit::etUnder(void)
{
	if(selectedtext == MODE_HTML)
	{
//OFF		textEditHtml->setUnderline( buttonUnder->isChecked() );
	}
	return 0; 
}


int HyperDocEdit::etLeft(void)
{
//OFF	textEditHtml->setAlignment( Qt::AlignLeft ) ;

	buttonLeft->setChecked( true );
	buttonCenter->setChecked( false );
    buttonRight->setChecked( false);
	buttonJust->setChecked( false );
	return 0; 
}

int	HyperDocEdit::etCenter(void)
{
//OFF	textEditHtml->setAlignment( Qt::AlignCenter ) ;
	buttonLeft->setChecked( false );
	buttonCenter->setChecked( true );
    buttonRight->setChecked( false);
	buttonJust->setChecked( false );
	return 0; 
}

int	HyperDocEdit::etRight(void)
{
//OFF	textEditHtml->setAlignment( Qt::AlignRight ) ;
	buttonLeft->setChecked( false );
	buttonCenter->setChecked( false );
    buttonRight->setChecked( true);
	buttonJust->setChecked( false );
	return 0; 
}

int	HyperDocEdit::etJust(void)
{
//OFF	textEditHtml->setAlignment( Qt::AlignJustify ) ;
	buttonLeft->setChecked( false );
	buttonCenter->setChecked( false );
    buttonRight->setChecked( false);
	buttonJust->setChecked( true );
	return 0; 
}


int HyperDocEdit::textStyle (int i)
{
	/*
    if ( i == 0 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayBlock, QStyleSheetItem::ListDisc );
    else if ( i == 1 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListDisc );
    else if ( i == 2 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListCircle );
    else if ( i == 3 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListSquare );
    else if ( i == 4 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListDecimal );
    else if ( i == 5 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListLowerAlpha );
    else if ( i == 6 )
	textEditHtml->setParagType( QStyleSheetItem::DisplayListItem, QStyleSheetItem::ListUpperAlpha );
    textEditHtml->viewport()->setFocus();
*/	return 0; 
}

int HyperDocEdit::textFamily(const QString &str)
{
//OFF	textEditHtml->setFamily( str );
    textEditHtml->viewport()->setFocus();
	return 0; 
}

int HyperDocEdit::textSize(const QString &str)
{
//OFF	textEditHtml->setPointSize( str.toInt() );
    textEditHtml->viewport()->setFocus();
	return 0; 
}


int HyperDocEdit::checkHtmlChanged(int state)
{
	if(state)
		checkText->setChecked(false);
	else
		checkText->setChecked(true);

	textEditPlain->setReadOnly(!checkText->isChecked());
	textEditHtml->setReadOnly(!checkHtml->isChecked());
	
	selectedtext = checkHtml->isChecked() ? MODE_HTML : MODE_TEXT ;
	return 0;
}

int HyperDocEdit::checkTextChanged(int state)
{
	if(state)
		checkHtml->setChecked(false);
	else
		checkHtml->setChecked(true);

	textEditPlain->setReadOnly(!checkText->isChecked());
	textEditHtml->setReadOnly(!checkHtml->isChecked());

	selectedtext = checkHtml->isChecked() ? MODE_HTML : MODE_TEXT ;
	return 0;
}

int HyperDocEdit::openReq(void)
{
	QString text,file;

	if(hypdoc == NULL)
		return 0;

	file = QFileDialog::getOpenFileName(this,"Open template","");
	if(file.isEmpty())
		return 0;

	editedname = file;
	QFile f(file);
	if(f.open(QFile::ReadOnly))
	{
		QTextStream t(&f); 
		text = t.readAll();
		f.close();
	}
	else
		sdebug("FAILED TO READ FILE");	
	hypdoc->set(text);
	setHyperDoc(hypdoc);
	return 0;
}

int HyperDocEdit::saveReq(void)
{
	if(hypdoc == NULL)
		return 0;

	if(editedname.isEmpty())
		return 0;
	
	QFile f(editedname);
	if(f.open(QFile::WriteOnly))
	{
		QTextStream t(&f); 
		t << hypdoc->getRawDoc();
		f.close();
	}
	else
		sdebug("FAILED TO WRITE FILE!");	

	return 0;
}

int HyperDocEdit::saveasReq(void)
{
	QString file;
	
	if(hypdoc == NULL)
		return 0;

	file = QFileDialog::getSaveFileName(this,"Save template","");
	if(file.isEmpty())
		return 0;

	editedname = file;
	QFile f(file);
	if(f.open(QFile::WriteOnly))
	{
		QTextStream t(&f); 
		t << hypdoc->getRawDoc();
		f.close();
	}
	else
		sdebug("FAILED TO WRITE FILE!");	

	return 0;
}

int HyperDocEdit::closeReq(void)
{
	close();
	return 0;
}

int HyperDocEdit::text_changed(void)
{
	QString text;

	if(nowchaged)
		return 0;
	nowchaged = true;
	text = textEditPlain->toPlainText();
	hypdoc->set(text);
	textEditHtml->setText(text);
	nowchaged = false;
	return 0;
}

int HyperDocEdit::html_changed(void)
{
	QString text;

	if(nowchaged)
		return 0;
	nowchaged = true;
	text = textEditHtml->toHtml();

	//Woraround -to make the optput XML compatible :-(
	text.replace(QRegExp("border=([012345])"),"border=\"\\1\"");

	hypdoc->set(text);
	textEditPlain->setText(text);
	nowchaged = false;
	return 0;
}

int HyperDocEdit::setHyperDoc(HyperDoc *hd)
{
	QString cap;
	if(hd == NULL)
		return 0;

	hypdoc = hd;
	refreshConnections();
	textEditHtml->setText(hypdoc->getRawDoc());
	textEditPlain->setText(hypdoc->getRawDoc());
	if(hypdoc->getName().isEmpty())
		cap = "Template editor";
	else
		cap = QString("Template editor - %1").arg(hypdoc->getName());

	emit changeCaption(cap);
	setWindowTitle(cap);
	return 0;

}

int HyperDocEdit::refreshConnections(void)
{
	if(hypdoc == NULL)
		return 0;

	sdebug("*** HyperDocEdit::refreshConnections ***");	
	comboListTL->clear();
	if(comboTL->currentText() == "Tables")
	{
		QList<QString>::iterator is;
		is=hypdoc->dtsn->begin();
		while(is != hypdoc->dtsn->end())
		{
			comboListTL->addItem(*is);
			++is;
		}
	}
	if(comboTL->currentText() == "Lists")
	{
		QList<HFloatTables *>::iterator il;
		il=hypdoc->fts->begin();
		while(il != hypdoc->fts->end())
		{
			comboListTL->addItem((*il)->sqlTableName());
			++il;
		}
	}

	//--//
	comboRes->clear();
	QList<ResourceProvider *>::iterator ir;
	ir = hypdoc->resourceProviders->begin();
	while(ir != hypdoc->resourceProviders->end())
	{
		comboRes->addItems((*ir)->resources());
		++ir;
	}
		


	sdebug("*** HyperDocEdit::refreshConnections ***END");	
	refreshConnections2();
	return 0;
}

int HyperDocEdit::comboTLSlot(int i)
{
	return refreshConnections();
}

int HyperDocEdit::refreshConnections2(void)
{
	QString cont;

	if(hypdoc == NULL)
		return 0;

	sdebug("*** HyperDocEdit::refreshConnections2 ***");	
	cont = comboListTL->currentText();
	if(comboTL->currentText() == "Tables")
	{
		QList<QString>::iterator is;
		QList<HTable *>::iterator it;
		is=hypdoc->dtsn->begin();
		it=hypdoc->dtsp->begin();
		while(is != hypdoc->dtsn->end())
		{
			if( cont == *is )
			{
				selectedHT = *it;
				selectedHF = NULL;
				refreshConnections3();
			}
			++is;
			++it;
		}
	}
	if(comboTL->currentText() == "Lists")
	{
		QList<HFloatTables *>::iterator il;
		il=hypdoc->fts->begin();
		while(il != hypdoc->fts->end())
		{
			if( cont == (*il)->sqlTableName() )
			{
				selectedHT = NULL;
				selectedHF = *il;
				refreshConnections3();
			}
			++il;
		}
	}
	sdebug("*** HyperDocEdit::refreshConnections2 ***END");	
	return 0;
}

int HyperDocEdit::refreshConnections3(void)
{
	HDataField *df;
	
	if(hypdoc == NULL)
		return 0;
	
	sdebug("*** HyperDocEdit::refreshConnections3 ***");	
	comboFields->clear();
	if(selectedHT != NULL)
	{
		selectedHT->firstField();
		while((df=selectedHT->nextFieldAll()) != NULL)
				if(df->isSQLField())
					comboFields->addItem( df->sqlSelectHead() );

	}
	if(selectedHF != NULL)
	{
		selectedHF->baserecord->firstField();
		while((df=selectedHF->baserecord->nextFieldAll()) != NULL)
				if(df->isSQLField())
					comboFields->addItem( df->sqlSelectHead() );

	}
	refreshConnections4();
	sdebug("*** HyperDocEdit::refreshConnections3 ***END");	
	return 0;
}

int HyperDocEdit::comboListTLSlot(int i)
{
	return refreshConnections2();
}

int HyperDocEdit::refreshConnections4(void)
{
	QString curr;
	HDataField *df;
	
	if(hypdoc == NULL)
		return 0;

	sdebug("*** HyperDocEdit::refreshConnections4 ***");	
	curr = comboFields->currentText();
	textExp->setText("");
	if(selectedHT != NULL)
	{
		selectedHT->firstField();
		while((df=selectedHT->nextFieldAll()) != NULL)
			if(df->isSQLField())
				if( curr == df->sqlSelectHead() )
				{
					currentField = QString("%1:%2").arg(comboListTL->currentText()).arg(df->sqlSelectHead());
					textExp->setText(df->getExplainText());
				}
	}
	if(selectedHF != NULL)
	{
		selectedHF->baserecord->firstField();
		while((df=selectedHF->baserecord->nextFieldAll()) != NULL)
			if(df->isSQLField())
				if( curr == df->sqlSelectHead() )
				{
					currentField = QString("*:%1").arg(df->sqlSelectHead());
					textExp->setText(df->getExplainText());
				}
	}
	sdebug("*** HyperDocEdit::refreshConnections4 ***END");	
	return 0;
}

int HyperDocEdit::comboFieldsSlot(int i)
{
	return refreshConnections4();
}

int HyperDocEdit::comboResSlot(int i)
{
	//-- insert code here --//
	return 0;
}

//-------------------------------------------------------------------------
QString HyperDocEdit::getSelected(void)
{
	return currentField;
}

int HyperDocEdit::plainChanged(void)
{
	return 0;
}

int HyperDocEdit::autoChanged(void)
{
	return 0;
}

int HyperDocEdit::toolInsertData   (void)
{	return toolInsertDataRes(0); }

int HyperDocEdit::toolInsertRes    (void)
{	return toolInsertDataRes(1); }

int HyperDocEdit::toolInsertDataRes(int mode)
{
	QString gstr;

	if(getSelected().isEmpty())
		return 0;
	
	QList<QString> expts;
	expts.push_back("Sz�vegbet�t kezd�skor");
	expts.push_back("Sz�vegbet�t befejez�skor");
	expts.push_back("Helyettes�t� sz�veg (ha �res)");
	
	GetTextBox *gtb = new GetTextBox(this,"Adatbak�r�s...","Finomhagoland� adatok \n(Ha nincs be�ll�tand� csak hagyd �ket �resen)",expts);
	gtb->exec();

	if(gtb->results.size() == 0)
	{
		delete gtb;
		return 0;
	}

	gstr = QString(mode == 0 ? "[data %1%2%3]%4[/data]" : "[res %1%2%3]%4[/res]")
		.arg(gtb->results[0].isEmpty() ? "" : QString("begin=|%1| "   ).arg(gtb->results[0]))
		.arg(gtb->results[1].isEmpty() ? "" : QString("end=|%1| "     ).arg(gtb->results[1]))
		.arg(gtb->results[2].isEmpty() ? "" : QString("notfound=|%1| ").arg(gtb->results[2]))
		.arg(mode == 0 ? getSelected() : comboRes->currentText() );
	
	sdebug(gstr);

	if(checkHtml->isChecked())
		textEditHtml->insertPlainText(gstr);
	if(checkText->isChecked())
		textEditPlain->insertPlainText(gstr);

	delete gtb;
	return 0;
}

int HyperDocEdit::toolInsertTable(void)
{
	int i,j,row,col;
	QString gstr;

	if(!checkText->isChecked())
	{
		QMessageBox::warning(this,"Figyelmeztet�s",
			"T�bl�zatot csak akkor lehet besz�rni ha az aktu�lisan \"Text\" m�dban szerkeszt�nk.");
		return 0;
	}

	QList<QString> expts;
	expts.push_back("Keret sz�less�ge");
	expts.push_back("Sorok sz�ma");
	expts.push_back("Oszlopok sz�ma");
	
	GetTextBox *gtb = new GetTextBox(this,"T�bl�zat tulajdons�gai...","",expts);
	gtb->exec();
	
	if(gtb->results.size() == 0)
	{
		delete gtb;
		return 0;
	}

	gstr = QString("\n<table border=\"%1\">\n")
		.arg(gtb->results[0].isEmpty() ? "0" : gtb->results[0]);

	row = gtb->results[1].isEmpty() ? 0 : gtb->results[1].toInt();
	col = gtb->results[2].isEmpty() ? 0 : gtb->results[2].toInt();

	for(i = 0; i < row;++i)
	{
		gstr.append(" <tr>\n");
		for(j = 0; j < col;++j)
			gstr.append("\t<td>cell</td>\n");
		gstr.append(" </tr>\n");
	}
	gstr.append("</table>\n");

	textEditPlain->insertPlainText(gstr);

	delete gtb;
	return 0;
}

int HyperDocEdit::toolInsertCond(void)
{
	return 0;
}

int HyperDocEdit::toolInsertIter(void)
{

	QString gstr;

	if(getSelected().isEmpty()) 
		return 0;

	if(selectedHF == NULL)
	{
		QMessageBox::warning(this,"Figyelmeztet�s","Ha ismetl�d� sz�veget szursz be a kiv�lasztott adatmez�nek list�nak kell lennie.\n(Adatmez� besz�r�sa sorban)");
		return 0;
	}
	
	QList <QString> expts;
	expts.push_back("Tartalom (�rdemes ut�lag kitolteni)");
	expts.push_back("Helyettes�t� sz�veg (ha nem tal�lhat� elem)");
	
	GetTextBox *gtb = new GetTextBox(this,"Adatbak�r�s...","Finomhagoland� adatok \n(Ha nincs be�ll�tand� csak hagyd �ket �resen)",expts);
	gtb->exec();

	if(gtb->results.size() == 0)
	{
		delete gtb;
		return 0;
	}

	gstr = QString("[iter data=|%1|%2]%3[/iter]")
		.arg( selectedHF->sqlTableName() )
		.arg( gtb->results[1].isEmpty() ? "" : QString(" notfound=|%1|" ).arg(gtb->results[1]) )
		.arg( gtb->results[0].isEmpty() ? "   " : gtb->results[0] );
	
	sdebug(gstr);

	if(checkHtml->isChecked())
		textEditHtml->insertPlainText(gstr);
	if(checkText->isChecked())
		textEditPlain->insertPlainText(gstr);

	delete gtb;
	return 0;
}

void HyperDocEdit::closeEvent(QCloseEvent *e)
{
	emit closeRequest();
	QWidget::closeEvent(e);
}

////////////////////////////////////////////////////////////////////////////
// class HyperDocEditSql											      //
////////////////////////////////////////////////////////////////////////////

HyperDocEditSql::HyperDocEditSql(QWidget *parent,QString tablename,QString keyfname,
								 QString expfname,QString contentfname,int pdhdoc_del_mode)
								 : HyperDocEdit(parent,pdhdoc_del_mode)
{
	sdebug("*** HyperDocEdit::HyperDocEditSql ***");
	p_table = tablename; 
	p_key   = keyfname;
    p_exp   = expfname;
	p_cont  = contentfname;
	sdebug("*** HyperDocEdit::HyperDocEditSql ***END");
}

int HyperDocEditSql::shadowOpen(QString name,int mode)
{
	HSqlHandler sqlh;
	QString selectedkey,txtexp,txtcont;

	if(name.isEmpty())
	{ sdebug("HyperDocEditSql::openReq => nothing to selected, exiting..."); close();  return 1;	}

	//megnyitas
	txtcont =sqlh.submit1ResultQuery(QString("SELECT %1 FROM %2 WHERE %3=\'%4\';")
		.arg(p_cont).arg(p_table).arg(mode == 0 ? p_key : p_exp).arg(name),
		"Nem sikerult megnyitni a sablont! (1)").toString();

	if(sqlh.errorStatus())
	{ QMessageBox::warning(this,"Hiba","Nem sikerult megnyitni a sablont! (2)"); close(); return 1; }

	txtexp =sqlh.submit1ResultQuery(QString("SELECT %1 FROM %2 WHERE %3=\'%4\';")
					.arg(p_exp).arg(p_table).arg(mode == 0 ? p_key : p_exp).arg(name),
		"Nem sikerult megnyitni a sablont! (2)").toString();

	if(sqlh.errorStatus())
	{ QMessageBox::warning(this,"Hiba","Nem sikerult megnyitni a sablont! (3)"); close(); return 1;	}

	//megnyitott beallitasa
	editedname = txtexp;
	hypdoc->setName(txtexp);
	hypdoc->set(txtcont);
	setHyperDoc(hypdoc);
	return 0;
}

int HyperDocEditSql::openReq(void)
{
	HSqlHandler sqlh;
	QString selectedkey,txtexp,txtcont;

	HList *templates = new HList(p_table);
	templates->addField((new HSmallText(p_exp,"N�v","N�v","",""))->asColored(60,200,60));
	templates->addField((new HKey(p_key,"Kulcs","Kulcs","")));


	HDialog* dialog = new HDialog(this,"Megnyit�s",templates,NULL,"Ok|EscC|Vert|DeleteData","V�laszd ki a megnyitand� sablont",
									"","",NULL);
	templates->readList();
	dialog->exec();
	selectedkey = templates->soft_current_key;
	delete dialog;

	return shadowOpen(selectedkey);
}

int HyperDocEditSql::saveReq(void)
{
	bool ok,lock;
	HSqlHandler sqlh;
	QString gstr="";

	//tesztek:
	lock = sqlh.submit1ResultQuery(QString("SELECT lock FROM %1 WHERE %2=\'%3\';")
										.arg(p_table)
										.arg(p_exp)
										.arg(editedname)
								,"Hiba a templatenevegyezes kideritese alatt.").toBool();

	ok = sqlh.errorStatus();
	if(ok)
	{
		QMessageBox::warning(this,"Hiba","A n�v nem szerepel a rendszerben.\nBels� hiba!");
		return 1;
	}
	if(lock)
	{
		QMessageBox::warning(this,"Figyelmeztet�s","A szerkesztett sablon le van z�rva, nem menthet� el csak m�s n�ven!\nA ment�s megszakadt!");
		return 0;
	}

	sqlh.submit0ResultQuery(QString("UPDATE %1 SET %2=\'%3\' WHERE %4 =\'%5\';")
										.arg(p_table)
										.arg(p_cont)
										.arg(hypdoc->getRawDoc())
										.arg(p_exp)
										.arg(editedname)
		,"Hiba a sablon ment�se alatt");
	if(sqlh.errorStatus())
	{
		QMessageBox::warning(this,"Hiba","A sablon ment�se nem siker�lt...");
	}
	else
	{
		QMessageBox::information(this,"Nyugt�z�s","A ment�s sikeresen lezajlott.");
	}

	return 0;
}

int HyperDocEditSql::saveasReq(void)
{
	bool ok;
	HSqlHandler sqlh;
	QString gstr="";

	do
	{
		QList <QString> expts;
		expts.push_back("Sablonn�v");
		GetTextBox *gtb = new GetTextBox(this,"Mentett n�v megad�sa",QString("Add meg az �j sablonnevet\n(Jelenlegi:%1)").arg(hypdoc->getName()),expts);
		gtb->exec();
		if(gtb->results.size() != 0)
			gstr = gtb->results[0];
		delete gtb;

		if(gstr.isEmpty())
		{
			QMessageBox::warning(this,"Figyelmeztet�s","A n�v amit v�lasztott�l �res. Minden sablont neves�teni kell!\nA ment�s felbe lett szak�tva.");
			return 0;
		}

		//tesztek:
		sqlh.submit1ResultQuery(QString("SELECT * FROM %1 WHERE %2=\'%3\';")
										.arg(p_table)
										.arg(p_exp)
										.arg(gstr)
			,"Hiba a templatenevegyezes kideritese alatt.");

		ok = !sqlh.errorStatus();
		if(ok)
			QMessageBox::warning(this,"Figyelmeztet�s","A n�v amit v�lasztott�l m�r szerepel a rendszerben.\n�rj be egy m�sikat!");
	}
	while(ok);

	sqlh.submit0ResultQuery(QString("INSERT INTO %1(%2,%3) VALUES(\'%4\',\'%5\');")
										.arg(p_table)
										.arg(p_exp)
										.arg(p_cont)
										.arg(gstr)
										.arg(hypdoc->getRawDoc())
		,"Hiba a sablon ment�se alatt");
	if(sqlh.errorStatus())
	{
		QMessageBox::warning(this,"Hiba","A sablon ment�se nem siker�lt...");
	}
	else
	{
		QMessageBox::information(this,"Nyugt�z�s","A ment�s sikeresen lezajlott.");
	}

	editedname = gstr;
	return 0;
}

int HyperDocEditSql::closeReq(void)
{
	return 0;
}

HyperDocEditSql::~HyperDocEditSql(void)
{
	sdebug("*** HyperDocEditSql::~HyperDocEditSql ***");
	sdebug("*** HyperDocEditSql::~HyperDocEditSql ***END");
}

//end code.