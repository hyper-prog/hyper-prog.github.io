/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Info viewer of catalog items (hcinfo.h)
****************************************************************************/

#ifndef CDCAT_HCINFO_H_
#define CDCAT_HCINFO_H_

#include "base.h"

#include <QObject>

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

class DBNode;

class InfoFrame : public QFrame
{
	Q_OBJECT

	private:
		DBNode *a;
		bool type;
		int mx,my;
		int ox,oy;
        
		QColor bgcolor,linecolor,ctxtcolor,vtxtcolor;
		QToolButton *c1t,*c2t;

	public:
		InfoFrame(QWidget *parent);
		~InfoFrame(void);

	public slots:
		int updateColors(void);
		int showNode(DBNode *n,bool pnode);

	protected:
		void paintEvent(QPaintEvent *e);

		void enterEvent(QEvent *e);
		void leaveEvent(QEvent *e);
		void mouseMoveEvent(QMouseEvent *me);
		void mousePressEvent(QMouseEvent *me);
		void mouseReleaseEvent(QMouseEvent *me);
		void resizeEvent(QResizeEvent *re);

};

class HCatInfoDWidget : public QDockWidget
{
	Q_OBJECT

	private:
		InfoFrame *dwf;

	public:
		HCatInfoDWidget(QWidget * parent = 0);
		~HCatInfoDWidget(void);

	public slots:
		int showNode(DBNode *n,bool pnode);

		int ceToolPress(void);
		int coToolPress(void);

	signals:
		void ceEventReq(void);
		void coEventReq(void);

};

#endif
#endif
//end code.
