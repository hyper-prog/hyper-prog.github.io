/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2006 Peter Deak  (hyper80@gmail.com)

	res_p.h
*/

#ifndef GSAFE__RESOURCEPROVIDER_HEADER_FILE_X_
#define GSAFE__RESOURCEPROVIDER_HEADER_FILE_X_

/** Er�forr�sbiztos�t� objektumok defin�ci� */
class ResourceProvider
{
	public:
		virtual QString     getResource(QString rcname) = 0;
		virtual bool        hasResource(QString rcname) = 0;
		virtual QStringList resources  (void)           = 0;

};

#endif
