/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 

  Program Config module (config.h)
****************************************************************************/

#ifndef CDCAT_CONFIG_B_HEADER
#define CDCAT_CONFIG_B_HEADER


#include <QtCore>

#define CT_ERROR  0
#define CT_BOOL   1
#define CT_INT    2
#define CT_STRING 3

class CPair
{
	public:
		int type;
		QString name,cfname;
		QVariant value;
		QVariant def_value;
};

class CConfig : public QObject
{
	private:
		bool mod;
		QString cfile;
		QList<CPair *> sl;

	public:
		bool cerror;
		QString errormsg;

	private:
		void fill_config_data(void);

	public:
		CConfig(void);
		~CConfig(void);

		void addConfigValue(int type,QString name,QVariant v,QString cfname="");

		bool     isConfigVal  (QString value);
		int      getConfigType(QString value);

		QVariant getConfigVal(QString name);
		void     setConfigVal(QString name,QVariant v);

		int readConfig(void);
		int writeConfig(void);
		bool modified(void) { return mod; };

		QString getConfigFileName(void)
			{	return cfile;	};
		void setConfigFileName(QString f)
			{	cfile = f;		};

		virtual void check(void);

		//---

		void addIntConfigValue(QString name,int v,QString cfname="")
			{	addConfigValue(CT_INT   ,name,QVariant(v),cfname); }

		void addStringConfigValue(QString name,QString v,QString cfname="")
			{	addConfigValue(CT_STRING,name,QVariant(v),cfname); }

		void addBoolConfigValue(QString name,bool v,QString cfname="")
			{	addConfigValue(CT_BOOL  ,name,QVariant(v),cfname); }

		//---

		int     getIntConfigVal(QString name)
			{
				if(CT_INT != getConfigType(name)) 
					cerror = true; 
				return getConfigVal(name).toInt();    
			}

		QString getStringConfigVal(QString name)
			{
				if(CT_STRING != getConfigType(name)) 
					cerror = true; 
				return getConfigVal(name).toString(); 
			}

		bool    getBoolConfigVal(QString name)
			{				
				if(CT_BOOL != getConfigType(name)) 
					cerror = true; 
				return getConfigVal(name).toBool();   
			}


		void setIntConfigVal(QString name,int v)
			{	
				if(CT_INT != getConfigType(name)) 
					cerror = true; 
				setConfigVal(name,QVariant(v)); 
			}

		void setStringConfigVal(QString name,QString v)
			{	
				if(CT_STRING != getConfigType(name)) 
					cerror = true; 
				setConfigVal(name,QVariant(v)); 
			}

		void setBoolConfigVal(QString name,bool v)
			{				
				if(CT_BOOL != getConfigType(name)) 
					cerror = true; 
				setConfigVal(name,QVariant(v)); 
			}


};
/*
#include <qstring.h>
#include <qvariant.h>
#include <qobject.h>
#include <qdialog.h>
#include <qstringlist.h>

class QVBoxLayout;

class QHBoxLayout;
class QGridLayout;
class QCheckBox;
class QLineEdit;
class QPushButton;
class DataBase;
class QLabel;
class QWidget;
class CdCatMainWidget;
class QSpinBox;
class QFrame;
class QFont;
class QComboBox;
class QColor;

class CdCatConfig : public QObject
 {
  Q_OBJECT
  public:
   char errormsg[512];

   CdCatConfig(void);

   int startProgram(DataBase **dbp,QWidget *mw);
   int writeConfig();
   int readConfig ();
   void setParameter(char *par);

  public:
  
   bool    startpar;
   QString startfn;
   
   //Configureable items:
   int     fsize;
   int     historysize;
   bool    autoload;
   QString autoloadfn;
   bool    nice;
   bool    autosave;
   bool    ownfont;
   
   bool    readtag;
   bool    v1_over_v2;
   bool    readinfo;
   
   bool    readavii;
   
   bool    readcontent;
   QString readcfiles;
   unsigned long readclimit;
   
   QStringList hlist;
   QSize   windowSize;
   QPoint  windowPos;
   int windowSize_height;
   int windowSize_width;
   QString cdrompath;
   int  mainP1;
   int  mainP2;
   int  mainP3;

   bool find_cs;
   bool find_em;
   bool find_di;
   bool find_fi;
   bool find_co;
   bool find_ct;
   bool find_mco;
   bool find_mar;
   bool find_mti;
   bool find_mal;
   int  findX;
   int  findY;
   int  findWidth;
   int  findHeight;

   QColor *comm_bg,*comm_stext,*comm_vtext,*comm_fr;
   QFont *defaultfont;
#ifndef _WIN32
   bool    mounteject;
#else   
   QString lang;
#endif
   
  bool linkf;

 

 };
*/
#endif
// end code.
