/*
  TreeGenerator
  (OpenGL GLSL Environment generator)

  Copyright (C) Peter Deak (hyper80@gmail.com)
  http://hyperprog.com

  Platform: C++ Qt (http://qt.nokia.com)

  License GPL

  This program is only for test & education pusposely & fun ;-) */
#include "glew/GL/glew.h"

#include "core.h"

#include <QtCore>
#include <QtGui>
#include <QtOpenGL>

#include "core.h"
#include "tree.h"
#include "dconsole.h"

EnvParameters::EnvParameters(void)
{
        tex_ground = 0;
        mask_ground = 0;
        tex_sky = 0;
        mask_sky = 0;

        startx=-1000;
        endx=1000;
        startz=-1000;
        endz=1000;
        partx=100;
        partz=100;
}

TreeParameters::TreeParameters(void)
{
        subtype = 1; //Tree

        deep = 1;
    //default parameters
        startpos.x		=	0;
        startpos.y		=	0;
        startpos.z		=	0;
        treestartpos		=	startpos;

        startdirection.x	=	0;
        startdirection.y	=	1;
        startdirection.z	=	0;

        trunkstartradius	=	12;
        treestartradius		=	trunkstartradius;
        minimumradius		=	1;

        directionVar.x		=	0.01;
        directionVar.y		=	0.0;
        directionVar.z		=	0.0;

        directionVarLength.x    =	0.9;
        directionVarLength.y    =	0.9;
        directionVarLength.z    =	0.9;
        dirGenFactorHeiht	=	500;
        dirGenFactorWidth	=	300;
        dirGenFactorFlat	=	0;

        trunkthinfactor		=	0.96;
        trunkfullness		=	0.5;
        segmentlength		=	2.5;

        rootminheight		=	100;
        minsegmentnum		=	2;
        maxsegmentnum		=	20;
        globalMinBranchLength   =	3;

        branchShorteningFactor  =	0.9;

        hashFactor		=	0.3;
        branchFactor		=	0.6;
        dirChFactor		=	0.004;
        smallBranchEndFactor    =	0.2;

        branchingMinRadFactor	=	0.3;
        branchingMaxRadFactor	=	0.7;
        maxLeafBranchRadius	=	3.0;

        endingBranchRadius	=	1.0;

        leafFactor		=	0.65;

        ttex_fullupnum		=	5;

        maxdeep			=	8;

        rootmaxheight           =       9999;

        knob_plusrad            =       10;
        knob_centerheight       =       30;
        knob_length             =       60;
}

GrassParameters::GrassParameters()
{
        subtype = 2; //Grass

        number			=	6;
        minNumber		=	3;
        maxNumber		=	9;
        dir.x			=	0;
        dir.y			=	1;
        dir.z			=	0;
        sidedir.x		=	1;
        sidedir.y		=	0;
        sidedir.z		=	1;

        height			=	20;
        minHeight		=	15;
        maxHeight		=	40;

        startthick		=	2;
        endthick		=	0.4;
        segmentlength           =	5;

        plusflexfactor          =	2;

        directionVarGenMin.x    =       -0.15;
        directionVarGenMin.y	=       -0.0;
        directionVarGenMin.z	=       -0.15;
        directionVarGenMax.x	=       0.15;
        directionVarGenMax.y	=       0.0;
        directionVarGenMax.z	=       0.15;
}

void GLData::setTextures(int colortex,int masktex)
{
        glActiveTextureARB(GL_TEXTURE0_ARB);
        glBindTexture(GL_TEXTURE_2D, colortex);
        glUniform1i(shader_t1, 0);
        glEnable(GL_TEXTURE_2D);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        //glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

        //glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
        //glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_REPLACE);

        glActiveTextureARB(GL_TEXTURE1_ARB);
        glBindTexture(GL_TEXTURE_2D, masktex);
        glUniform1i(shader_t2, 1);
        glEnable(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);

        //glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
        //glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_INCR);

        glActiveTextureARB(GL_TEXTURE0_ARB);
}

void GrassParameters::resetVarValues(void)
{
        dir.x			=	0;
        dir.y			=	1;
        dir.z			=	0;
        sidedir.x		=	1;
        sidedir.y		=	0;
        sidedir.z		=	1;
}

void TreeGenerator::buildBranch(TreeParameters *p)
{
        int hash;
        int ringpointnum;
        Vertex currCen;
        Vertex currDir;
        Vertex downringCen;
        double currRad;
        double currHeight;
        double down_globalflex=0.0f,up_globalflex=0.0f;
        double plus_radius=0;
        int s,t,next;
        Vertex *upRing = NULL;
        Vertex *downRing = NULL;
        //for tex:
        int tex_rise;
        double tex_t,tex_n,tex_d,tex_u;

        if(p->deep > p->maxdeep)
                return;
        if(p->deep == 1)
        {
                p->treestartpos = p->startpos;
                p->treestartradius = p->trunkstartradius;
                p->treestartdirection = p->startdirection;
        }

        ringpointnum = (int) (p->trunkfullness * p->trunkstartradius);
        if(ringpointnum < 4)
                ringpointnum = 4;
        currCen = &(p->startpos);
        currDir = &(p->startdirection);
        currRad = p->trunkstartradius;
        currDir.normalizeXYZvect();

        hash = 0;
        tex_rise = 0;
        currHeight = 0;
        for(s=0 ; s< ((int)p->maxsegmentnum) ; ++s)
        {
                currDir.x += p->directionVar.x;
                currDir.y += p->directionVar.y;
                currDir.z += p->directionVar.z;
                currDir.normalizeXYZvect();

                if(s==0)
                {
                        //generate first downring
                        downRing = ringGenerator(ringpointnum,&currCen,&currDir,currRad);
                }
                //rising up...
                currRad *= p->trunkthinfactor;
                downringCen = &currCen;
                currCen.addVectWithLength(&currDir,p->segmentlength*currRad);
                currHeight += p->segmentlength*currRad;

                plus_radius=0;
                if(p->deep == 1 && (fabs(currHeight - p->knob_centerheight) < p->knob_length / 2))
                {
                    plus_radius = ((p->knob_length/2) - fabs(currHeight-p->knob_centerheight))  /  (p->knob_length/2) * p->knob_plusrad;
                }

                //generate the higher ring.
                upRing = ringGenerator(ringpointnum,&currCen,&currDir,currRad+plus_radius);

                tex_d = (1.0f / (double)p->ttex_fullupnum) * (double)(tex_rise+0);
                tex_u = (1.0f / (double)p->ttex_fullupnum) * (double)(tex_rise+1);
                tex_rise = (tex_rise + 1) % p->ttex_fullupnum;

                glBegin(GL_TRIANGLES);


                up_globalflex = ( (p->treestartradius - currRad) / p->treestartradius )
                                                        *
                                                ( sqrt( (p->treestartpos.x-currCen.x)*(p->treestartpos.x-currCen.x) + (p->treestartpos.z-currCen.z)*(p->treestartpos.z-currCen.z)) / 100 )
                                                        *
                                                ( (currCen.y-p->treestartpos.y) / 100 );
                if(s==0)
                        down_globalflex = up_globalflex;

                glVertexAttrib1d(gldata->shader_localflex,0.0);
                for(t=0 ; t<ringpointnum ; ++t)
                {
                        if(t != ringpointnum -1)
                                next = t + 1;
                        else
                                next = 0;

                        tex_t = (1.0f / ringpointnum) *  t;
                        tex_n = (1.0f / ringpointnum) * (t+1);

                        glColor3f(1.0,1.0,1.0);

                        downRing[t].setNormalThisMinus(&downringCen);
                        glVertexAttrib1d(gldata->shader_globalflex,down_globalflex);
                        glTexCoord2f(tex_t,tex_d);
                        downRing[t].toOpenGL();

                        upRing[t].setNormalThisMinus(&currCen);
                        glVertexAttrib1d(gldata->shader_globalflex,up_globalflex);
                        glTexCoord2f(tex_t,tex_u);
                        upRing[t].toOpenGL();

                        downRing[next].setNormalThisMinus(&downringCen);
                        glVertexAttrib1d(gldata->shader_globalflex,down_globalflex);
                        glTexCoord2f(tex_n,tex_d);
                        downRing[next].toOpenGL();

                        ++triangles;

                        glColor3f(1.0,1.0,1.0);

                        upRing[next].setNormalThisMinus(&currCen);
                        glVertexAttrib1d(gldata->shader_globalflex,up_globalflex);
                        glTexCoord2f(tex_n,tex_u);
                        upRing[next].toOpenGL();

                        downRing[next].setNormalThisMinus(&downringCen);
                        glVertexAttrib1d(gldata->shader_globalflex,down_globalflex);
                        glTexCoord2f(tex_n,tex_d);
                        downRing[next].toOpenGL();

                        upRing[t].setNormalThisMinus(&currCen);
                        glVertexAttrib1d(gldata->shader_globalflex,up_globalflex);
                        glTexCoord2f(tex_t,tex_u);
                        upRing[t].toOpenGL();

                        ++triangles;
                }
                glVertexAttrib1d(gldata->shader_globalflex,up_globalflex);
                glEnd();

                delete[] downRing;
                downRing = upRing;

                down_globalflex = up_globalflex;

                if(p->deep == 1 && currHeight > p->rootmaxheight)
                {
                    p->endpos = &currCen;
                    p->enddir = &currDir;
                    p->endradius = currRad;
                    if(p->leaftype == 2)
                    {
                        BigLeafParameters *blp = new BigLeafParameters();

                        *blp = *((BigLeafParameters *)(p->leafObject));
                        blp->startpos = &currCen;
                        blp->updir = &currDir;
                        delayed_draw = blp;
                    }
                    return;
                }

                if(currRad <= p->endingBranchRadius)
                {
                        double f0 = (double)(rand()%1000) / 1000.0f;
                        if(f0 < p->smallBranchEndFactor)
                                break;
                }

                if(currRad <= p->maxLeafBranchRadius)
                {
                        double fl = (double)(rand()%1000) / 1000.0f;
                        if(fl < p->leafFactor)
                        {
                                makeLeaf(&(upRing[rand()%ringpointnum]),&currCen,&currDir,up_globalflex,p);
                        }
                }

                if(s*p->segmentlength*currRad > p->globalMinBranchLength*p->trunkstartradius)
                {
                        p->endpos = &currCen;
                        p->enddir = &currDir;
                        p->endradius = currRad;

                        if(p->deep == 1 && p->rootminheight > currHeight)
                                continue;

                        //make hash or branch?
                        if(s > p->minsegmentnum)
                        {
                                double f1 = (double)(rand()%1000) / 1000.0f;
                                if(f1  < p->hashFactor )
                                {
                                        hash = 1;
                                        break;
                                }
                        }

                        //make branch?
                        double f2 = (double)(rand()%1000) / 1000.0f;
                        if( f2 < p->branchFactor )
                        {
                                makeBranch(p);
                                currRad = p->endradius;
                                continue;
                        }


                        //dirchange
                        double f3 = (double)(rand()%1000) / 1000.0f;
                        if( f3 < p->dirChFactor )
                        {
                                makeDirChange(p);
                                continue;
                        }
                }
        }

        delete[] upRing;
        p->endpos = &currCen;
        p->enddir = &currDir;
        p->endradius = currRad;

        if(hash || p->deep == 1 || (currRad > p->maxLeafBranchRadius))
                makeHash(p);
}

void TreeGenerator::makeLeaf(Vertex *leafstartpos,Vertex *branchcenter,Vertex *branchdir,double globalflex,TreeParameters *p)
{
        if(leaf_stack == NULL)
                return;

        LeafParameters *lp = new LeafParameters();

        *lp = *((LeafParameters *)(p->leafObject));

        lp->leafstartpos = leafstartpos;
        lp->branchcenter = branchcenter;
        lp->branchdir	 = branchdir;

        lp->globalflex		 = globalflex;

        leaf_stack->push(lp);
}

void TreeGenerator::generteLeaf(LeafParameters *lp)
{
        Vertex v;
        Vertex nearback;
        Vertex nearfore;
        Vertex farback;
        Vertex farfore;

        v.x = lp->leafstartpos.x - lp->branchcenter.x;
        v.y = lp->leafstartpos.y - lp->branchcenter.y;
        v.z = lp->leafstartpos.z - lp->branchcenter.z;
        v.normalizeXYZvect();

        nearback = lp->leafstartpos;
        nearfore = lp->leafstartpos;
        nearback.addVectWithLength(&(lp->branchdir),-lp->leafWidth/2);
        nearfore.addVectWithLength(&(lp->branchdir), lp->leafWidth/2);

        farback = nearback;
        farfore = nearfore;
        farback.addVectWithLength(&v,lp->leafLength);
        farfore.addVectWithLength(&v,lp->leafLength);

        glBegin(GL_TRIANGLES);

                glVertexAttrib1d(gldata->shader_globalflex,lp->globalflex);

                glVertexAttrib3d(gldata->shader_shakedir,
                                                                                                -1.0f + ((double)(rand()%100) /100.0f) * 2.0f,
                                                                                                -1.0f + ((double)(rand()%100) /100.0f) * 2.0f,
                                                                                                -1.0f + ((double)(rand()%100) /100.0f) * 2.0f
                                                                                        );

                //triangle 1 leaf 1
                glVertexAttrib1d(gldata->shader_localflex,0.0); glTexCoord2f(1.0,0.0);  nearfore.toOpenGL();
                glVertexAttrib1d(gldata->shader_localflex,0.0); glTexCoord2f(0.0,0.0);  nearback.toOpenGL();
                glVertexAttrib1d(gldata->shader_localflex,1.0); glTexCoord2f(0.0,1.0);  farback.toOpenGL();
                        ++triangles;
                //triangle 2 leaf 1
                glVertexAttrib1d(gldata->shader_localflex,0.0); glTexCoord2f(1.0,0.0);  nearfore.toOpenGL();
                glVertexAttrib1d(gldata->shader_localflex,1.0); glTexCoord2f(0.0,1.0);  farback.toOpenGL();
                glVertexAttrib1d(gldata->shader_localflex,1.0); glTexCoord2f(1.0,1.0);  farfore.toOpenGL();
                        ++triangles;

                glVertexAttrib3d(gldata->shader_shakedir,0,0,0);

                glVertexAttrib1d(gldata->shader_localflex,0.0);

        glEnd();
}

void TreeGenerator::makeHash(TreeParameters *p)
{
        Vertex *cdir;
        double hs;
        if(branch_stack == NULL)
                return;

        TreeParameters *a = new TreeParameters();
        TreeParameters *b = new TreeParameters();

        *a = *p;						*b = *p;
        a->startpos = &p->endpos;		b->startpos = &p->endpos;
        a->startdirection = &p->enddir;	b->startdirection = &p->enddir;

        a->minsegmentnum = p->minsegmentnum * p->branchShorteningFactor;
        b->minsegmentnum = p->minsegmentnum * p->branchShorteningFactor;

        cdir = getRandomDirection(&p->enddir,&p->directionVarLength,&p->endpos,&p->treestartpos,p->endradius, p->dirGenFactorHeiht,p->dirGenFactorWidth,p->dirGenFactorFlat);
        a->directionVar = cdir;
        delete cdir;

        cdir = getRandomDirection(&p->enddir,&p->directionVarLength,&p->endpos,&p->treestartpos,p->endradius, p->dirGenFactorHeiht,p->dirGenFactorWidth,p->dirGenFactorFlat);
        b->directionVar = cdir;
        delete cdir;

        hs = 0.4f + ((double)(rand()%1000)/1000) * 0.2f;

        a->trunkstartradius = sqrt(p->endradius *1.3 * p->endradius * 1.3 * hs);
        b->trunkstartradius = sqrt(p->endradius *1.3 * p->endradius * 1.3 * (1.0f-hs));

        a->deep++;
        b->deep++;

        branch_stack->push(a);
        branch_stack->push(b);
}

void TreeGenerator::makeBranch(TreeParameters *p)
{
        Vertex *cdir;
        if(branch_stack == NULL)
                return;

        TreeParameters *a = new TreeParameters();

        *a = *p;
        a->startpos = &p->endpos;
        a->startdirection = &p->enddir;

        a->minsegmentnum = p->minsegmentnum * p->branchShorteningFactor;

        cdir = getRandomDirection(&p->enddir,&p->directionVarLength,&p->endpos,&p->treestartpos,p->endradius, p->dirGenFactorHeiht,p->dirGenFactorWidth,p->dirGenFactorFlat);
        a->directionVar = cdir;
        delete cdir;

        double minr = p->endradius*p->branchingMinRadFactor;
        double maxr = p->endradius*p->branchingMaxRadFactor;

        if(minr < p->minimumradius)
                minr = p->minimumradius;

        a->trunkstartradius = minr + ((double)(rand()%1000)/1000) * (maxr - minr);

        p->endradius = sqrt(((p->endradius*p->endradius*M_PI)-(0.5*a->trunkstartradius*0.5*a->trunkstartradius*M_PI))/M_PI);
        if(p->endradius < p->minimumradius)
                p->endradius = p->minimumradius;

        a->deep++;

        branch_stack->push(a);
}

void TreeGenerator::makeDirChange(TreeParameters *p)
{
        Vertex *cdir;

        cdir = getRandomDirection(&p->enddir,&p->directionVarLength,&p->endpos,&p->treestartpos,p->endradius, p->dirGenFactorHeiht,p->dirGenFactorWidth,p->dirGenFactorFlat);
        p->directionVar = cdir;
        delete cdir;
}

void TreeGenerator::buildTree(TreeParameters *p)
{
        delayed_draw = NULL;
        TreeParameters *rootp = new TreeParameters(); //i don't want to delete the parameter at the end
        *rootp = *p;

        branch_stack = new stack<TreeParameters *>();
        leaf_stack   = new stack<LeafParameters *>();
        branch_stack->push(rootp);

        gldata->setTextures(p->tex_trunk,p->mask_trunk);
        while(!branch_stack->empty())
        {
                TreeParameters *bp = branch_stack->top();
                branch_stack->pop();
                buildBranch(bp);
                delete bp;
        }

        gldata->setTextures(p->tex_leaf,p->mask_leaf);
        while(!leaf_stack->empty())
        {
                LeafParameters *lp = leaf_stack->top();
                leaf_stack->pop();
                generteLeaf(lp);
                delete lp;
        }
        if(delayed_draw != NULL)
        {
            generateBigLeaf(delayed_draw);
            delete delayed_draw;
            delayed_draw = NULL;
        }

        delete branch_stack;
        branch_stack = NULL;
        delete leaf_stack;
        leaf_stack = NULL;
}

/// SKY /////////////////////////////////////////////////////////////////////////////////////////////////
void TreeGenerator::buildSky(EnvParameters *ep)
{
        gldata->setTextures(ep->tex_sky,ep->mask_sky);
        glDisable(GL_DEPTH_TEST);
        glBegin(GL_QUADS);
                glNormal3d(0,0,1);
                glTexCoord2f(0,0); glVertex3f(-1000,0,-400);
                glTexCoord2f(1,0); glVertex3f(1000,0,-400);
                glTexCoord2f(1,1); glVertex3f(1000,2000,-400);
                glTexCoord2f(0,1); glVertex3f(-1000,2000,-400);
        glEnd();
        glEnable(GL_DEPTH_TEST);
}
/// GROUND /////////////////////////////////////////////////////////////////////////////////////////////////

void TreeGenerator::buildGround(EnvParameters *ep)
{
        int x,z;
        int xs,zs;

        xs = ep->partx;
        zs = ep->partz;


        gldata->setTextures(ep->tex_ground,ep->mask_ground);
        glBegin(GL_TRIANGLES);
        glVertexAttrib1d(gldata->shader_globalflex,0.0);
        glVertexAttrib1d(gldata->shader_localflex,0.0);
        for(x = ep->startx;x < ep->endx;x+=xs)
                for(z = ep->startz;z < ep->endz;z+=zs)
                {
                        glNormal3d(0.0f,1.0f,0.0f);
                        glTexCoord2f(0.0f,0.0f);	glVertex3d(x,0,z);
                        glTexCoord2f(1.0f,1.0f);	glVertex3d(x+xs,0,z+zs);
                        glTexCoord2f(0.0f,1.0f);	glVertex3d(x,0,z+zs);
                        ++triangles;

                        glNormal3d(0.0f,1.0f,0.0f);
                        glTexCoord2f(0.0f,0.0f);	glVertex3d(x,0,z);
                        glTexCoord2f(1.0f,0.0f);	glVertex3d(x+xs,0,z);
                        glTexCoord2f(1.0f,1.0f);	glVertex3d(x+xs,0,z+zs);
                        ++triangles;

                }
        glEnd();
}

/// GRASS ///////////////////////////////////////////////////////////////////////////////////////////////////

void GrassParameters::genVar(void)
{
        directionVar.x = directionVarGenMin.x + ((double)(rand()%1000)/1000) * (directionVarGenMax.x - directionVarGenMin.x);
        directionVar.y = directionVarGenMin.y + ((double)(rand()%1000)/1000) * (directionVarGenMax.y - directionVarGenMin.y);
        directionVar.z = directionVarGenMin.z + ((double)(rand()%1000)/1000) * (directionVarGenMax.z - directionVarGenMin.z);
}

void GrassParameters::genSideDir(void)
{
        double degree = ((double)(rand()%1000)/1000) * 360;
        sidedir.x		=	sin(degree * (2*M_PI / 360.0f));
        sidedir.y		=	0;
        sidedir.z		=	cos(degree * (2*M_PI / 360.0f));
        sidedir.normalizeXYZvect();
}

void GrassParameters::genHeight(void)
{
        height = minHeight + ((double)(rand()%1000)/1000) * (maxHeight - minHeight);
}


void GrassParameters::genNumber(void)
{
        number = minNumber + rand()%(maxNumber - minNumber);
}

void TreeGenerator::generateGrass(GrassParameters *gp)
{
        int i;
        for(i=0;i<gp->number;++i)
        {
                gp->genAll();
                generateSingleGrass(gp);
        }
}

void TreeGenerator::generateSingleGrass(GrassParameters *gp)
{
        int s;
        Vertex currPos;
        Vertex pd,pu;
        double currThick;
        double thickFactor;
        double curr_globalflex,oldcurr_globalflex,pd_globalflex,pu_globalflex;
        double grasslength;

        gp->dir.normalizeXYZvect();
        gp->sidedir.normalizeXYZvect();
        thickFactor = (gp->startthick - gp->endthick) / (gp->height / gp->segmentlength);
        currPos = &(gp->startpos);
        currThick = gp->startthick;
        grasslength = 0.0f;


        glBegin(GL_TRIANGLES);
    for(s=0 ; grasslength <= gp->height ; ++s)
        {
                if(s == 0)
                {
                        pd=currPos;
                        pd.addVectWithLength(&(gp->sidedir),currThick);

                        pu = currPos;
                        pu.addVectWithLength(&(gp->dir),gp->segmentlength / 2);
                        pu.addVectWithLength(&(gp->sidedir),currThick);
                        //flex
                        curr_globalflex = fabs(currPos.y - gp->startpos.y) / gp->height;
                        pd_globalflex	= fabs(pd.y - gp->startpos.y) / gp->height;
                        pu_globalflex	= fabs(pu.y - gp->startpos.y) / gp->height;
                        curr_globalflex = curr_globalflex * curr_globalflex * gp->plusflexfactor;
                        pd_globalflex	= pd_globalflex * pd_globalflex * gp->plusflexfactor;
                        pu_globalflex	= pu_globalflex * pu_globalflex * gp->plusflexfactor;
                        //end flex

                        setNormalFrom3Vertex(&currPos,&pd,&pu);

                        glTexCoord2f(1.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);	currPos.toOpenGL();
                        glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pd_globalflex);		pd.toOpenGL();
                        glTexCoord2f(0.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,pu_globalflex);		pu.toOpenGL();

                }

                if(s!= 0 && s%2 == 1)
                {
                        Vertex oldCurr;

                        oldCurr = currPos;
                        currPos.addVectWithLength(&(gp->dir),gp->segmentlength);
                        grasslength += gp->segmentlength;
                        //flex
                        oldcurr_globalflex	= fabs(oldCurr.y - gp->startpos.y) / gp->height;
                        pu_globalflex		= fabs(pu.y - gp->startpos.y) / gp->height;
                        curr_globalflex		= fabs(currPos.y - gp->startpos.y) / gp->height;
                        oldcurr_globalflex	= oldcurr_globalflex * oldcurr_globalflex * gp->plusflexfactor;
                        pu_globalflex		= pu_globalflex * pu_globalflex * gp->plusflexfactor;
                        curr_globalflex		= curr_globalflex * curr_globalflex * gp->plusflexfactor;
                        //end flex

                        setNormalFrom3Vertex(&oldCurr,&pu,&currPos);
                        glTexCoord2f(1.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,oldcurr_globalflex);oldCurr.toOpenGL();
                        glTexCoord2f(0.0f,0.5f); glVertexAttrib1d(gldata->shader_globalflex,pu_globalflex);		pu.toOpenGL();
                        glTexCoord2f(1.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);	currPos.toOpenGL();
                        pd = pu;
                }

                if(s!= 0 && s%2 == 0)
                {
                        pu = currPos;
                        pu.addVectWithLength(&(gp->dir),gp->segmentlength / 2);
                        pu.addVectWithLength(&(gp->sidedir),currThick);
                        //flex
                        curr_globalflex = fabs(currPos.y - gp->startpos.y) / gp->height;
                        pd_globalflex	= fabs(pd.y - gp->startpos.y) / gp->height;
                        pu_globalflex	= fabs(pu.y - gp->startpos.y) / gp->height;
                        curr_globalflex	= curr_globalflex * curr_globalflex * gp->plusflexfactor;
                        pd_globalflex	= pd_globalflex * pd_globalflex * gp->plusflexfactor;
                        pu_globalflex	= pu_globalflex * pu_globalflex * gp->plusflexfactor;
                        //end flex

                        setNormalFrom3Vertex(&currPos,&pd,&pu);
                        glTexCoord2f(1.0f,0.5f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);	currPos.toOpenGL();
                        glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pd_globalflex);		pd.toOpenGL();
                        glTexCoord2f(0.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,pu_globalflex);		pu.toOpenGL();
                }

                ++triangles;

                if(s%2 == 0)
                {
                        currThick -= thickFactor;

                        gp->dir.x += gp->directionVar.x;
                        gp->dir.y += gp->directionVar.y;
                        gp->dir.z += gp->directionVar.z;
                        gp->dir.normalizeXYZvect();
                }
        }

        glVertexAttrib1d(gldata->shader_globalflex,0.0f);
        glEnd();
}

void TreeGenerator::buildGrass(GrassParameters *gp)
{
        int i,n;
        n = (int) (fabs((gp->ex - gp->sx)*(gp->ex - gp->sz))*gp->density);
        gldata->setTextures(gp->tex_grass,gp->mask_grass);
        for(i=0;i<n;++i)
        {
                gp->startpos.x = gp->sx + ((double)(rand()%10000) / 10000) * (gp->ex - gp->sx);
                gp->startpos.z = gp->sz + ((double)(rand()%10000) / 10000) * (gp->ex - gp->sz);
                gp->startpos.y = gp->y;
                generateGrass(gp);
        }
}


BigLeafParameters::BigLeafParameters(void)
{
        texmode			=	TEXMODE_FULL;
        number			=	6;
        minNumber		=	4;
        maxNumber		=	7;

        startpos.x		=	0;
        startpos.y		=	100;
        startpos.z		=	0;

        updir.x			=	0;
        updir.y			=	1;
        updir.z			=	0;

        leandir.x		=	1;
        leandir.y		=	0;
        leandir.z		=	1;

        alpha			=	25;
        beta			=	25;
        startangle		=	75;
        minStartangle	=	60;
        maxStartangle	=	85;
        endangle		=	-30;
        minEndangle		=	-50;
        maxEndangle		=	-20;
        minLength		=	80;
        maxLength		=	160;
        length			=	100;
        width			=	50;

        segmentlength	=	20;

        plusflexfactor_all = 1;
        plusflexfactor_leafend = 1.0;
};

void BigLeafParameters::resetVarValues(void)
{
        leandir.x		=	1;
        leandir.y		=	0;
        leandir.z		=	1;
}

void BigLeafParameters::genAngles()
{
        startangle = minStartangle + ((double)(rand()%1000)/1000) * (maxStartangle - minStartangle);
        endangle   = minEndangle + ((double)(rand()%1000)/1000) * (maxEndangle - minEndangle);
}


void BigLeafParameters::genLeanDir(void)
{
        double degree = ((double)(rand()%1000)/1000) * 360;
        leandir.x		=	sin(degree * (2*M_PI / 360.0f));
        leandir.y		=	0;
        leandir.z		=	cos(degree * (2*M_PI / 360.0f));
        leandir.normalizeXYZvect();
}

void BigLeafParameters::genLength(void)
{
        length = minLength + ((double)(rand()%1000)/1000) * (maxLength - minLength);
}

void BigLeafParameters::genNumber(void)
{
        number = minNumber + rand()%(maxNumber - minNumber);
}

void TreeGenerator::generateBigLeaf(BigLeafParameters *lp)
{
        int i,m;
        lp->genAll();

        m = lp->number;
        gldata->setTextures(lp->tex_leaf,lp->mask_leaf);
        for(i=0;i<m;++i)
        {
                lp->resetVarValues();
                lp->genLeanDir();
                lp->genLength();
                lp->genAngles();
                generateSingleBigLeaf(lp);
        }
}

void TreeGenerator::generateSingleBigLeaf(BigLeafParameters *lp)
{
        int s,snum;
        double realsegmentlength;
        Vertex currPos;

        Vertex currTangentDir;
        Vertex varDir;

        Vertex left;
        Vertex right;

        snum = (int)(lp->length / lp->segmentlength);
        realsegmentlength = (double)lp->length / (double)snum;

        lp->updir.normalizeXYZvect();
        lp->updir.normalizeXYZvect();
        lp->leandir.normalizeXYZvect();
        lp->leandir.normalizeXYZvect();

        { //calculating left,right
                Vertex v1;
                Vertex v2;
                v1 = lp->startpos;
                v2 = lp->startpos;
                v1.addVectWithLength(&lp->updir,1.0f);
                v2.addVectWithLength(&lp->leandir,1.0f);

                Vertex *vp = normalFrom3Vertex(&lp->startpos,&v1,&v2);
                left = vp;
                right = vp;
                delete vp;
                right.x *= -1;
                right.y *= -1;
                right.z *= -1;
        }

        { //calculating start currDir(startDir), /endDir/ varDir
                double sin_result;
                double cos_result;
                Vertex endDir;

                sin_result = sin(lp->startangle * ((2*M_PI)/360.0f));
                cos_result = cos(lp->startangle * ((2*M_PI)/360.0f));
                currTangentDir.x = lp->updir.x * sin_result +  lp->leandir.x * cos_result;
                currTangentDir.y = lp->updir.y * sin_result +  lp->leandir.y * cos_result;
                currTangentDir.z = lp->updir.z * sin_result +  lp->leandir.z * cos_result;

                sin_result = sin(lp->endangle * ((2*M_PI)/360.0f));
                cos_result = cos(lp->endangle * ((2*M_PI)/360.0f));
                endDir.x = lp->updir.x * sin_result +  lp->leandir.x * cos_result;
                endDir.y = lp->updir.y * sin_result +  lp->leandir.y * cos_result;
                endDir.z = lp->updir.z * sin_result +  lp->leandir.z * cos_result;

                currTangentDir.normalizeXYZvect();
                endDir.normalizeXYZvect();

                if(snum > 1)
                {
                        varDir.x = (endDir.x - currTangentDir.x) / (snum - 1);
                        varDir.y = (endDir.y - currTangentDir.y) / (snum - 1);
                        varDir.z = (endDir.z - currTangentDir.z) / (snum - 1);
                }
        }

        currPos = &(lp->startpos);

        double alpha_sin_result = sin(lp->alpha * ((2*M_PI)/360.0f));
        double beta_sin_result  = sin(lp->beta * ((2*M_PI)/360.0f));
        double alpha_cos_result = cos(lp->alpha * ((2*M_PI)/360.0f));
        double beta_cos_result  = cos(lp->beta * ((2*M_PI)/360.0f));

        double curr_globalflex=0;
        Vertex downVec;
        Vertex lV;
        Vertex rV;
        Vertex nextPos;
        Vertex lP;
        Vertex rP;
        Vertex lnP;
        Vertex rnP;

        double pre_curr_globalflex=0;
        Vertex pre_currPos;
        Vertex pre_downVec;
        Vertex pre_rP;
        Vertex pre_lP;

        glBegin(GL_TRIANGLES);
        for(s=0 ; s <= snum ; ++s)
        {
                //calculating downVec
                Vertex leftpoint,rightpoint;
                leftpoint = &currPos;   leftpoint.addVectWithLength(&left,1.0f);
                nextPos = &currPos;
                nextPos.addVectWithLength(&currTangentDir,1.0f);
                Vertex *dv = normalFrom3Vertex(&currPos,&leftpoint,&nextPos);
                downVec = dv;
                delete dv;


                downVec.normalizeXYZvect();

                //calculating lV rV lP rP
                rV.x = right.x * alpha_cos_result + downVec.x * alpha_sin_result;
                rV.y = right.y * alpha_cos_result + downVec.y * alpha_sin_result;
                rV.z = right.z * alpha_cos_result + downVec.z * alpha_sin_result;
                rP = &currPos;
                rP.addVectWithLength(&rV,lp->width / 2.0f);
                lV.x = left.x * beta_cos_result + downVec.x * beta_sin_result;
                lV.y = left.y * beta_cos_result + downVec.y * beta_sin_result;
                lV.z = left.z * beta_cos_result + downVec.z * beta_sin_result;
                lP = &currPos;
                lP.addVectWithLength(&lV,lp->width / 2.0f);

                if(s != 0) //not in the first step (there isn't pre_* values)
                {
                        //flex
                        curr_globalflex = ((double)s / (double)snum) * lp->plusflexfactor_all;
                        //end flex

                        //setNormalFrom3Vertex(&currPos,&pd,&pu);
                        if(lp->texmode == TEXMODE_PART)
                        {
                                glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_lP.toOpenGL();
                                glTexCoord2f(0.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		lP.toOpenGL();
                                glTexCoord2f(1.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		currPos.toOpenGL();

                                glTexCoord2f(1.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_currPos.toOpenGL();
                                glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_lP.toOpenGL();
                                glTexCoord2f(1.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		currPos.toOpenGL();

                                glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_rP.toOpenGL();
                                glTexCoord2f(1.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_currPos.toOpenGL();
                                glTexCoord2f(1.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		currPos.toOpenGL();

                                glTexCoord2f(0.0f,1.0f); glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);	pre_rP.toOpenGL();
                                glTexCoord2f(1.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		currPos.toOpenGL();
                                glTexCoord2f(0.0f,0.0f); glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);		rP.toOpenGL();
                        }
                        if(lp->texmode == TEXMODE_FULL)
                        {
                                double lef = lp->plusflexfactor_leafend;
                                double tx_lp,tx_curr,tx_rp;
                                double ty_precurr,ty_curr;

                                tx_lp = 0.0f; tx_curr = 0.5f; tx_rp = 1.0;

                                ty_curr = (1.0f / ((double)snum)) * (s);
                                ty_precurr = (1.0f / ((double)snum)) * (s-1);

                                glTexCoord2f(tx_lp  ,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex*lef);	pre_lP.toOpenGL();
                                glTexCoord2f(tx_lp  ,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex*lef);		lP.toOpenGL();
                                glTexCoord2f(tx_curr,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);			currPos.toOpenGL();

                                glTexCoord2f(tx_curr,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);		pre_currPos.toOpenGL();
                                glTexCoord2f(tx_lp  ,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex*lef);	pre_lP.toOpenGL();
                                glTexCoord2f(tx_curr,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);			currPos.toOpenGL();

                                glTexCoord2f(tx_rp  ,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex*lef);	pre_rP.toOpenGL();
                                glTexCoord2f(tx_curr,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex);		pre_currPos.toOpenGL();
                                glTexCoord2f(tx_curr,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);			currPos.toOpenGL();

                                glTexCoord2f(tx_rp  ,ty_precurr);	glVertexAttrib1d(gldata->shader_globalflex,pre_curr_globalflex*lef);	pre_rP.toOpenGL();
                                glTexCoord2f(tx_curr,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex);			currPos.toOpenGL();
                                glTexCoord2f(tx_rp  ,ty_curr);		glVertexAttrib1d(gldata->shader_globalflex,curr_globalflex*lef);		rP.toOpenGL();
                        }

                }

                pre_curr_globalflex = curr_globalflex;
                pre_currPos = &currPos;
                pre_downVec = &downVec;
                pre_rP = &rP;
                pre_lP = &lP;
                currPos.addVectWithLength(&currTangentDir,realsegmentlength);
                currTangentDir.add(&varDir);
        }


        glVertexAttrib1d(gldata->shader_globalflex,0.0f);
        glEnd();
}

//End code.
