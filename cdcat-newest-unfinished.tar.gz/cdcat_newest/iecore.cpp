/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 

  Import Export Core module (iecore.cpp)
****************************************************************************/

#include <QtCore>

#include "iecore.h"
#include "dbase.h"

/***************************************************************************
 * DBExportEngine class                                                    *
 ***************************************************************************/

DBExportEngine::DBExportEngine(DataBase *database)
{
	db = database;
	out = NULL;
	cR = true;
	tR = true;
	dR = true;
	sR = true;
	fR = true;
	s1R = true;
	s2R = true;
	medial = "";
	stack = NULL;
}

DBExportEngine::~DBExportEngine(void)
{
	db = NULL;
}

int DBExportEngine::writeDB(QString file,int mode,bool monly,QString medialist,QString show)
{
	if(db == NULL || db->getRootNode() == NULL )
	{
		errormsg = " Internal error ";
		return 1;
	}

	//F(files) C(comments) T(tags) D(dates) S(size)
	if(show.contains(QChar('c'),Qt::CaseInsensitive))	cR   = true; else cR  = false;
	if(show.contains(QChar('t'),Qt::CaseInsensitive))	tR   = true; else tR  = false;
	if(show.contains(QChar('d'),Qt::CaseInsensitive))	dR   = true; else dR  = false;
	if(show.contains(QChar('s'),Qt::CaseInsensitive))	sR   = true; else sR  = false;
	if(show.contains(QChar('f'),Qt::CaseInsensitive))	fR   = true; else fR  = false;
	if(show.contains(QChar('1'),Qt::CaseInsensitive))	s1R  = true; else s1R = false;
	if(show.contains(QChar('2'),Qt::CaseInsensitive))	s2R  = true; else s2R = false;

	m = mode;
	mo = monly;
	medial = medialist;
	QFile f(file);
	if(!(f.open(QIODevice::WriteOnly | QIODevice::Text )))
	{
		errormsg = QObject::tr( "I can't create or rewrite the file" );
		return 1;
	}
	out = new QTextStream(&f);
	//Write down...
	stack = new QStack<DBNode *>();
	stack->push(db->getRootNode());

	if(m == EXP_HTML)
	{
		out->setCodec("UTF-8");
		*out << "<html>"<<endl;
		*out << "<head>"<<endl;
		*out << "	<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">"<<endl;
		*out << "	<title>CdCat html export - "<< db->getDBName() <<"</title>"<<endl;
		*out << "</head>" <<endl;
		*out << "<body>" <<endl;
		*out << "<h2>CdCat html export - "<<db->getDBName()<<"</h2>" <<endl;
		*out << "<table>" <<endl;

		while(!stack->isEmpty())
            doHtml();


		*out << "</table>The end." <<endl;
		*out << "</body></html>" <<endl;
	}

	if(m == EXP_TXT)
	{
		while(!stack->isEmpty())
			doTxt();
	}

	if(m == EXP_CSV)
	{
		while(!stack->isEmpty())
			doCsv();
	}

	
	delete out;
	delete stack;
	out = NULL;
	f.close();
	return 0;
}


#define CATALOGCOLOR   "#88FF88" 
#define MEDIACOLOR     "#FF9999" 
#define DIRECTORYCOLOR "#FFFF00" 
#define FILECOLOR      "#BBDDFF" 
#define COMMENTCOLOR   "#FFFFFF" 
#define TAGCOLOR       "#F0F0F0" 

int DBExportEngine::doHtml(void)
{
	QString s;

	DBNode *act = stack->pop();

	if(act == NULL)
		return 0;

	//Do we need to export this media?
	if(	act->type == HC_MEDIA && // ==> it is a media
		!medial.isEmpty()     && // ==> and there is a restriction of the media names   
		!((medial.split(QChar(';'),QString::SkipEmptyParts))
			.contains(act->getNameOf())) ) // ==> this media is not in the list...
				{

					stack->push(act->next);
					return 0; //Skip this media!
				}

	if(!fR && act->type == HC_FILE)
	{
		stack->push(act->next);
		return 0;
	}

	*out << "<tr bgcolor=\"";
		if(act->type == HC_CATALOG)		*out << CATALOGCOLOR;
		if(act->type == HC_MEDIA)		*out << MEDIACOLOR;
		if(act->type == HC_DIRECTORY)	*out << DIRECTORYCOLOR;
		if(act->type == HC_FILE)		*out << FILECOLOR;
	*out << "\"><td colspan=2>";


	if(act->type == HC_DIRECTORY)
		*out << act->getFullPath();
	else if(act->type == HC_MEDIA)
		*out << "<strong>" << act->getNameOf() << "</strong>";
	else
		*out << act->getNameOf();


	*out << "</td><td>";
		if(act->type == HC_CATALOG)		
			*out << "CATALOG";
		if(act->type == HC_MEDIA)		
			*out << "<BR/>MEDIA " << (qobject_cast<DBMedia *>(act->DBdata))->number <<" ("
				 << (qobject_cast<DBMedia *>(act->DBdata))->getMTypeName() <<")<BR/>";
		if(act->type == HC_DIRECTORY)	
			*out << "DIR";
		if(act->type == HC_FILE)		
		{
			if(sR)
				*out << (qobject_cast<DBFile *>(act->DBdata))->getSizeString();
			else
				*out << "FILE";
		}
	*out << "</td>"<<endl;

	if(dR)
	{
        switch(act->type)
		{
			case HC_CATALOG:
					*out << "<td>"<<(qobject_cast<DBCatalog *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"</td>"<<endl;
				break;
			case HC_MEDIA:
					*out << "<td>"<<(qobject_cast<DBMedia *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"</td>"<<endl;
				break;
			case HC_DIRECTORY:
					*out << "<td>"<<(qobject_cast<DBDirectory *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"</td>"<<endl;
				break;
			case HC_FILE:
				*out << "<td>"<<(qobject_cast<DBFile *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"</td>"<<endl;
				break;
		}
	}

	*out << "</tr>"<<endl;

	switch(act->type)
	{
		case HC_CATALOG:
			if(cR)
			{
				s = (qobject_cast<DBCatalog *>(act->DBdata))->comment;
				if(!s.isEmpty())
					*out << "<tr bgcolor=\""<< COMMENTCOLOR <<"\"><td>&nbsp;</td><td colspan=2>"
					<< s.replace("#","<br/>") <<"</td></tr>"<<endl;
			}
			break;
		case HC_MEDIA:
			if(cR)
			{
				s = (qobject_cast<DBMedia *>(act->DBdata))->comment;
				if(!s.isEmpty())
					*out << "<tr bgcolor=\""<< COMMENTCOLOR <<"\"><td>&nbsp;</td><td colspan=2>"
					<< s.replace("#","<br/>") <<"</td></tr>"<<endl;
			}
			break;
		case HC_DIRECTORY:
				
			if(cR)
			{
				s = (qobject_cast<DBDirectory *>(act->DBdata))->comment;
				if(!s.isEmpty())
					*out << "<tr bgcolor=\""<< COMMENTCOLOR <<"\"><td>&nbsp;</td><td colspan=2>"
					<< s.replace("#","<br/>") <<"</td></tr>"<<endl;
			}
			break;
		case HC_FILE:
			if(tR)
			{
				DBNode *sub = (qobject_cast<DBFile *>(act->DBdata))->prop;
				for(;sub != NULL;sub = sub->next)
					if(sub->type == HC_MP3TAG)
					{
						*out << "<tr><td>&nbsp;</td><td bgcolor=\""<< TAGCOLOR 
							<<"\" colspan=2>&nbsp;&nbsp;Artist: <strong>"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->artist<<"</strong></td></tr>"<<endl;
						*out << "<tr><td>&nbsp;</td><td bgcolor=\""<< TAGCOLOR 
							<<"\" colspan=2>&nbsp;&nbsp;Title: <strong>"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->title<<"</strong></td></tr>"<<endl;
						*out << "<tr><td>&nbsp;</td><td bgcolor=\""<< TAGCOLOR 
							<<"\" colspan=2>&nbsp;&nbsp;Album: <strong>"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->album<<"</strong></td></tr>"<<endl;
						*out << "<tr><td>&nbsp;</td><td bgcolor=\""<< TAGCOLOR 
							<<"\" colspan=2>&nbsp;&nbsp;Comment: <strong>"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->comment<<"</strong></td></tr>"<<endl;
						*out << "<tr><td>&nbsp;</td><td bgcolor=\""<< TAGCOLOR 
							<<"\" colspan=2>&nbsp;&nbsp;Track/Year: <strong>"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->track
							<<"/"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->year<<"</strong></td></tr>"<<endl;
					}
			}
			if(cR)
			{
				s = (qobject_cast<DBFile *>(act->DBdata))->comment;
				if(!s.isEmpty())
					*out << "<tr bgcolor=\""<< COMMENTCOLOR <<"\"><td>&nbsp;</td><td colspan=2>"
					<< s.replace("#","<br/>") <<"</td></tr>"<<endl;
			}
			break;
	}

	*out  <<endl;

	stack->push(act->next);
	if(act->type != HC_MEDIA || !mo)
		stack->push(act->child);
	return 0;
}

int DBExportEngine::doTxt(void)
{
	DBNode *act = stack->pop();

	if(act == NULL)
		return 0;

	//Do we need to export this media?
	if(	act->type == HC_MEDIA && // ==> it is a media
		!medial.isEmpty()     && // ==> and there is a restriction of the media names   
		!((medial.split(QChar(';'),QString::SkipEmptyParts))
			.contains(act->getNameOf())) ) // ==> this media is not in the list...
				{
					stack->push(act->next); //Skip this media!
					return 0;
				}

	if(!fR)
	{
		if(act->type == HC_FILE)
		{
			stack->push(act->next);
			return 0;
		}
	}
	else
	{
		if(act->type == HC_DIRECTORY)
		{
			stack->push(act->next);
			stack->push(act->child);
			return 0;
		}
	}

	if(act->type == HC_CATALOG)		
		*out << "CATALOG   : ";
	if(act->type == HC_MEDIA)		
		*out << "MEDIA     : (" << (qobject_cast<DBMedia *>(act->DBdata))->getMTypeName() <<") ";
	if(act->type == HC_DIRECTORY)	
		*out << "DIRECTORY : ";

	*out << act->getFullPath();

	if(act->type == HC_FILE)		
	{
		if(sR)
			*out << " ("<< (qobject_cast<DBFile *>(act->DBdata))->getSizeString()<<") ";
	}

	if(dR)
	{
        switch(act->type)
		{
			case HC_CATALOG:
				*out << " {"<<(qobject_cast<DBCatalog *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"} "<<endl;
				break;
			case HC_MEDIA:
				*out << " {"<<(qobject_cast<DBMedia *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"} "<<endl;
				break;
			case HC_DIRECTORY:
				*out << " {"<<(qobject_cast<DBDirectory *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"} "<<endl;
				break;
			case HC_FILE:
				*out << " {"<<(qobject_cast<DBFile *>(act->DBdata))->modification.toString(Qt::LocalDate)<<"} "<<endl;
				break;
		}
	}
	else
	{
		*out << endl;
	}

	switch(act->type)
	{
		case HC_CATALOG:
			if(cR)
				if(!(qobject_cast<DBCatalog *>(act->DBdata))->comment.isEmpty())
					*out << "           COMMENT : "<<(qobject_cast<DBCatalog *>(act->DBdata))->comment<<endl;
			break;
		case HC_MEDIA:
			if(cR)
				if(!(qobject_cast<DBMedia *>(act->DBdata))->comment.isEmpty())
					*out << "           COMMENT : "<<(qobject_cast<DBMedia *>(act->DBdata))->comment<<endl;
			break;
		case HC_DIRECTORY:
			if(cR)
				if(!(qobject_cast<DBDirectory *>(act->DBdata))->comment.isEmpty())
					*out << "           COMMENT : "<<(qobject_cast<DBDirectory *>(act->DBdata))->comment<<endl;
			break;
		case HC_FILE:
			if(tR)
			{
				DBNode *sub = (qobject_cast<DBFile *>(act->DBdata))->prop;
				for(;sub != NULL;sub = sub->next)
					if(sub->type == HC_MP3TAG)
					{
						*out << "           Artist : "<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->artist<<endl;
						*out << "           Title  : "<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->title<<endl;
						*out << "           Album  : "<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->album<<endl;
						*out << "           Comment: "<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->comment<<endl;
						*out << "           Tck/Yea: "<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->track
							<<"/"<<(qobject_cast<DBMp3Tag *>(sub->DBdata))->year<<endl;
					}
			}
			if(cR)
				if(!(qobject_cast<DBFile *>(act->DBdata))->comment.isEmpty())
					*out << "           COMMENT : "<<(qobject_cast<DBFile *>(act->DBdata))->comment<<endl;
			break;
	}

	stack->push(act->next);
	if(act->type != HC_MEDIA || !mo)
		stack->push(act->child);
	return 0;
}

int DBExportEngine::doCsv(void)
{
	QString s;

	DBNode *act = stack->pop();

	if(act == NULL)
		return 0;

	//Do we need to export this media?
	if(	act->type == HC_MEDIA && // ==> it is a media
		!medial.isEmpty()     && // ==> and there is a restriction of the media names   
		!((medial.split(QChar(';'),QString::SkipEmptyParts))
			.contains(act->getNameOf())) ) // ==> this media is not in the list...
				{
					stack->push(act->next); //Skip this media!
					return 0;
				}

	if(!(act->type == HC_FILE || (act->type == HC_MEDIA && mo)))
	{
		stack->push(act->next);
		stack->push(act->child);
		return 0;
	}

	if(act->type == HC_FILE)
	{
        if(!s1R && !s2R)
		{ //No separation
			*out << act->getFullPath();
		}
		else
		{   //separate the catalog name
			QStringList parts;
			s = act->getFullPath();
			s.remove(0,2);
			parts = s.split(QChar('/'));
			*out << parts[0] << ";";
			parts.removeFirst();
			if(s2R)
			{ //separate the media name too
				*out << parts[0] << ";";
				parts.removeFirst();
			}
			*out << parts.join("/");
		}
	}
	else
	{
		*out << act->getFullPath();
	}

	if(fR)
		*out <<";"<< act->getNameOf();

	if(act->type == HC_FILE)		
	{
		if(sR)
			*out << ";"<< (qobject_cast<DBFile *>(act->DBdata))->getSizeString();
	}

	if(dR)
	{
        switch(act->type)
		{
			case HC_CATALOG:
				*out << ";"<<(qobject_cast<DBCatalog *>(act->DBdata))->modification.toString(Qt::ISODate)<<endl;
				break;
			case HC_MEDIA:
				*out << ";"<<(qobject_cast<DBMedia *>(act->DBdata))->modification.toString(Qt::ISODate)<<endl;
				break;
			case HC_DIRECTORY:
				*out << ";"<<(qobject_cast<DBDirectory *>(act->DBdata))->modification.toString(Qt::ISODate)<<endl;
				break;
			case HC_FILE:
				*out << ";"<<(qobject_cast<DBFile *>(act->DBdata))->modification.toString(Qt::ISODate)<<endl;
				break;
		}
	}
	else
	{
		*out << endl;
	}

	stack->push(act->next);
	if(act->type != HC_MEDIA || !mo)
		stack->push(act->child);
	return 0;
}

/***************************************************************************
 * DBImportEngine class                                                    *
 ***************************************************************************/

//end code.
