/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 

  Input Output Core module (iocore.h)
****************************************************************************/

#ifndef CDCAT_IOCORE_HEADER
#define CDCAT_IOCORE_HEADER

#include <stdio.h>

#include <QtCore>
#include <QtXml>

#include <zlib.h>


#define OUT_BUFF_ELEMENT	16

class DBNode;
class DBMp3Tag;

class DBFileWriter : public QObject
 {
	Q_OBJECT

	private:
		inline const char * to_cutf8(QString s);
		inline const char * to_cutf8(QDateTime d);
     
		QTextCodec *converter;
  
		gzFile f;
		int level;
		
		int outbindex;
		char **outbuffer;
   
	public:
		bool nicef;

	public:
		DBFileWriter(gzFile ff,bool nicefp);
		~DBFileWriter();
     
		int writeDown(DBNode *source);
  
	private:
		char **spgtable;
		inline const char * spg(int spn);

		void commentWriter (QString& c);

		int  writeHeader   (void);
		int  writeCatalog  (DBNode *source);
		int  writeMedia    (DBNode *source);
		int  writeDirectory(DBNode *source);
		int  writeFile     (DBNode *source);
		int  writeMp3Tag   (DBNode *source);
		int  writeContent  (DBNode *source);
		int  writeCatLnk   (DBNode *source);

	signals:
		void working(void);
}; 


class DBFileReader : public QObject , public QXmlDefaultHandler
{
	Q_OBJECT
	
	public:
		QString   get_scutf8 (const char *s);
		QDateTime get_dcutf8(const char *s);
		QDateTime convStrDT(QString i);
 
	private:
		// Element counter
		int counter; 
		gzFile f;
		QString *rawdata;
		DBNode *sp;
		QString cdataBuffer;
		DBMp3Tag *tmp_tagp;
		int  error,insert,cnmode;

		QString catname;

	protected:
		virtual bool    startDocument (void);
		virtual bool    endDocument   (void);

		virtual bool    startElement  (const QString& ns, const QString& ln, const QString& name, 
									   const QXmlAttributes& atts);
		virtual bool    endElement    (const QString& ns, const QString& ln, const QString& name);
		virtual bool    characters	  (const QString& ch);

		virtual bool    fatalError    (const QXmlParseException & exception );

		virtual QString errorString   (void) { return errormsg; }

	public:
		int readTo(DBNode *target);
		int getReadedElementNumber(void) { return counter; }

		QString errormsg;    

		DBFileReader(gzFile ff,int ins = 0);
		~DBFileReader(void);

		QString getCatName(void);

	signals:
		void working(void);
};

#endif
//end code.
