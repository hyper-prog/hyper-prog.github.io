/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2009 Peter Deak  (hyper80@gmail.com)

	printlib.h
*/

#ifndef GSAFE__PRINTOUT_LIB_HEADER__
#define GSAFE__PRINTOUT_LIB_HEADER__

#include <QtCore>
#include <QtGui>

class HBase;
class HTableBase;
class HPrintTable;

class PreviewFrame : public QFrame
{
	Q_OBJECT
	
	private:
        int dx,dy;
		double scale;
		HPrintTable *pt;
		QPixmap *gr;

    public:
        int panx,pany;

	public:
		PreviewFrame(HPrintTable *p,QWidget *parent);
        ~PreviewFrame(void);
		void reset(void);

	protected:
		void paintEvent(QPaintEvent *e);
		void wheelEvent(QWheelEvent *e);
		void keyPressEvent(QKeyEvent *e);

   		void mousePressEvent(QMouseEvent *e);
		void mouseReleaseEvent(QMouseEvent *e);
		void mouseMoveEvent(QMouseEvent *e);
		void resizeEvent(QResizeEvent *e);
	
	signals:
		void scrollSignal(int x,int y);

};

class HPrintTable : public QDialog
{
	Q_OBJECT

	protected:
		int page;      //lapszam (kalkulalt)
		int pagerun;   //lapszam, rajzolas alatt
		int cellh;     //cellamagassag
		QList<int> cellw; //cellaszesessweg oszloponkent
        QList<int> cellrh; //cellamagasag soronkent
		int rownum,column; //sorszam,oszlopszam

		bool hide;

		HBase *data;
		QVBoxLayout *layout;

		QLabel *pn;
        PreviewFrame *preview;
		QScrollArea  *scrollp;
		QPrinter     *printer;

		QFont printfont;

	public:
		HPrintTable(QWidget *parent,HBase *d,QFont *pf = NULL); 

	public slots:
		void scanIt  (void);
		int  drawIt  (QPainter *p,double scale=1.0,bool print=false);
		int  updateDisplay(void);
		int  printIt (void);

	protected:
		void scanList (void);
		void scanTable(void);
		void scanPlainDataMatrix(void);

	 	int drawList(QPainter *p,bool print=false);
		int drawTable(QPainter *p,bool print=false);
		int drawPlainDataMatrix(QPainter *p,bool print=false);
		int newPage  (QPainter *p,bool print=false);

	protected:
		void resizeEvent(QResizeEvent *e);
		void keyPressEvent(QKeyEvent *e);

	/*A gui ezt a signal-t hasz�lja arra, hogy a mezokhoz tartozo HDispDataField
	   tipusu leszarmazottaknak atadja a friss�t�si k�relmet
	  A nyomtatos resz ezt nem fogja hasznalni termeszetenel fogva, de azert az interfeszt megtartjuk,
	  hogy az adatresznel ne aggodjon a connect*/
	signals:
		void updateDisplaySignal(void);
};


#endif
