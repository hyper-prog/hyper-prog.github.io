/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Console / Gui

  Main Header (main_run.h)
****************************************************************************/

#ifndef CDCAT_CDCAT_MAIN_H_
#define CDCAT_CDCAT_MAIN_H_

#include "base.h"
#include "dbase.h"
#include <QtCore>

#ifdef APP_GUI_MODE
#include <QtGui>
#endif

class CConfig;
class GuiCore;

#ifdef APP_GUI_MODE
class GuiApp : public QApplication
{
	Q_OBJECT

	public:
		static GuiApp *guiAppPo;

	public:
		CConfig  * ccfg;
		DataBase * cdb;
		GuiCore  * guicore;
		

	public:
		GuiApp(int &argc,char ** argv);
		~GuiApp(void);
};
#endif

#ifdef APP_CONSOLE_MODE
class ConsoleApp : public QCoreApplication
{
	Q_OBJECT

    public : 
		ConsoleApp(int &argumenti,char **argumentc);
	
		void printhelp(void);
};

class ConsoleActionHandler : public DBActionHandler
{
    Q_OBJECT

    public:
		ConsoleActionHandler(void) {}

    public:
		virtual int     errorOccured(int code,QString msg,QString a1="",QString a2="",QString a3="");
		virtual QString textQuestion(QString msg);
		virtual int     chooseQuestion(QString msg,QString a1="",QString a2="",QString a3="");
		virtual void    warningMessage(QString msg);
	
};

#endif 

#endif
//end code.
