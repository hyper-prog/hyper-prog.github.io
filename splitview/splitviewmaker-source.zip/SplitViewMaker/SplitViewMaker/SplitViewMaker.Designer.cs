namespace SplitViewMaker
{
    partial class SplitViewMaker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputText = new System.Windows.Forms.TextBox();
            this.outputText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonInputBrowser = new System.Windows.Forms.Button();
            this.buttonOutputBrowser = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.buttonRun = new System.Windows.Forms.Button();
            this.sliceX = new System.Windows.Forms.NumericUpDown();
            this.sliceY = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.sliceX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sliceY)).BeginInit();
            this.SuspendLayout();
            // 
            // inputText
            // 
            this.inputText.Location = new System.Drawing.Point(103, 9);
            this.inputText.Name = "inputText";
            this.inputText.Size = new System.Drawing.Size(195, 20);
            this.inputText.TabIndex = 0;
            // 
            // outputText
            // 
            this.outputText.Location = new System.Drawing.Point(103, 36);
            this.outputText.Name = "outputText";
            this.outputText.Size = new System.Drawing.Size(195, 20);
            this.outputText.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Input (.jpg)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Output Directory";
            // 
            // buttonInputBrowser
            // 
            this.buttonInputBrowser.Location = new System.Drawing.Point(309, 8);
            this.buttonInputBrowser.Name = "buttonInputBrowser";
            this.buttonInputBrowser.Size = new System.Drawing.Size(57, 23);
            this.buttonInputBrowser.TabIndex = 4;
            this.buttonInputBrowser.Text = "Browse";
            this.buttonInputBrowser.UseVisualStyleBackColor = true;
            this.buttonInputBrowser.Click += new System.EventHandler(this.buttonInputBrowser_Click);
            // 
            // buttonOutputBrowser
            // 
            this.buttonOutputBrowser.Location = new System.Drawing.Point(309, 35);
            this.buttonOutputBrowser.Name = "buttonOutputBrowser";
            this.buttonOutputBrowser.Size = new System.Drawing.Size(57, 23);
            this.buttonOutputBrowser.TabIndex = 5;
            this.buttonOutputBrowser.Text = "Browse";
            this.buttonOutputBrowser.UseVisualStyleBackColor = true;
            this.buttonOutputBrowser.Click += new System.EventHandler(this.buttonOutputBrowser_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(12, 111);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(354, 23);
            this.progressBar.TabIndex = 6;
            // 
            // buttonRun
            // 
            this.buttonRun.Location = new System.Drawing.Point(12, 82);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(239, 23);
            this.buttonRun.TabIndex = 7;
            this.buttonRun.Text = "Make split!  (x,y)";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // sliceX
            // 
            this.sliceX.Location = new System.Drawing.Point(257, 83);
            this.sliceX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.sliceX.Name = "sliceX";
            this.sliceX.Size = new System.Drawing.Size(49, 20);
            this.sliceX.TabIndex = 8;
            this.sliceX.Value = new decimal(new int[] {
            240,
            0,
            0,
            0});
            // 
            // sliceY
            // 
            this.sliceY.Location = new System.Drawing.Point(317, 83);
            this.sliceY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.sliceY.Name = "sliceY";
            this.sliceY.Size = new System.Drawing.Size(49, 20);
            this.sliceY.TabIndex = 9;
            this.sliceY.Value = new decimal(new int[] {
            240,
            0,
            0,
            0});
            // 
            // SplitViewMaker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 146);
            this.Controls.Add(this.sliceY);
            this.Controls.Add(this.sliceX);
            this.Controls.Add(this.buttonRun);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.buttonOutputBrowser);
            this.Controls.Add(this.buttonInputBrowser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.outputText);
            this.Controls.Add(this.inputText);
            this.Name = "SplitViewMaker";
            this.Text = "SplitViewMaker";
            ((System.ComponentModel.ISupportInitialize)(this.sliceX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sliceY)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputText;
        private System.Windows.Forms.TextBox outputText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonInputBrowser;
        private System.Windows.Forms.Button buttonOutputBrowser;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.NumericUpDown sliceX;
        private System.Windows.Forms.NumericUpDown sliceY;
    }
}

