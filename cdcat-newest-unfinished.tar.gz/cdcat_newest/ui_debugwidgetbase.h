/********************************************************************************
** Form generated from reading UI file 'debugwidgetbase.ui'
**
** Created: Thu Feb 17 23:10:22 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEBUGWIDGETBASE_H
#define UI_DEBUGWIDGETBASE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DebugWidgetBase
{
public:
    QVBoxLayout *vboxLayout;
    QHBoxLayout *hboxLayout;
    QPushButton *pushSql;
    QPushButton *pushText;
    QSpacerItem *spacerItem;
    QPushButton *pushSyncwrite;
    QSpacerItem *spacerItem1;
    QPushButton *pushClear;
    QTextEdit *debugtxt;
    QHBoxLayout *hboxLayout1;
    QLineEdit *lineSQL;

    void setupUi(QWidget *DebugWidgetBase)
    {
        if (DebugWidgetBase->objectName().isEmpty())
            DebugWidgetBase->setObjectName(QString::fromUtf8("DebugWidgetBase"));
        DebugWidgetBase->resize(691, 484);
        vboxLayout = new QVBoxLayout(DebugWidgetBase);
        vboxLayout->setSpacing(6);
        vboxLayout->setContentsMargins(11, 11, 11, 11);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        hboxLayout = new QHBoxLayout();
        hboxLayout->setSpacing(6);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        pushSql = new QPushButton(DebugWidgetBase);
        pushSql->setObjectName(QString::fromUtf8("pushSql"));
        pushSql->setCheckable(true);
        pushSql->setChecked(true);

        hboxLayout->addWidget(pushSql);

        pushText = new QPushButton(DebugWidgetBase);
        pushText->setObjectName(QString::fromUtf8("pushText"));
        pushText->setCheckable(true);
        pushText->setChecked(true);
        pushText->setDefault(false);

        hboxLayout->addWidget(pushText);

        spacerItem = new QSpacerItem(15, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem);

        pushSyncwrite = new QPushButton(DebugWidgetBase);
        pushSyncwrite->setObjectName(QString::fromUtf8("pushSyncwrite"));
        pushSyncwrite->setCheckable(true);

        hboxLayout->addWidget(pushSyncwrite);

        spacerItem1 = new QSpacerItem(271, 24, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem1);

        pushClear = new QPushButton(DebugWidgetBase);
        pushClear->setObjectName(QString::fromUtf8("pushClear"));

        hboxLayout->addWidget(pushClear);


        vboxLayout->addLayout(hboxLayout);

        debugtxt = new QTextEdit(DebugWidgetBase);
        debugtxt->setObjectName(QString::fromUtf8("debugtxt"));
        QPalette palette;
        QBrush brush(QColor(255, 255, 127, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush1(QColor(0, 0, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        QBrush brush2(QColor(106, 104, 100, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush2);
        QBrush brush3(QColor(212, 208, 200, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush3);
        debugtxt->setPalette(palette);
        debugtxt->setUndoRedoEnabled(false);
        debugtxt->setReadOnly(true);
        debugtxt->setAcceptRichText(false);

        vboxLayout->addWidget(debugtxt);

        hboxLayout1 = new QHBoxLayout();
        hboxLayout1->setSpacing(6);
        hboxLayout1->setContentsMargins(0, 0, 0, 0);
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        lineSQL = new QLineEdit(DebugWidgetBase);
        lineSQL->setObjectName(QString::fromUtf8("lineSQL"));
        QPalette palette1;
        QBrush brush4(QColor(255, 255, 0, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush4);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush4);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush3);
        lineSQL->setPalette(palette1);

        hboxLayout1->addWidget(lineSQL);


        vboxLayout->addLayout(hboxLayout1);

        QWidget::setTabOrder(lineSQL, pushSql);
        QWidget::setTabOrder(pushSql, pushText);
        QWidget::setTabOrder(pushText, pushClear);

        retranslateUi(DebugWidgetBase);
        QObject::connect(pushClear, SIGNAL(clicked()), debugtxt, SLOT(clear()));

        QMetaObject::connectSlotsByName(DebugWidgetBase);
    } // setupUi

    void retranslateUi(QWidget *DebugWidgetBase)
    {
        DebugWidgetBase->setWindowTitle(QApplication::translate("DebugWidgetBase", "HDebugConsole", 0, QApplication::UnicodeUTF8));
        pushSql->setText(QApplication::translate("DebugWidgetBase", "SQL", 0, QApplication::UnicodeUTF8));
        pushText->setText(QApplication::translate("DebugWidgetBase", "Texts", 0, QApplication::UnicodeUTF8));
        pushSyncwrite->setText(QApplication::translate("DebugWidgetBase", "SyncWirte: \"syndebug.txt\"", 0, QApplication::UnicodeUTF8));
        pushClear->setText(QApplication::translate("DebugWidgetBase", "Clear", 0, QApplication::UnicodeUTF8));
        debugtxt->setHtml(QApplication::translate("DebugWidgetBase", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8pt;\">START:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineSQL->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DebugWidgetBase: public Ui_DebugWidgetBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEBUGWIDGETBASE_H
