/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Mp3 TagV1/TAgV2/Techinfo reader (mp3tag.h)
****************************************************************************/

#include <stdio.h>


#ifndef CDCAT_MP3_TAG_HEADER
#define CDCAT_MP3_TAG_HEADER

class ReadMp3Tag
 {
  public:
  
    ReadMp3Tag(void);
    ReadMp3Tag(const char *fn,bool v1_over_v2p);
    ~ReadMp3Tag(void);
     
    int  Work   (const char *filename); 

    bool readed  (void) const { return bTAGreaded;     };
    bool exist   (void) const { return bTAGexist;      };

    const char *year   (void) const;
    const char *album  (void) const;
    const char *artist (void) const;
    const char *title  (void) const;
    const char *comment(void) const;
    const char *gettechinfo(void) const;    
    int         tnum (void) const;


   
  private:
  
    bool  ReadTAGv1(void);
    bool  ReadTAGv2(void);
    int  technicalInfo(void); 

    FILE *mp3;
    bool v1_over_v2;
    bool bTAGreaded,bTAGexist;
    int  tnumber;

    char *Year;
    char *Album;
    char *Artist;
    char *Title;
    char *Comment;
    
    char *techinfo;
  
    char * strbcut(char *a); 
 };

#endif
//end code.
