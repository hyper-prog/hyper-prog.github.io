/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

	datalib.h + MOC
*/

#ifndef GSAFE__DATALIB_HEADER_FILE_X_
#define GSAFE__DATALIB_HEADER_FILE_X_

#include <QtCore>

///////////////////////////////////////////////////////////
// BEGIN - CONFIG/MODIFIERS/MODULES						 //
///////////////////////////////////////////////////////////

#define PROGRESS_POSSIBILITY 1

#define MODULE_REFRESHAGENT_NETSERVER 1
#define REFRESHAGENT_TCPPORT		  1234

#define MODULE_REFRESHAGENT_NETCLIENT 1

/** HSqlChoose adattag eset�n ez az �rt�k hat�rozza meg, hogy a gyors�t� hasht�bl�ban
 *	h�nyszoros legyen a t�lfoglal�s az elemsz�mhoz k�pest. 
 *	(Nagyobb sz�m eset�n kevesebb �tk�z�s, gyorsabb ; Kissebb �rt�k eset�n kevesebb elpazarolt mem�ria)
 *	1.0 <= HASHMUL  */ 
#define HASHMUL 1.5

//#define VALIDATE_HALT_ON_FIRST_ERROR

///////////////////////////////////////////////////////////
// END - CONFIG/MODIFIERS/MODULES						 //
///////////////////////////////////////////////////////////

#define INNER_JOIN 0
#define LEFT_OUTER_JOIN 1

#define HEAD true
#define VALUE false

#ifdef MODULE_REFRESHAGENT_NETSERVER
#include <QtNetwork>
#endif
#ifdef MODULE_REFRESHAGENT_NETCLIENT
#include <QtNetwork>
#endif

// Glob�lis f�ggv�nyek //

int getIndexOf(QStringList l,QString s);
void setErrorLocal(QString s);
void error(QString s);

QStringList * deep_copy_stringlist(QStringList *target,QStringList *source);

// Oszt�lyok //

class QTextCodec;

QString convNationalToHtmlCodes(QString input);

/** XML Adatgener�l� oszt�ly. 
 *  XML csom�pontok adatok kiirat�sa, k�dol�s v�gzese stb. 
 *	Az oszt�ly el�segiti a j�l form�zott xml dokumentumok egyszer� l�trehoz�s�t. */ 
class HXmlWriter
{
    private:
        QString		codec_name;
        int			indent_pos;
        QTextStream *output_stream;
        QStack<QString> *node_stack;
        QTextCodec	*tc;
		bool no_recode;

	private:
		void eatData(QString d);
    public:
		/** L�trehoz egy egyszer� HXmlWriter oszt�lyt*/
        HXmlWriter(void);
        ~HXmlWriter(void);

		/** Visszadja azon TextStrem-objekumot, melybe az XML adat �r�dik */
        QTextStream *getStream(void);
		/** Be�ll�that� az a TextStream-objektum, melybe az XML adat �r�dik */
        void setStream(QTextStream *oo);

		/** XML fejl�c l�trehoz�sa */
        void putHead(QString enc,bool nullhead = false);

		/** Egy �ltal�nos tartalm� nyit�tag l�trehoz�sa. (Z�r�skor a tagn�v aut�matikusan �r�dik) 
		 *	@param n a tag neve  
		 *	@see endNode() */
        void beginNode(QString n,QString parameters="");

		/** M�r megkezdett csom�pont lez�r�sa 
		 *	@see beginNode() */
        void endNode(void);

		/** Karakteres adatokat tartalmaz� csom�pont le�r�sa (nyit�s, tartalom, z�r�s) 
		 *	@param n a csom�pont neve
		 *	@param data a karakteres adat */
        void putCData(QString n,QString data,QString parameters="");

		/** Egy �res egyszer� z�rt csom�pont l�trehoz�sa (tartalom n�lk�l) 
		 *	@param n a csom�pont neve */
        void putEmptyNode(QString n);

		/** Egy stringet ir a stream-be minden egyeb formazas nelkul. (Tartalmazhat xml elemeket is) 
		 *	@param data maga az adat */
		void putRawData(QString data);

		QByteArray recodeDataNoconvert(QString d);
        QByteArray recodeData(QString d);
};

/** Frissit�seket fel�gyel� "�gyn�k" 
 *	Amennyiben ig�nybe k�v�njuk venni, egy p�ld�nyt (de csak egyet!) l�tre kell hozni a programon bel�l.
 *	Amennyiben ez az oszt�ly kap egy jelet, hogy egy SQL t�bl�ban m�dos�t�s t�rt�nt azonnal
 *	urjaolvas�sra k�nyszer�ti az �sszes programban kinyitott HList�t, mely f�gg�s�gi viszonyban �ll
 *	a m�dos�tott t�bl�val 
 *	@see notify() */
class HRefreshAgent : public QObject
{
	Q_OBJECT 

	protected:
		static HRefreshAgent *theone;

	public slots:
		int notifySlot(QString tblname);

	public:
		/** L�trehozza egy Fris�t�si �gyn�k�t */
		HRefreshAgent(void);
		~HRefreshAgent(void);
		
		/** Ezt a f�ggv�nyt hivd egy tablanevvel ha azt akarod, hogy azok a t�blalist�k friss�ljenek
		  *	amik ezt jelenitik meg, vagy ezzel f�gg�s�gben �llnak. Ennyi a lenyeg. A t�bbi automatikus. */
		static void notify(QString tblname);

		static HRefreshAgent* getNotifyAgent(void) { return theone; };


	protected:
		void internalNotify(QString tblname);

	signals:
		void getnotify(QString tblname);
};

#ifdef MODULE_REFRESHAGENT_NETSERVER
/** A HRefreshAgentNetclient - osztalyok szerveroldala.
 *  Ez az osztaly kozvetlen nem csatlakozik a HRefreshAgent -hez, ha a szervert futtat�
 *  g�p szint�n frissitend� list�kat tartalmaz akkor egy klienst is el kell inditani, �s
 *  a localhostra becsatlakoztatni. */ 
class HRefreshAgentNetserver : public QObject 
{
	Q_OBJECT

	public:
		HRefreshAgentNetserver(void);
		~HRefreshAgentNetserver(void);
		
		static bool isRunning(void);
		static HRefreshAgentNetserver * getHRefreshAgentNetserver(void) { return theone; }
		static QString serverAddress();

	protected:
		static bool inNotify;
		static HRefreshAgentNetserver *theone;
	
	private:
		QTcpServer *tcpServer;
		QList<QTcpSocket *> tcps_list;
		QString laddr;

	private slots:
		int newConn(void);
		int request(void);
		int clientLeaving(void);
		int action(QString name,int sendernum);

};
#endif

#ifdef MODULE_REFRESHAGENT_NETCLIENT
/** Ez az oszt�ly a HRefreshAgent-hez csatlakozik automatikusan (p�ld�nyos�t�skor) �s
 *  a HRefreshAgent funkcionalitasat terjeszti ki az �sszes olyan programra a h�l�zaton,
 *  melyek egyazon szerverre csatlakoztak.
 *  Hasznalat�hoz nem kell tenni egyebet, mint a HRefreshAgent peldanyositasa utan egy
 *  HRefreshAgentNetclient -t is p�ld�nyos�tani ugy hogy a konstruktornak megadjuk a 
 *  HRefreshAgentNetserver -t futtat� g�p hostnav�t vagy IP c�m�t */
class HRefreshAgentNetclient : public QObject
{
	Q_OBJECT

	public:
		HRefreshAgentNetclient(QString server_ip);
		~HRefreshAgentNetclient();

		static bool isConnected(void);
		static HRefreshAgentNetclient * getHRefreshAgentNetclient(void) { return theone; }

	protected:
		static bool inNotify;
		static HRefreshAgentNetclient *theone;

	private:
		QTcpSocket *socket;
		bool c_ok;

	private slots:
		int request(void);
		int serverClosing(void);
		int action(QString name);

	signals:
		void connectionLost();
		void connectionEstablished();
};
#endif

class HBase : public QObject 
{
    Q_OBJECT 

    protected:
   		/** Az objektumt�pus sz�vegesen */
        QString	whoami;
    public:
	/** Visszadja az objektum t�pus�t sz�vegesen (itt:"HTableBase") */
		QString getWhoami(void);
    
    public:
        HBase(void);
        ~HBase(void);
};

class HPlainDataMatrix : public HBase 
{
    Q_OBJECT

private:
    int col_count;
    QString title;
    QString exp_title;

    QString* hheader;

    QList<QVariant *> data;
	QList<QString>	  control;
	QList<QVariant *>::iterator iter;
	QList<QString>::iterator iter_ctrl;
	bool *printCellWrap;
	int  *printMaxCellWidth;

public:

	QString getTitle(void) { return title; }
	void setTitle(QString t) { title = t; }
	void setExtendedTitle(QString xt) { exp_title = xt; }


    HPlainDataMatrix(int col);
    ~HPlainDataMatrix(void);

    int  columnCount();
    int  rowCount();
    
    void setHeaderCell(int col,QString strdata);
    void setHeader(QList<QString> strlistdata);
    void setHeader(QString d1="",QString d2="",QString d3=""
					,QString d4="",QString d5="",QString d6=""
					,QString d7="",QString d8="",QString d9=""
					,QString d10="",QString d11="",QString d12=""
                    ,QString d13="",QString d14="",QString d15="");

	QString getHeaderItem(int col);
    QList<QString> getHeader(void);

	void setColumnPrintWrap(int col,bool wrap) { if(col <= col_count) printCellWrap[col] = wrap; }
	bool getColumnPrintWrap(int col)           { if(col <= col_count) return printCellWrap[col]; else return false; }
	void setColumnPrintMaxWidth(int col,int m) { if(col <= col_count) printMaxCellWidth[col] = m; }
	int  getColumnPrintMaxWidth(int col)       { if(col <= col_count) return printMaxCellWidth[col]; else return 0; }

	void replaceTextInColumn(int col,QString find,QString replace,bool parts=false);
    void replaceSameUnderCellToEmpty(int col);
   
	void firstRow(void);
	bool nextRow(void);
	bool isEnded(void);
	void removeCurrentRow(void); 
	QList<QVariant> currentRow(void);
	QList<QString> currentRowStr(void);
	QString currentRowStr(QString separator);
	QString currentRowControl(void);

    void addRow(QList<QVariant> listdata,QString ctrl="");
    void addRowStr(QList<QString> strlistdata,QString ctrl="");
    void addRowStr(QString d1="",QString d2="",QString d3=""
					,QString d4="",QString d5="",QString d6=""
					,QString d7="",QString d8="",QString d9=""
					,QString d10="",QString d11="",QString d12=""
                    ,QString d13="",QString d14="",QString d15="")
	{
		addRowStrCTRL("",d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15);
	}

	void addRowStrCTRL(QString ctrl,QString d1="",QString d2="",QString d3=""
					,QString d4="",QString d5="",QString d6=""
					,QString d7="",QString d8="",QString d9=""
					,QString d10="",QString d11="",QString d12=""
                    ,QString d13="",QString d14="",QString d15="");

	void appendHPainDataMatrix(HPlainDataMatrix *tail);

	QList<QVariant> getRow(int row);
    QList<QString> getRowStr(int row);
    QString getRowStr(int row,QString separator);

    QVariant getCell(int row,int col);
    QString getCellStr(int row,int col);
    void setCell(int row,int col,QVariant vdata);
	void setCellStr(int row,int col,QString strdata);
	void setRowControl(int row,QString ctrl);

	void setAppendPrependColumn(int col,QString prepend,QString append);
    /*Elt�volit az adatmezokbol minden html tagot <*> ha a controll stringben benne van: "optionalhtmltags"
      Ha a force_all true akkor mindn ilyet eltavolit akkoris ha nincs benne a "optionalhtmltags" */
    void removeHTMLTags(bool force_all=false);

	int sumCoulmnAsInt(int col);
	double sumCoulmnAsDouble(int col);
	QString concatenateCoulmn(int col,QString separator);


	/** Html -t general az objektumbol
			_params_ can contains combinations of: 
				html , center , notitle , width=X ,	border=X , pad=X , space=X , notable , noheader , fullwidth
			 _row-control_ can contains combinations of:
				backgroundColor=RRGGBB , 1cellexpandcenter , precell=XXX; , postcell=XXX; 
				expandCol=COLFROM-COLTO , alignCellRight=COL , alignCellCenter=COL , addCellParam=COl:XXXX;	*/
	QString getContentAsHtml(QString params);
    
    QString getColumn(int col,QString separator);
};

/** Adatbaziskapcsolathoz szukseges SQL testreszabasokat kezelo osztaly. */
class HSqlInterface : public HBase
{
	Q_OBJECT

	private:
		static bool isset;

	public:
		HSqlInterface();
		~HSqlInterface();

		/** Egy konkret alapbeallitaskeszletet tolt be
		  lehetseges modnevek :  "QtSqlite_Win" �s "PostgreSQL_WinOdbc" "PostgreSQL_LinPsql"*/
		static void setSqlMode(QString modename);	
	
		/** Be�ll�tja az alap�rtelmezett be��l�t�sk�szletet
		 * @see setSqlMode */
		static QString defaultSqlInterfaceMode;
		
	public:
		static QString hsqli_currentMode;


		/** Ha a SqlQuery->numRowsAffented fuggveny helyes erteket ad erdemes true-ra allitana, 
			ha nem akkor false-al mukodik csak */
		static bool hsqli_usequerysize;

		/** Adatbazisban ilyen sz�vegkent jelenik meg a TRUE ertek pl "1" vagy "TRUE" */
		static QString hsqli_truevalue;

		/** Adatbazisban ilyen sz�vegkent jelenik meg a FALSE ertek pl "0" vagy "FALSE" */
		static QString hsqli_falsevalue;

		/** HKey adatmezo tipusa true=VARCHAR false=INTEGER */
		static bool	hsqli_hkeytype_varchar_int;

		/** Varchar tipusu HKey mezo eseten a VARCHAR karakterszama */
		static int hsqli_varcharhkeylength	;

		/** HKey adatmezo CREATE TABLE string generalasakor ilyen megszoritast kap */
		static QString hsqli_hkeyconstraint;

		/** Egesz tipusu mez� SQL tipusneve (CREATE TABLE eseten)*/ 
		static QString hsqli_numbertypename;

		/** Lebegopontos tipusu mez� SQL tipusneve (CREATE TABLE eseten)*/ 
		static QString hsqli_floattypename;

		/** Van-e a rendszerben TIMESTAMP tipus (Ha nincs akkor nem lehet ilyen mezot beszurni a tablakba)*/
		static bool	hsqli_hastimestamptype;

		/** Idobelyeg tipusu mez� SQL tipusneve (CREATE TABLE eseten)*/ 
		static QString hsqli_timestamptypename;

		/** Van-e a rendszerben Datum tipus (Ha nincs karakteresen tarolodik el)*/
		static bool	hsqli_hasdatetype;

		/** Datum tipusu mez� SQL tipusneve (CREATE TABLE eseten)*/ 
		static QString hsqli_datetypename;

		/** SQLChoose mezonek legyen-e megszoritasi resze CREATE TABLE eseten*/
		static bool hsqli_sqlchooseconstraint;

        /** Timestamp mez� aktualis timestamp erteke */
        static QString hsqli_timestampnowvalue;

        /** Az sql hibauzenethethez hozzafuzi a driverbol erkezo uzenetet */
        static bool hsqli_appendsqlerrormsg;
};

/** Alap SQL adatkezel� oszt�ly. Minden olyan oszt�ly �soszt�lya mely SQL m�veleteket v�gez.
 *	Itt talalhatok az sql muveletekhez szukseges alapveto funkciok, hibakezel�s 
 *	illetve egy k�t alapvet� m�velet az egyszer�bb lek�rdez�s / m�dos�t�s v�gett */
class HSqlHandler : public HSqlInterface
{
	Q_OBJECT

	protected:
		bool query_error_occured;

	public:
		/** Aktu�lisan akt�v tranzakci�sz�m */
		static int trans;

	public:
		HSqlHandler(void); 
		~HSqlHandler(void); 
	
        /** Sql Tranzakci� kezd�se. Mindenk�pp sz�ks�ges el�bb ezt megh�vni mial�tt egy commit()
         *	vagy egy rolback() megh�v�sra ker�l. 
		 *	@see commit()
		 *	@see rollback()
		 *	@see transaction() */
		void transaction(void);

        /** Committ-�lja a m�r elkezdett tranzakci�t 
		 *	@see commit()
		 *	@see rollback()
		 *	@see transaction() */
		void commit(void);

        /** Rollback-eli a m�r elkezdett tranzakci�t 
		 *	@see commit()
		 *	@see rollback()
		 *	@see transaction() */
		void rollback(void);

        /** Elind�t egy egyszer� eredm�ny n�lk�li (DDL/DML) SQL k�r�st 
         *	@return TRUE:hib�val �rt v�get, ezesetben feldobja az err param�ter sz�veg�t, FALSE: akkor minden rendben volt
         *	@param q Az SQL lek�rdez�s sz�vege
		 *	@param err Hiba eset�n a feldoband� hiba�zenet 
		 *	@param tdisabled FALSE:�j tranzakci�ban bez�rva m�k�dik, TRUE:nem ind�t �j tranzakci�t */
        bool submit0ResultQuery(QString q,QString err,bool tdisabled=false);

        /** Elind�t egy egyszer� 1 eredm�nyes (1 sor 1 oszlop) SQL k�r�st 
         *	@return NULL:hib�val �rt v�get, ezesetben feldobja az err param�ter sz�veg�t, egy�bk�nt az eredm�nyt adja vissza
         *	@param q Az SQL lek�rdez�s sz�vege
		 *	@param err Hiba eset�n a feldoband� hiba�zenet 
		 *	@param tdisabled FALSE:�j tranzakci�ban bez�rva m�k�dik, TRUE:nem ind�t �j tranzakci�t */
        QVariant submit1ResultQuery(QString q,QString err,bool tdisabled=false);

        /** Elind�t egy N eredm�ny� SQL k�r�st 
         *	@param q Az SQL lek�rdez�s sz�vege
		 *	@param err Hiba eset�n a feldoband� hiba�zenet 
		 *	@param tdisabled FALSE:�j tranzakci�ban bez�rva m�k�dik, TRUE:nem ind�t �j tranzakci�t */
        HPlainDataMatrix* submitNResultQuery(int N,QString q,QString err,bool tdisabled=false);

		/** Lek�rdezi, hogy a legutols� lek�rdez�s sz�vege hiba n�lk�l hajt�dott-e v�gre 
		 *	@return TRUE:hiba volt, FALSE:nem volt hiba */
		bool errorStatus(void) { return query_error_occured; }

	signals:
		/** Hiba eset�n ezt a szign�lt dobja fel az objektum, a hiba sz�veg�vel*/
		void errorSignal(QString err);
};

class HDataField;
/** HDataField oszt�lyokat list�ba szervez� seg�doszt�ly. K�zvetlenul nem haszn�land�.
 *	A HTable oszt�ly haszn�lja aut�matikusan. (Adatmez�k list�ja ebben van) */
class HDataField_List : public HSqlHandler 
{
	Q_OBJECT

	public:
		HDataField_List(void);
		~HDataField_List(void);

		void addElement(HDataField *d);
		void clearElements(void);
		void connectElement(HDataField_List *c);
		void disconnectElement(void); 

    public:
		HDataField *data;
		HDataField_List *next;
		HDataField_List *nextall;

};

/** Tabla/Lista alaposzt�ly. Ebb�l sz�rmaznak a t�bl�kat/list�kat kezel� oszt�lyok,mint a HTable meg a HList
 *	T�bbnyire a tablaszintu muveletek �s a k�z�s interf�szek vannak kidolgozva benne
 *	@see HTable
 *	@see HList */
class HTableBase : public HSqlHandler
{
		Q_OBJECT

	protected:

		QString		tabletitle;
		int			field;
		HDataField_List *table,*run; // < Head of the list
		QString		sqlTable; 
		QStringList *depend;

        /** Kapcsolodashoz szukseges adatmezok
         *	Abban a tablaban a kapcsolodo mezo amiHEZ kapcsoltam a masikat! */
		QString conn_part;

        /** Abban a tablaban adminisztracios adat AMIT kapcsoltam a masikhoz ( IMC= I'M Connected ) */
        QString		imc_thiskey,imc_thatkey;
        HTableBase *imc_thattable;
		/** meg�rzi a csatlakoztatott t�bl�k neveit. Ilyenkor desktukt�v z�r�sn�l a f�t�bla meghal�sakor
		 *	felszabad�that�ak a kapcsolt t�bl�k is. 
		 *	Az interf�sz-libek hivj�k dektrukt�v z�r�skor. */
		QStack<HTableBase *> *connectedTableBases;

	public:
        bool	extrafeatures;
		QString errstr;

		/** Egy �res adatmez�k n�lk�li t�bla-lista alapot hoz l�tre
		 *	@param t a t�bla SQL neve */
		HTableBase(QString t);
		~HTableBase(void);

		/** M�sol� konstruktor. M�solja a teljes t�bla adatszerkezet�t �s �llapot�t, �rt�keit, 
		 *	de a kapcsolt tablat nem m�solja mag�val, �s a kapcsolatot sem. Azaz ha egy �sszekapcsolt
		 *	t�blarendszert akarunk m�solni egyenk�nt m�solni kell a t�blar�szeket, majd �sszekapcsolni �ket ujra. */
		HTableBase(HTableBase *t);

		/** Felveszi a param�terben megadott t�bla �llapot�t (M�sol� konstruktor le�r�sa szerint 
		 *	@param x a mintat�bla */
		void deepcopy_from_htablebase(HTableBase *x);

        /** Automatikus t�bla �sszecsatlakoztat�s. A HConnect mezot csatlakoztatja a HKey hez.
         *	AJANLOTT INKAB EZT A FUGGV�NYT HASZN�LNI AZ connectTable() HELYETT 
		 *	@see connectTable() */
        void connectTable(HTableBase *ct,int type=INNER_JOIN,QString connconstraint="");
        /** �ltal�nosan Hozzakapcsol a tablahoz egy masik tablat 
         *	@param ct a kapcsolando tabla HtableBase* pointere
         *  @param thiskey ezen tablanak a kapcsolomez�je /Amibol a connectet hivtuk (sql nev)
         *  @param thatkey a hozzakapcsolando tablanak a kapcsolomezeje /Ami parameterkent van megadva (sql nev)
         *  @param type kapcsolodas tipusa. Jelenleg csak az INNER_JOIN �s a LEFT_OUTER_JOIN van implementalva
         *  @param connconstraint kapcsolaskor megadott plusz feltetel X (... inner join a on a.k = b.l AND X ...)    */
		void connectTable(HTableBase *ct,QString thiskey,QString thatkey,int type=INNER_JOIN,QString connconstraint="");

        /** Torli a mar meglevo tablacsatlakozasokat
         *	Mind a kapcsolodo, es kapcsolt oldalnal meg kell hivni, es minden iranyu kapcsolatot lerombol! 
		 *	A hozz�kapcsolt t�bl�kat nem szabad�tja fel.
		 *	@see clearAndFreeConnections()	*/
		void clearConnections(void);

        /** Torli a mar meglevo tablacsatlakozasokat �s felszabaditja a hozz�kapcsolt t�bl�kat
         *	Csak a f�t�bl�ban kell megh�vni! */
		void clearAndFreeConnections(void);

        /** Ki�ri a t�bl�t, azaz kipucolja az adatmez�ket. (HDataField-eket kit�rli) 
		 *	@see addField() */
		void freeTable(void); 

		/** Felvesz egy uj adatmez�t (oszlopot) a t�bladefin�ci�ba 
		 *	@param i a hatulra besz�rand� adatmez� (HDataFiled t�pus) 
		 *	@see freeTable() */
        void addField(HDataField *i);
        
        /** Adatmez�k bej�r�sa: L�ptet�s kezd�se, a poz�ci� az els� mez�re �ll 
		 *	@see nextField()
		 *	@see nextFieldAll()	*/
		void firstField(void);
        
        /** Adatmez�k bej�r�sa: L�ptet�s a k�vetkez� mez�re, �s az aktu�lis visszad�sa (Kapcsolt t�bl�k n�lk�l) 
		 *	@see firstField()
		 *	@see nextFieldAll()	*/
		HDataField *nextField(void);    
        
        /** Adatmez�k bej�r�sa: L�ptet�s a k�vetkez� mez�re, �s az aktu�lis visszad�sa (Kapcsolt t�bl�kkal) 
		 *	@see firstField()
		 *	@see nextField()	*/
		HDataField *nextFieldAll(void); 

        /** Visszad egy adatdefinici�s objektumot a t�bl�b�l az SQL neve alapj�n 
		 *	@param sqln a k�rt mez� sql neve 
		 *	@param all TRUE:Ha az adott tabla kapcsolt tabla akkor a kapcsolatokban is keres.
         *	@param containerSqlTable Csak all=true eseten van ertelme megadni, kapcsolt tablaknal azt a mezot
		 *							 adja vissza amelyiket az adott nevu tabla tartalmazza. Akkor kell(hasznos) megadni 
		 *							 ha a osszekapcsolt metatablakban azonos nevu mezok is vannak.
		 *	@return a k�rt HDataField, NULL ha nem tal�lta */
        HDataField *fieldBySqlName(QString sqln,bool all=false,QString containerSqlTable="");
        /** Visszad egy adatdefinici�s objektumot a t�bl�b�l a sorsz�ma alapj�n 
		 *	@param i a k�rt mez� sorsz�ma 
		 *	@return a k�rt HDataField, NULL ha nem tal�lta */
        HDataField *fieldByIndex(int i,bool all=false);

		HDataField *staticFieldByTitle(QString title="");


		/** A t�bla minden adatmez�j�n szerkeszthet� attrib�tumot �ll�t be. */
		void setEditable(void);
		/** A t�bla minden adatmez�j�n csak olvashat� attrib�tumot �ll�t be. */
		void setReadonly(void);
		/** A t�bla minden adatmez�j�n rejtett attrib�tumot �ll�t be. */
        void setHide(void);
        /** A t�bla minden adatmez�j�n nem rejtett attrib�tumot �ll�t be. */
        void setShow(void);
		/** A t�bla minden adatmez�j�n egy bizonyops GUI sz�nt �ll�t be. 
		 *	@param r V�r�s komponens
		 *	@param g Z�ld komponens
		 *	@param b K�k komponens */
		void setColor(int r,int g,int b);

		/** A tabla minden elemenek a flagjet "nincs beallitva" ertekre allitja */
		void setAllNOSet(void);
		/** A tabla minden elemenek a flagjet "beallitva" ertekre allitja.
		    (Hasznos, ha mondjuk egy update-nek ki akarjuk kenyszeriteni, hogy minden mezo updatelodjon) */
		void setAllYESSet(void);

		bool isChanged(bool all=false);

		/** Lek�ri a t�bla sz�veges c�m�t */
		QString  tableTitle(void)         { return tabletitle; }
		/** Be�ll�tja a t�bla sz�veges c�m�t */
		void     setTableTitle(QString s) { tabletitle = s;    }

		/** Visszaadja a hivatkozott t�bla SQL nev�t */
		QString sqlTableName(void);

		/** Adatmez�k r�szletes le�r�sait adja vissza egy StringList-ben */
        QStringList getExplainHeads(void)      { return getHeads(1); };
		/** Adatmez�k r�vid le�r�sait adja vissza egy StringList-ben */
		QStringList getShortTitleHeads(void) { return getHeads(2); };
		/** Adatmez�k hosszu/r�vid le�r�sait adja vissza egy StringList-ben 
		 *	@param what 1:R�szletes le�r�s, 2:R�vid le�r�s */
		QStringList getHeads(int what);

		/** A t�bl�hoz tartoz� teljes r�szletess�g� SQL SELECT utas�t�s gener�l�sa
		 *	Kulcsresz nelkul a tabla osszes elemet lek�ri. 
         *	Alap�rtelmezetten Kapcsolt tablak figyelembev�tele nelk�l 
		 *	@param tail Az X hely�re besz�rt r�szt adja meg: "SELECT .. FROM .. WHERE TRUE X"  Pl: "AND key=1"
		 *	@param all FALSE:Kapcsolt t�bl�k n�lk�l TRUE:Kapcsolt t�bl�kkal
		 *	@param keypart TRUE:A where r�szben a lek�rdez�st lesz�k�ti az aktu�lis kulcs �ltal meghat�rozott rekordra FALSE:Nem sz�r direkt a kulcsmez�re 
		 *	@return Az SQL select utas�t�s (lez�r� pontosvessz� n�lk�l */
		QString sqlSelect(QString tail="",bool all=false,bool keypart=false);    
        /** A f�ggv�ny ugyan�gy m�k�dik mint a sqlSelect() csak a kulcsra val� sz�r�s
		 *	itt nem ker�l bele a lek�rdez�sbe (Rekordhalmaz lek�rdez�se), de a kapcsolt t�bl�k figyelembe lesznek v�ve 
		 *	@see sqlSelect()  /tail,TRUE,FALSE/ */
		QString sqlSelectAll(QString tail="") { return sqlSelect(tail,true,false); } 
        /** A f�ggv�ny ugyan�gy m�k�dik mint a sqlSelect(), a kulcsra val� sz�r�s
		 *	itt beleker�l a lek�rdez�sbe (Egy rekord lek�rdez�se), de a kapcsolt t�bl�k nem lesznek figyelembe v�ve 
		 *	@see sqlSelect()  /tail,all,TRUE/  */
		QString sqlSelectWk(QString tail="",bool all=false) { return sqlSelect(tail,all,true); }  
        /** A f�ggv�ny ugyan�gy m�k�dik mint a sqlSelect(), a kulcsra val� sz�r�s
		 *	itt beleker�l a lek�rdez�sbe (Egy rekord lek�rdez�se), �s a kapcsolt t�bl�k is figyelembe lesznek v�ve 
		 *	@see sqlSelect() /tail,TRUE,TRUE/ */
		QString sqlSelectWkAll(QString tail="") { return sqlSelect(tail,true,true); } 

		/** Visszadja az indexk�nt megadott oszlop fejl�c�t */
		QVariant operator[](int i);

		/** A fuggveny meghivasa frissit�sre keszteti az aktu�lis megjelenito feluletet.
		 *	Ezt, a "dataUpdatedSignal" SIGNAL segitsegevel �ri el.
		 *	(A felulet iditaskor sajat slotjat csatlakotatja ehhez signalhoz) */
		void dataUpdated(void);

		/** Elind�tja az adatmez�k regex szerinti elle�rz�s�t (megszor�t�s) + alacsonyabb szintu megszoritas tesztet
		 *	@param all TRUE:Kapcsolt t�bl�kra is vonatkozik, FALSE: KApcsolt t�bl�k n�lk�l 
		 *	@return Ha �res string akkor az adatmez�k �rv�nyesek, ha nem �res a hiba�zenetet adja vissza */
        QString validate(bool all=true);

		/** El��ll�tja a metat�bl�nak megfelel� SQL t�bla DDL utas�t�s�t (CREATE TABLE)
		 *	@return Az SQL utas�t�s 
		 *	@param switches el��ll�t�si m�dot tartalmaz� sz�veg. Jelenleg nem defini�lhat� semmilyen szab�lyoz� kapcsol� sem */
		QString sqlCreateString(QString switches="");

		/** Minden MARK cimkevel rendelkezo mez�t megjelenit */
		void setShowAllMarked(QString mark);
		/** Minden MARK cimkevel rendelkezo mez�t elrejt     */
		void setHideAllMarked(QString mark);
		/** Minden MARK cimkevel rendelkezo mez�r�l leszedi a readonly attributumot */
		void setEditableAllMarked(QString mark);
		/** Minden MARK cimkevel rendelkezo mez�t csak ir�sv�dett� tesz */
		void setReadolnyAllMarked(QString mark);
		/** Minden MARK cimkevel rendelkezo mez�t a megadott sz�nre szinez */
		void setColorAllMarked(QString mark,int r,int g,int b);

        void removeSqlCooseButtons(void);

        /** A kovetkezo fuggvenyekkel ekvivalens:
            this->setShow();
            this->setEditable();
            this->setHideAllMarked("HIDE_MARKER_PARAMETER");
            this->setReadolnyAllMarked("RO_MARKER_PARAMETER");
            this->removeSqlCooseButtons();                      */
        void blockReInitializeBase(QString hide_marker,QString ro_marker);

	public slots:
		int errorPassSlot(QString err);

		/** Ezzel a f�ggv�nnyel felvehet�nk egy SQL t�blanevet, amelyt�l ez a t�bla f�gg.
		 *	A HRefreshAgent m�k�d�sekor ha a ezen t�bla t�bla vagy b�rmely ilyen m�don felvett f�gg�s�gben
		 *	l�v� t�bla friss�t�sre ker�l az ujraolvastat�si mechanizmus beindul. 
		 *	Pl:Ha ezen metat�bla egy n�zett�bl�ra hivatkozik mely t�bb t�bla �sszekapcsol�sa, akkor c�lszer�
		 *	ilyen m�don felvenni az �sszes n�zett�bl�ban r�sztvev� egyszer� t�bla SQL nev�t. 
		 *	@param n azon t�bla SQL neve melyt�l a f�gg�s fenn�ll */
		void addDependTableName(QString n);

	signals:
        /** Aktivalodik, ha kivulrol vagy belulrol barmilyen formaban megvaltoztattak a memoriabeli adatokon valamit
		 *	Tipikusan automatikusan valtozo (szamolt) mezok frissiteset erdemes raallitani */
        void dataChanged(void);

        /** Aktivalodik, ha valtozott az adat a memoriaban. Es ez az adatkezelo osztalyrendszer fel�l j�tt (nem a gui felol)
		 *	Tipikusan a megjelenito reszt kesztetne frissitesre */
		void dataUpdatedSignal(void);

        /** Aktivalodik ha modositottak a tablat az adatbazisban. Tipikusan ugyanehhez az adatbazishoz kapcsolodo
         *	elemek kezeloit figyelmeztetne. */
        void dataModifiedSignal(void);
	
#ifdef PROGRESS_POSSIBILITY
		
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka elkezd�dik */
		void startWorking(void);
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka folyamatban van */
		void doWorking(void);
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka v�get �r */
		void endWorking(void);

#endif

};

/** Egy rekordot kezel� szerkeszthet� t�blaoszt�ly 
 *  Az alapvet� szerkeszthet� meta-rekord. Megfeletethet� egy adatb�zisbeli t�blarekordnak is,
 *  de k�pezheti annak r�szhalmaz�t is, vagy ak�r egy rekordkapcsolat�t is.
 *	Az adatok felolvashat�k, szerkeszthet�k, elmenthet�k.
 */
class HTable : public HTableBase
{
	Q_OBJECT

	protected:
		bool ro_mask;
		bool reread_key;
		QString insertedKey;

	public:
        /** Egy �res t�bl�t hoz l�tre. 
		 *	Az keletkezett metat�bl�ban nincsenek adatmez�k, nincsen hozz�kapcsolva semmilyen m�sik objektumhoz sem.
		 *	@param t az adatb�zisbeli t�bla SQL neve.
		 */
		HTable(QString t); 
		~HTable(void);

		/** M�sol� konstruktor, m�solja a teljes t�bla adatszerkezet�t �s �llapot�t, �rt�keit, 
		 *	de a kapcsolt tablat nem m�solja mag�val, �s a kapcsolatot sem. Azaz ha egy �sszekapcsolt
		 *	t�blarendszert akarunk m�solni egyenk�nt m�solni kell a t�blar�szeket, majd �sszekapcsolni �ket ujra.
		 *	@param t a m�soland� t�bla
		 */
		HTable(HTable *t);

		void deepcopy_from_htable(HTable *x);

		/** Az aktu�lis t�bl�zoz tartoz� SQL insert utas�t�st gener�lja le.
		 *	Az sqlInsert beszurja a HConnect mezok erteket is. 
		 *	Az sqlInsertAll a kapcsolt t�bl�kat is besz�rja, �gy a HConnect-ek ertekeit a kapcsolodassal automatikusan t�lti ki 
		 *  @param insertkey TRUE:besz�rja a kulcsmez� �rt�k�t is, FALSE:a kulcsmez� kimarad a besz�r�sb�l (defaultban generalodik)	
		 *	@see sqlInsertAll() */
		QString sqlInsert(bool insertkey=false);
		/** Az aktu�lis t�bl�zoz tartoz� SQL insert utas�t�st gener�lja le.
		 *	Az sqlInsert beszurja a HConnect mezok erteket is. 
		 *	Az sqlInsertAll a kapcsolt t�bl�kat is besz�rja, �gy a HConnect-ek ertekeit a kapcsolodassal automatikusan t�lti ki
		 *	@see sqlInsert() */
		QString sqlInsertAll(void); 

		QString sqlUpdate(bool all=false);
		QString sqlUpdateAll(void) { return sqlUpdate(true); };
	
		/** -> HEAD (true)  returns the head string of key
		    -> VALUE (false) returns the value of key */
		QString getKey(bool head_val,QString intable=""); 
		
		/** Visszadja az indexk�nt megadott oszlop �rt�k�t a mem�riabeli �ll�s szerint*/
		QVariant operator[](int i);

        void	 setSqlFieldValue(QString sqln,QVariant v,bool sdisable=false);
        QVariant getSqlFieldValue(QString sqln);

		bool readonlyMask(void) { return ro_mask; }

        /** A kovetkezo fuggvenyekkel ekvivalens:
            this->returnToDefault();
            this->blockReInitializeBase(); 
                Ami megfelel:
                    this->setShow();
                    this->setEditable();
                    this->setHideAllMarked("HIDE_MARKER_PARAMETER");
                    this->setReadolnyAllMarked("RO_MARKER_PARAMETER");
                    this->removeSqlCooseButtons();                      */
        void blockReInitialize(QString hide_marker,QString ro_marker);

	public slots:
		/** Lekerdez egy rekordot (1 soros eredmenyt var es azzal updateli a memoriabeli adatokat
		   -> Ha van valami param�terbe �rva akkor felulirja a tablaban a HKey mezot,
		      es a lekerdezesben mint elsodleges kulcsot haszn�lva lek�rdez
           -> Ha ures a parameter akkor a meglevo HKey mezo erteket haszn�lja mint elsodleges kulcsot 
           -> update: ha true akkor kuld egy dataUpdated signalt, ha false akkor nem.
		   <- 0 ha sikerult, 1 ha nem */
		int updateWithKey(QString key="",bool all=false,bool update = true,bool tdisabled=false);
		int updateWithKeyAll(QString key="",bool update=true,bool tdisabled=false) { return updateWithKey(key,true,update,tdisabled); }; 
		
		/** Be�ll�tja az els� HKey mezo ert�k�t a kapott �rt�kre
		    <- 0 ha be�ll�totta, 1 ha nem */
		int setKey(QString key); 

		/** Elmenti a mem�ri�ban lev� kulcsmez� szerinti rekordot
		    <- 0 ha sikerult, 1 ha nem */
		int saveRecord(bool all=false,bool tdisabled=false); //kapcsolt tablak nelkul
		int saveRecordAll(bool tdisabled=false) { return saveRecord(true,tdisabled); } //kapcsolt tablakkal

		/** Beszurja a mem�ri�ban tal�lhat� rekordot
		    -> insertkey=true : beszurja a kulcsmez�t is a HKey ertekevel
		    -> insertkey=false: a kulcsmezot nem szurja be (automatikusan generalja az adatk. rendszer
		    <- 0 ha sikerult, 1 ha nem 
			Az insertRecord beszurja a HConnect mezok erteket is. 	*/
		int insertRecord(bool insertkey=false,bool disable_tr=false);

   		/** Beszurja a mem�ri�ban tal�lhat� rekordot
  	        -> insertkey=true : beszurja a kulcsmez�t is a HKey ertekevel
		    -> insertkey=false: a kulcsmezot nem szurja be (automatikusan generalja az adatk. rendszer
		    <- 0 ha sikerult, 1 ha nem 
            Joinolt tablas verzio 
			Az insertRecordAll nem eldobja a HConnect-ek ertekeit mivel a kapcsolodassal automatikusan t�lti ki*/
        int insertRecordAll(bool disable_tr=false);

		/** K�zvetlen egy insert utan visszak�ri a kulcs �rt�k�t 
			azzal a m�dszerrel, hogy vissak�rdez a kulcsra. A legnagyobb timestamp mezovel rendelkez�
			rekord kulcsat adja vissza. Ahhoz hogy biztons�gosan m�k�dhessen
			L�TEZNIE KELL A T�BL�BAN TIMESTAMP MEZ�NEK CONTROLL/CHECK OPCIOVAL �S
			AZ INSERT UTAS�T�SSAL EGY TRANZAKCI�BAN KELL FUTTATNI mivel a timestamp szerint
			cs�kken�ben rendezve szedi ki a legut�bbi kulcsot.
			Akkor szedi ki a kulcs erteket ha e beszuras elott a rereadNextInsertedKey() fuggvenyt meghivjuk!
			 tovabba csak az insertRecord -a l megy insertRecordAll al nem ! */
		void rereadNextInsertedKey(void) { insertedKey=""; reread_key = true; };
		QString getInsertedKey(void) { return insertedKey; };

		/** Vissza�llitja az adatmez�k �rt�k�t az alap�rtelmezettekre.
		   (tipikusan insert utan hasznos.) */
		int returnToDefault(bool all=true);

		/** Bekapcsol, illetve kikapcsol egy �r�sv�delmi maszkot aTELJES T�BL�RA!, az�rt maszk, mert meghagyja az egyes
			mez�k ir�sv�delmi tulajdons�gait azaz NEM MODOS�TJA A MEZ�K IRASRA VONATKOZO TULAJDONS�GAIT!
			Ha be van kapcsolva ez az opci� mind�sszesen a Gui-rendszert utas�tja nem szerkeszthet� adathez�k
			megjelen�t�s�re. Akkor hasznos ha egy egy�bk�nt szerkesztend� mem�riabeli t�bl�r�l egy ideiglenes n�zetet
			szeretn�nk megjelen�teni nem szerkeszthet� m�don */
		int enableReadonlyMask(void)  { ro_mask = true;  return 0; };
		int disableReadonlyMask(void) { ro_mask = false; return 0; };

    protected:
		QString getKeyValueAfterInsert(void);

        QString specifyKey(QString tablename);
};


#define FLOATTABLES_STS_UNDEF		0 /* L�trehoztuk ujkent a listaban de meg nincs eldontve hogy megmarad-e . DB-ben nincs*/
#define FLOATTABLES_STS_ALIVE		1 /* Benne van a list�ban is meg a DB-is.*/
#define FLOATTABLES_STS_NEW			2 /* Benne van a listaban de a DB ben nincs */
#define FLOATTABLES_STS_DELETED		3 /* Listabol toroljuk a DB bol is kell*/
#define FLOATTABLES_STS_CANCELLED	4 /* Listabol torultok, DB ben nincs (uj volt, de toroltuk) */
/** A HFloatTables HTable-k t�mbjet kezeli (itt Recordok), olyanmodon, hogy nem teszi szuks�gess� az
    azonnali adatbazisszinkronizalast. Ig�ny szerint adatbazisbol felolvashat�k a rekordok, �s
    amikor az sz�ks�ges kiirhat�k az adatb�zisba. Ide�lis olyan rekordhalmazok szerkeszt�sekor amikor
    nem akarjuk hogy a m�dos�t�sok azonnal az adatb�zisba �r�djanak, hanem csak egyszerre egy m�sik tranzakci�ban.
    Lekezeli az DBolvas�st, DB�r�st, uj Rekord k�trehoz�s�t, t�rl�st szerkeszt�st! */
class HFloatTables : public HSqlHandler
{
	protected:
		QString sqlTable;
		bool fiter;
		QList<HTable *>::iterator titer;
		QList<int>::iterator siter;
	
	public:
		HTable *baserecord;
		QList<int>		 *sts;
		QList<HTable *> *tbls;

	public:
		/** baserec - Alap HTable objektum. A Rekordhalmaz ezekb�l az objektumokb�l �p�l fel 
		    Az �j rekordok is ebb�l kl�noz�dnak. (delete XXX; - kor a baserecord is felszabadul.)
		    Tov�bb� a felolvasand� t�blan�v is a baserecord sqlTable mez�j�b�l j�n. */
		HFloatTables(HTable *baserec);
		~HFloatTables(void);

		QString sqlTableName(void) { return sqlTable; };
		//bejaras/kezeles:
		/** Elemsz�m*/
		int count(void);
		int countAllStat(void);

		/** Egy �L� vagy �J t�blaelemet ad vissza a list�b�l, egy mez��rt�ke, kulcsa, vagy indexe alapj�n */
		HTable *getTByField(QString field,QString key);
		HTable *getTByKey(QString key);
		HTable *getTByNum(int idx);

		/** Minden �l� list�ban szerepl� rekordot UJra �ll�t. 
			(Igy kik�nyszer�thet� minden elem insertalasa. / Listaduplikalas esetere.)*/
		void allAliveToNew(void);
		/** Minde Recordban egy bizonyos mez�t be�ll�t egy bizonyos �rt�kre */
		void setAllField(QString fname,QVariant value);

		/** Bej�r�s listaszer�eln: */
		void first(void);
		HTable *nextRecord(void);
		QString nextKey(void);

		/** �j rekord felv�tele a list�ba. /adatb�zism�velettel nem j�r/ 
			Az uj rekordot ett�l az objektumt�l kell "k�rni" az
			al�bbi f�ggv�nyek seg�ts�g�vel. A createRecord azonnal elhelyezi a rekordot ujkent,
			a createRecordAsUndef bizonytalan st�tuszban helyezi el a rekordot, es a 
			makeRecordToNew fuggvennyel lehet nyugt�zni a beszur�st, vagy a removeUndef -el stornozni. */
		HTable *createRecord(void); //clone of baserecord
		HTable *createRecordAsUndef(void); //clone of baserecord
		void markedRecordToNew(HTable *r);
		void removeUndef(void);

		/** Kit�r�l egy rekordot a list�b�l /adatb�zism�velettel nem j�r/ */
		int deleteRecord(HTable *d);
		int deleteRecord(int idx);

		/** Lista ki�rit�se adatb�zis�r�s n�lk�l. */
		int clearMem(void);

		/** Adatbazisbol olvasas / mentes. A saveDBTable hajt vegre minden m�dos�t�st az adatb�zison ami
			el�z�leg a list�ban t�rt�nt. Ameddig ez nem h�v�dik meg a m�dos�t�sok csakis a mem�ri�ban �lnek */
		int readDBTable(QString filter,bool tdisabled=false);
		int saveDBTable(bool tdisabled=false);
};

/** Egy eg�sz t�bl�t listaszer�en kezel� oszt�ly (nem szerkeszthet�) */
class HList : public HTableBase
{
	Q_OBJECT

	protected:

		QStringList			 *keys;
		QList<QStringList *> *values;
		QString				 active_key;
		
		QList<QStringList *>::iterator	query_valiter;
		QStringList::iterator			query_keyiter;

	public:
		QString last_filter;
		bool	last_all;

	public:

        /** Egy �res t�bl�t hoz l�tre. */
		HList(QString t); 
		~HList(void);

		/**M�sol� konstruktor
			A M�sol� konstruktor m�solja a teljes t�bla adatszerkezet�t �s �llapot�t, �rt�keit, 
			de a kapcsolt tablat nem m�solja mag�val, �s a kapcsolatot sem. Azaz ha egy �sszekapcsolt
			t�blarendszert akarunk m�solni egyenk�nt m�solni kell a t�blar�szeket, majd �sszekapcsolni �ket ujra.*/		
		HList(HList *t);
		void deepcopy_from_hlist(HList *x);

		virtual QList<QStringList *>*  getValues(void) { return values; }
		virtual QStringList*		   getKeys(void)   { return keys;   }
		
		/** A mez�k "title" ertelet adja vissza */
		QString operator[](int i);

		QString activeKey(void);	
		void 	setActiveKey(QString k);
 
        virtual QString getSqlFieldValue(QString sqln);

		QString soft_current_key; //pointed by the gui class


		/** A lekerdezokurzort az elso rekordra allitja*/
		void			queryToFirst(void);
		/** L�pteti a lek�rdez�kurzort a kovetkezo poziciora
			return: true  volt mire leptetni
					false nem volt mire leptetni utolso elem volt. */
		bool			queryNextRecord(void);
		/** L�pteti a kurzort a k�vetkez� poz�ci�ra �s visszadja a kulcs�rt�ket */
		QString		queryNextKey(void);
		/** L�pteti a kurzort a k�vetkez� poz�ci�ra �s visszadja az �rt�kmez�ket */
		QStringList*	queryNextValues(void);
		/** visszadja az aktu�lis kulcs�rt�ket */
		QString		queryCurrKey(void);
		/** visszadja az aktu�lis �rt�kmez�ket */
		QStringList*	queryCurrValues(void);

	public slots:
        virtual int clearList(void);
		int actLine(void);
		/** Felolvassa a list�t az adatbazisbol. A reReadList ugyanaz mint a readList csak a param�terek
		    szigoruan megegyeznek az el�z� h�v�s�val.
			filter p�lda:  AND id='1'  Ennyi. */
		virtual int readList(QString filter="",bool all=true);
		int			reReadList(void) { return readList(last_filter,last_all); };

		/** Az alabbi fuggvenyt a HRefreshAgent hasznalja, teljesen automatikusan. Nem kell piszkalni... */
		int captureNotify(QString tblname);

		/** Ez a SIGNAL aktivalodik ha a felhasznalo rab�k�tt egy rekordra */
	signals:
		void actionOnRecord(QString key);

};

/*A HFloatTables oszt�lyt hamis�tja egy HList -nak. 
  Igy list�zhatjuk a m�g az adatb�zisban nem l�tez� adatt�bl�t  */
class HFloatTablesAsHList : public HList
{
	Q_OBJECT

	protected:
		HFloatTables *mem;

		/*Figy1: A kulcslista generaltotott, mivel nem minden elem letezik az adatbazisban
		  nem biztos hogy m�g van elsodleges kulcsuk. Ezert a generaltatott mezo.
		  Figyelj oda ra, mert emiatt nem biztos hogy a HFloatTables ban a kulcsok kozott
		  megtalalod az active_key �rteket! */

		/*Figy2: HA v�ltozat�s t�rt�nik az adatt�bl�kon a v�loz�sok csak a refreshValuesKeys()
		  fuggv�ny megh�v�sa ut�n aktualiz�l�dnak a list�ban. Ezzel elker�lend�, hopgy minden egyes
		  GUI cella moclatasakor lefusson a teljes konvertalociklus. Igy gyorsabb. Az OK- megnyomasa utan 
		  tehat meg kell hivni a fuggvenyket */

	public:
		// memt - HFloatTables alaposztaly, 
		// templ - ha nem akarjuk megadni a mezoket a HFloatTablesAsHList p�ld�nyon akkor 
        //         a megadott list�r�l mag�ra kl�nozza azokat
        // clone_struct_from_memt - Ha true(default:false!) akkor templ==NULL eseten azaz amikor nem adunk meg
        //         listadefinici�s template-et a memt->baserecord alapj�n mag�rah�zza a mez� strukt�r�t
        //         alap�rtelmezetten nem teszi azaz a HFloatTablesAsHList templ==NULL eset�n 
        //         definialatlan mezokkel fog rendelkezni. (HTableBase peldanyok seg�ts�g�vel kell felt�lt�getni...)
		HFloatTablesAsHList(HFloatTables *memt,HList *templ=NULL,bool clone_struct_from_memt=false);
		~HFloatTablesAsHList();
		
		HTable *getActiveTable(void);

		void refreshValuesKeys(bool updSignal=false);

		virtual QList<QStringList *>* getValues(void) { return values; }
		virtual QStringList*          getKeys(void)	  { return keys; }
		
	public slots:
		// A HFloatTables-t nem uritui csak az ideiglenes list�kat.
		// ha a tenyleges tablat akarod uriteni a HFloatTables::clearMem et hasznald!
        virtual int clearList(void);
		virtual int readList(QString filter="",bool all=true);
	
	private: 
		//azert hogy ne haszn�ld!
		virtual QString getSqlFieldValue(QString sqln);

};

/////////////////////////////////////////////////////////////////////////////////
/// simple data fields //////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

class HDataField : public HSqlHandler
{
	Q_OBJECT

	protected:
		QString whoami;  //oszt�lyazonos�t�
		int set;
		QString explain; //a mez� hosszu magyar neve/funkcioja
		QString title;   //a mez� r�vid t�m�r c�me (list�kn�l ez a fejl�c)
		QString tailstr; //az �rt�k ut�n f�zend� sz�veg ( pl: db,Ft.,stb. )
		QString sqlColumn; 
		QString defval;
        QString valid;
        QStringList notvalid;
		QString function;//ha a mezoerteket valamilyen sql fugvennybe akarrjuk tenni pl date(timestamp)
		QString derived;//lejkerdezeskor ez a resz hivodik meg zarojelben
		bool    meldwithnext; //Szerkesztes alatt (HDispTable-n belul) ha true akkor a k�vetkez� HDataField egy sorba lesz olvasztva
		bool	nomiddlestretch; //Szerkesztes alatt (HDispTable-n belul) nem rak expandert a explain QLabel es szerkesztomezo koze
		int		editboxmaxwidth; //Szerkesztes alatt (HDispTable-n belul) a szerkesztomezo maximalis hosszat adja meg

		QString spec_disp_sort;
        
        bool lastvalidate_result;
        bool permanentvalidate_result;
		QString manual_validate_error;
		bool editable;
		bool sql;
		bool show;

        int  wcellw_print; 
        bool wcell_print;  

		int color_r,color_g,color_b;

		QStringList markers;
	public:
		bool connected; //ha a tablat connekt�lom egy m�sikhoz ez az ertek automatikusan true lesz
		QString conn_sqlTable; //ebben a tablaban van ez a mezo. Alapbol ures, mert a HTable tartalmazza
							   //az erteket, de konnektalas utan mar ez az adat el!

	public:	
		HDataField(QString _sqlColumn,QString _explain,QString tit,
			       QString _tailstr="",bool _editable=true);

		~HDataField(void);
		HDataField(HDataField *t);


		void setData(QString _sqlColumn,QString _explain,QString tit,
			         QString _tailstr="",bool _editable=true);

	public:
		
		void deepcopy_from_hdatafield(HDataField *x);
		virtual HDataField* get_clone(void);

		QString getSpecDisplaySortMode(void)      { return spec_disp_sort; };
		void    setSpecDisplaySortMode(QString m) { spec_disp_sort=m;      };

		// set the value (sdisabled = emit signal disabled)
		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

        virtual void value_changed();

		QString getDefaultValue(void) { return defval; }

		/** Az adatb�zisban lev� �rt�ket megkapja �s visszadja a k�perny�n megjelen�tettet.
		    ez smalltext, largetext,stb eseten ugyanaz, de pl CharHash eset�n v�ltozni fog*/
		virtual QVariant dbValueToDispValue(QVariant v);

		virtual QVariant getDispValue() { return dbValueToDispValue(getValue()); };

		bool isSQLField(void) { return sql; }
		bool isEditable(void) { return editable; }
		void setEditable(void);
		void setReadonly(void);
		HDataField * asConstant(void) { setReadonly(); return this; }
		bool isSet(void) { if(set) return true; else return false; };
		void notSet(void) { set=0; };
		void doSet(void) { set=1; };


		bool isShow(void) { return show; }
		void setShow(void) { show = true; }
		void setHide(void) { show = false; }
		HDataField * asHide(void) { setHide(); return this; }

		/** Osszeolvasztas a soron kovetkez� HDataField-el (GUI-s szerkesztes HDispTable eseten)
		 *  Ha ossze vannak olvasztva a mez�k akkor a kovetkez�vel egy sorban jelenik meg.	 */
		void meldWithNext(void)			{ meldwithnext = true;  }
		void resetMeldWithNext(void)	{ meldwithnext = false; }
		bool isMeldedWithNext(void)		{ return meldwithnext;  }
		
		/** Ha az opcio be van kapcsolva akkor (GUI-s szerkesztes HDispTable eseten) a szerkesztomez� �s a magyar�z�sz�veg k�z�
		 *	nem rak be stretch mez�t. /Akkor lehet hasznos ha osszeolvasztott mez�k vannak/ 	*/
		void noMiddleStretch(void)		{ nomiddlestretch = true; }
		void resetNoMiddleStretch(void) { nomiddlestretch = false;}
		bool isNoMiddleStretch(void)	{ return nomiddlestretch; }

		/** Ha !=0 ertek van megadva akkor szerkeszteskor (GUI-s szerkesztes HDispTable eseten) eseten a QLineEdit alapu
		 *	szerkesztomezok maximalis hosszat korlatozza be.	*/
		void setEditBoxMaxWidth(int max) { editboxmaxwidth = max;  }
		int  editBoxMaxWidth(void)		 { return editboxmaxwidth; }

		/** Ha true-val ter vissza akkor az adatmezo elfogad fuggvenyt is,
		 *	egy�bk�nt a fuggvenybeallito fuggveny hatastalan 
		 *	@see setFunction	*/
		virtual bool acceptFunction(void) { return false; }
		/** Be�ll�t egy f�ggv�nyt a mez�h�z. SQL lek�rdez�skor ezen a fuggv�nyen kereszt�l szedi le az adatot a rendszer
		 *  pl: "date" eseten ,date(timestamp),
		 *	Biztons�gi okokbol csak akkor �rv�nyes, ha a mez� readonly!
		 *	valos mezok: smalltext,largetext,number,floating,date 
		 *  (ezt a mezok a acceptFunction fuggveny atdefinialasaval szabalyozzak)	*/
		void setFunction(QString func);
		/** Kitorli a mez� f�ggv�ny�t */
		void resetFunction(void)       { function = "";   }
		QString getFunction(void)      { return function; }

		/** Ha true-val ter vissza akkor az adatmezo lehet szarmaztatott mez� egy beagyazott lekerdezessel
		 *	egy�bk�nt a fuggvenybeallito fuggveny hatastalan 
		 *	@see setSubselect	*/
		virtual bool acceptSubselect(void) { return false; }
		/** Be�ll�t egy al-lek�rdez�st a mez�h�z. SQL lek�rdez�skor ezen leke�rdez�sen kereszt�l szedi le az adatot a rendszer
		 *  pl: "select now()" eseten ,(select now()),
		 *	Biztons�gi okokbol csak akkor �rv�nyes, ha a mez� readonly!
		 *	valos mezok: smalltext,largetext,number,floating,date 
		 *  (ezt a mezok a acceptFunction fuggveny atdefinialasaval szabalyozzak)	*/
		void setSubselect(QString subs);
		/** Kitorli a mez� leszaztatott lekerdezeset */
		void resetSubselect(void)       { derived = "";   }
		QString getSubselect(void)      { return derived; }

        //nyomtat�s sor�n az illet� cella sz�less�ge. 0 => automatikus (alapertelmezett)
        void setPrintCellWidth (int w) { wcellw_print = w; }
        int  getPrintCellWidth (void)  { return wcellw_print; }

        //nyomtat�s sor�n az illet� cella t�rhet� t�bb sorra.
        void setPrintCellWrap  (void)  { wcell_print = true; }  
        void setPrintCellNoWrap(void)  { wcell_print = true; }  
        bool isPrintCellWrap   (void)  { return wcell_print; }

	    QString getWhoami(void);
		
		void setColor(int r,int g,int b);
		HDataField * asColored(int r,int g,int b) { setColor(r,g,b); return this;}
		int getRColor(void) { return color_r; };
		int getGColor(void) { return color_g; };
		int getBColor(void) { return color_b; };

		QString getExplainText(void) { return explain; };
		QString getTitleText(void)   { return title;   };
		QString getTailText(void)    { return tailstr; };

		virtual QString sqlCreateStringPart(QString switches="");

		QVariant defvalParser(QString s);

        /** Be�ll�t egy regex-et ami a mez�t valid�lja. Ha nem illeszkedik a bevitt �rt�k a regexre akkor
         *   a rendszer nem fogadja el.  */
        void setValidator(QString v="");
        QString validate(void);
		/** Elemspecifikus valid�ci�, itt nem csin�l semmit, de lejebb lev� mez�k felulirhatjak!			
		 */
		virtual QString lowerValidate(void) { return QString(""); }

        void addNotValidValue(QString v);
        void setNotValidValues(QStringList nvl);
        void clearNotValidValues(void);

		/** Felevesz egy �j cimk�t a HDataField-hez. A cimk�k seg�ts�g�vel k�s�bb magasabb szinteken (HTable,HList) 
		 *	az adatmez�k egy komplett �s j�l meghat�rozott (bizonyos cimk�vel felcimk�zett) halmaz�n v�gezhet�nk
		 *	k�l�nf�kle m�veleteket, mint pl, mez�k elrejt�se, megjelen�t�se, ir�sv�dett� t�tele vagy sz�nez�se */
		void addMark(QString mark);
		void addMark(QStringList pmarkers);
        /** visszaadja hogy az adott HDataField-hez rendelkezik-e a param�terben megadott cimk�vel */
		bool hasMark(QString mark);
		/** Torli az �sszes a HDataField-hez tartoz� cimk�t */
		void clearMarkers(void);
		/** Visszaadja az �sszes cimk�t ami a HDataField-hez epp fel van v�ve */
		QStringList allMarker(void);

        /** Visszadja a legutobbi validalas eredmenyet 
            true- Hiba volt
            false-Ok volt    */
        bool getLastValidateStatus() { return lastvalidate_result; } 
        /** T�rli a validalasi hibajelzest (Guilibek miutan lekerdezik resetelik is. ) */
        void resetValidateStatus()   { lastvalidate_result=false;  } 
        /** Visszadja a legutobbi validalas eredmenyet, ugy hogy a reset sem torli a rossz erteket.
            Csakis egy jo adat levalidalasaval allithato helyre. */
	    bool getPermanentValidateStatus() { return permanentvalidate_result; }
		/** Kulso egyeb ellenorzes eseten ha a mezo erteket hibasnak talajuk ezzel a fuggvennyel kuldhetunk
			szabvanyos hibauzenetet es jelolhetjuk meg a hibas mezot. */
		void setMaulallyValidateError(QString message);
        

	public slots:
		void disableControlSlot(void) { emit disableControl(); }
		void enableControlSlot(void) { emit enableControl(); }

    signals:
        //Passzolodik a HTableBase-nek
        void dataChanged(void);

		void disableControl(void);
		void enableControl(void);

};

class HKey : public HDataField
{
	Q_OBJECT

	protected:
		QString value;

	public:
		HKey(QString sqlc,QString ex,QString tit,QString def);
		~HKey(void);

		/**M�sol� konstruktor*/
		HKey(HKey *t);

		void deepcopy_from(HKey *x);
		virtual HDataField* get_clone(void);

		virtual  int     setValue (QVariant v,bool sdisabled=false);
		virtual  int     setDefval(QVariant v);
		virtual  QVariant getValue (void);
		virtual  QString getSQLValue (void);
		virtual  QString sqlInsertHead(void);
		virtual  QString sqlInsertValue(void);
		virtual  QString sqlUpdate(void);
		virtual  QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");

};

class HConnect : public HDataField
{
	Q_OBJECT

	protected:
        QString connected_table;
		QString value;

	public:

		HConnect(QString sqlc,QString connected_tablep);
		~HConnect(void);

		/**M�sol� konstruktor*/
		HConnect(HConnect *t);

		void deepcopy_from(HConnect *x);
		virtual HDataField* get_clone(void);

        QString getConnectedTable(void) { return connected_table; };
		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");

};

class HSmallText : public HDataField
{
	Q_OBJECT

	protected:
		QString value;
		bool initial_selected;

	public:
		HSmallText(QString sqlc,QString ex,QString tit,QString t,QString def);
		~HSmallText(void);

		/**M�sol� konstruktor*/
		HSmallText(HSmallText *t);

		void deepcopy_from(HSmallText *x);
		virtual HDataField* get_clone(void);

        virtual QVariant dbValueToDispValue(QVariant v);
		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		void setInitialSelected(bool selected)  { initial_selected = selected;  }
		bool isInitialSelected(void)			{ return initial_selected;		}

		virtual bool acceptFunction(void) { return true; }
		virtual bool acceptSubselect(void) { return true; }

		virtual QString sqlCreateStringPart(QString switches="");
};

class HLargeText : public HDataField
{
	Q_OBJECT

	protected:
		QString value;

	public:
		HLargeText(QString sqlc,QString ex,QString tit,QString def);
		~HLargeText(void);

		/**M�sol� konstruktor*/
		HLargeText(HLargeText *t);

		void deepcopy_from(HLargeText *x);
		virtual HDataField* get_clone(void);

		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual bool acceptFunction(void) { return true; }
		virtual bool acceptSubselect(void) { return true; }

		virtual QString sqlCreateStringPart(QString switches="");
};

class HCharHash : public HDataField
{
	Q_OBJECT

	protected:
		QString value;

	public:
		QStringList keys;
		QStringList values;

	public:
		HCharHash(QString sqlc,QString ex,QString tit,QString t,QString def,
			      QStringList k,QStringList v);
		~HCharHash();
		
		/**M�sol� konstruktor*/
		HCharHash(HCharHash *t);

		void deepcopy_from(HCharHash *x);
		virtual HDataField* get_clone(void);

		virtual QVariant dbValueToDispValue(QVariant v);
 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");
};

class HNumHash : public HDataField
{
	Q_OBJECT

	protected:
		int value;

	public:
		QStringList keys;
		QStringList values;

	public:
		HNumHash(QString sqlc,QString ex,QString tit,QString t,QString def,
			      QStringList k,QStringList v);
		~HNumHash();

		/**M�sol� konstruktor*/
		HNumHash(HNumHash *t);

		void deepcopy_from(HNumHash *x);
		virtual HDataField* get_clone(void);

		virtual QVariant dbValueToDispValue(QVariant v);
 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");
};


class HNumber : public HDataField
{
	Q_OBJECT

	protected:
		int value;
		long int minimum,maximum;

	public:
		HNumber(QString sqlc,QString ex,QString tit,QString t,QString def);
		~HNumber(void);

		/**M�sol� konstruktor*/
		HNumber(HNumber *t);

		void deepcopy_from(HNumber *x);
		virtual HDataField* get_clone(void);


 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual bool acceptFunction(void) { return true; }
		virtual bool acceptSubselect(void) { return true; }

		void setMinimum(long int m) { minimum = m;    };
		void setMaximum(long int m) { maximum = m;    };
		long int getMinimum(void)   { return minimum; };
		long int getMaximum(void)   { return maximum; };

        virtual QVariant dbValueToDispValue(QVariant v);

		virtual QString sqlCreateStringPart(QString switches="");

		virtual QString lowerValidate(void);
};

class HStatic : public HDataField
{
	Q_OBJECT

	protected:
        QString value;

	public:
		HStatic(QString ex,QString tit="",QString def="");
		~HStatic(void);

		/**M�sol� konstruktor*/
		HStatic(HStatic *t);

		void deepcopy_from(HStatic *x);
		virtual HDataField* get_clone(void);

 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");
};

class HCheck : public HDataField
{
	Q_OBJECT

	protected:
		bool value;

	public:
 		QString trues,falses; // true-string  , false-string

	public:
		HCheck(QString sqlc,QString ex,QString tit,QString t,QString def,QString ts="igen/van",QString fs="nem/nincs");
		~HCheck(void);
		/**M�sol� konstruktor*/
		HCheck(HCheck *t);

		void deepcopy_from(HCheck *x);
		virtual HDataField* get_clone(void);

		virtual QVariant dbValueToDispValue(QVariant v);
 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual QString sqlCreateStringPart(QString switches="");
};

class HFloating : public HDataField
{
	Q_OBJECT

	protected:
		double value;
		double minimum,maximum;

	public:
		HFloating(QString sqlc,QString ex,QString tit,QString t,QString def);
		~HFloating(void);
		/**M�sol� konstruktor*/
		HFloating(HFloating *t);

		void deepcopy_from(HFloating *x);
		virtual HDataField* get_clone(void);

 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual bool acceptFunction(void) { return true; }
		virtual bool acceptSubselect(void) { return true; }

		void setMinimum(double m) { minimum = m; };
		void setMaximum(double m) { maximum = m; };
		double getMinimum(void) { return minimum; };
		double getMaximum(void) { return maximum; };

        virtual QVariant dbValueToDispValue(QVariant v);

		virtual QString sqlCreateStringPart(QString switches="");

		virtual QString lowerValidate(void);

};

class HDate : public HDataField
{
	Q_OBJECT

	protected:
		QDate value;
		bool u_alive;
		bool unknown;
		
	public:
		HDate(QString sqlc,QString ex,QString tit,QString def,bool u_a=true,bool unk=true);
		~HDate(void);
		/**M�sol� konstruktor*/
		HDate(HDate *t);

		void deepcopy_from(HDate *x);
		virtual HDataField* get_clone(void);

 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		virtual bool acceptFunction(void) { return true; }
		virtual bool acceptSubselect(void) { return true; }
		
		void possible_unknown(void)   { u_alive=true;   }
		void impossible_unknown(void) { u_alive=false;  }
		bool is_unknown_alive(void)   { return u_alive; }

		void value_is_unknown(void);
		void value_is_known(void);  
		bool is_value_unknown(void)   { return unknown; }

		virtual QString sqlCreateStringPart(QString switches="");
};

class HTimestamp : public HDataField
{
	Q_OBJECT

	protected:
		QString value;
		bool check;
		bool readed;

	public:
		/** Idobelyeg tipus� mez� alapvet�en k�tf�lek�pp viselkedhet, egyikben sem szerkeszthet�, mindegyikben
			az erteke automatikusan adodik meg. De:
			c=true (Check/Contoll mode) mindig frissul, ha a rekord iras elott visszaellen�rz�dik a konkurens ir�sok
					kiv�d�se �rdek�ben
			c=false (Normal mode) csak l�trehoz�skor (Insert) �ll�t�dik be k�zzel a programbol �tirhat�
					de a guib�l nem serkeszthet�, teh�t piszk�l�s n�lk�l a rekord l�trehoz�si ideje. */
		HTimestamp(QString sqlc,QString ex,QString tit,QString def,bool c);
		~HTimestamp(void);
		/**M�sol� konstruktor*/
		HTimestamp(HTimestamp *t);

		void deepcopy_from(HTimestamp *x);
		virtual HDataField* get_clone(void);

        virtual QVariant dbValueToDispValue(QVariant v);
 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		void set_havetocheck(void)      { check = true; };
		void set_donthavetocheck(void)  { check = false; };
		bool is_checkenabled(void)      { return check;  };

		void read_from_sql(void) { readed = true; }
		bool is_sqlreaded(void)  { return readed; }

		virtual QString sqlCreateStringPart(QString switches="");
};

class KVPair
{
	public:
		KVPair(void) { key = ""; value = ""; busy = false; }
		QString key,value;
		bool busy;
};

class HSqlChoose : public HDataField
{
	Q_OBJECT

	protected:
		//Hash function to speedup the key->value searching.
		int (*hash)(const char*);

		QString value;

		// eg:  full select is  SELECT p_id,fname,sname,bdate FROM persons WHERE fname~'^a' ORDER BY fname;
		QString connected_table;// (eg: "persons" )
		QString key_field;      // (eg: "p_id" )
		QString showed_field;   // sowed values.  | in string is column separator. otherwise replaced to space
                                //	(eg: "fname || '|' || sname || '|' || bdate   " )
		QString showed_field_head;
		QString filter_part;    // (eg: "fname ~ '^a' " )
		QString order_part;     // order by part   (eg: " order by fname" )
		QString popupdialog_title; //Title of the pop up dialog (in extended mode)
        int sortc;              // gui based sort/sort by column c; c=-1(no sort)

		QStringList keys;	//cache
		QStringList values; //cache
		QStringList sepvalues; //cache
		int maxhash;
		KVPair *pairs;

		bool easyform; //show type

    public:
        //hozzaadott gomb..
        const QObject *toolbrec;
        QString btext;
        QString toolbarbutton_down_text;

		bool progress_on_read;

        const QObject* extrafunc_receiver[5];
        QString extrafunc_text[5];
	
	public:
		HSqlChoose(QString sqlc,QString ex,QString tit,QString def,
			       QString ct,QString kf,QString sf,QString sfh,QString fp,QString op,QString inthash="");
		~HSqlChoose(void);

		/**M�sol� konstruktor*/
		HSqlChoose(HSqlChoose *t);

		void deepcopy_from(HSqlChoose *x);
		virtual HDataField* get_clone(void);

		virtual QVariant dbValueToDispValue(QVariant v);
 		virtual int     setValue (QVariant v,bool sdisabled=false);
		virtual int     setDefval(QVariant v);
		virtual QVariant getValue (void);
		virtual QString getSQLValue (void);
 		virtual QString sqlInsertHead(void);
		virtual QString sqlInsertValue(void);
		virtual QString sqlUpdate(void);
		virtual QString sqlSelectHead(void);

		QString getConnectedTableName(void) { return connected_table; }

		void enableEasyForm(void);
		void disableEasyForm(void);
		bool getEasyForm(void) { return easyform; };

		int	refreshSqlValues(bool emitsignal=true,bool tdisabled=false);
		QStringList& getKeys  (void);
		QStringList& getValues(void);
		QStringList& getSeparatedValues(void);
		QString getFieldHeads(void) { return showed_field_head; };

        void setGuiSortIndicator(int i) { sortc = i;    };
        int  getGuiSortIndicator(void)  { return sortc; };

        /** A felugro dialogusboxhoz hozzaad egy toolbar gombot text-sz�veggel
         *	A gomb lenyom�sakor a "receiver" objektum "toolbuttonclicked" SLOT-ja aktivalodik 
         *  Megprobalkozik kapcsolodni a "receiver" objektum "setKeyTo" signaljahoz, amivel a celobjektum
         *  Be tudja allitani az aktualis erteket. (Jo pl. arra ha egy uj elemet ilyen gombbal akarunk felvetetni,
         *   es azt utana nyilvan aktualissa akarjuk tenni.)
         *	A grafika inicializ�s�sa el�tt kell hivni!!   */     
        void addToolButton(const QObject* receiver,QString text);
        void removeToolButton(void);

        /** A felugro dialogusbox eset�n a tallozolistaban jobbgomb megnyom�sa eset�n megjelenik egy
         *  popupmenu, (ha van itt elem) �s a menuben ezen hozzaadott funkciok lesznek el�rhet�ek.
         *  A text lesz a sz�veg a popupmenuben. 
         *  A pos lesz a pozicio a menuben. MAX 5 db! azaz 0<= num <5
         *	A gomb lenyom�sakor a "receiver" objektum "extrafunc_X(QString key)" SLOT-ja aktivalodik ahol 0<= X <5
         *	A grafika inicializ�s�sa el�tt kell hivni!!   */     
        void addExtraFunction(int pos,const QObject* receiver,QString text);
        void removeExtraFunction(void);
       
		void setPopupDialogTitle(QString title) { popupdialog_title = title;	}
		void resetPopupDialogTitle(void)		{ popupdialog_title = "";		}
		QString getPopupDialogTitle(void)		{ return popupdialog_title;		}

		void setHashFunction(int (*nh)(const char*) ) { hash = nh; }
		void setInernalHashFunction(QString hashname);

		virtual QString sqlCreateStringPart(QString switches="");

	signals:
		void dataUpdatedSignal(void);

	#ifdef PROGRESS_POSSIBILITY
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka elkezd�dik */
		void startWorking(void);
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka folyamatban van */
		void doWorking(void);
		/** Progressbarok �s folyamatjelz�k haszn�latakor: Ezen signal-aktival�dik ha a munka v�get �r */
		void endWorking(void);
	#endif

};

//The default hash functions.
int nullhash    (const char *c); //Codename: "nullhash"
int charcodehash(const char *c); //Codename: "charcodehash"
int dropchar    (const char *c); //Codename: "dropchar"

#endif
//end code.
