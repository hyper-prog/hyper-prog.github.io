/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Tree model of catalog structur (hctree.cpp)
****************************************************************************/
#include "base.h"

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

#include "hctree.h"
#include "dbase.h"
#include "main_run.h"
#include "guicore.h"


/**********************************************************************************
* DBNodeModel class                                                               *
***********************************************************************************/

DBNodeTreeModel::DBNodeTreeModel(DBNode *start,QTreeView *parent,bool files_are_visible)
: QAbstractItemModel(parent)
{
	root = start;
	treeview = parent;
	show_files = files_are_visible;
}

DBNodeTreeModel::~DBNodeTreeModel(void)
{
}

int DBNodeTreeModel::rowCount(const QModelIndex& parent) const
{
	int row;
	DBNode *n,*t;

	if(!parent.isValid())
	{
		if(root == NULL)	return 0;
                else			return 1;
	}
	else
		n = static_cast<DBNode *>(parent.internalPointer());
	
	row = 0;
	if(n == NULL)
		return 0;


	for(t = n->child ; t != NULL ; t = t->next)
		if(show_files || t->type != HC_FILE)
			++row;

	return row;
}

QModelIndex DBNodeTreeModel::index(int row,int column,const QModelIndex& parent) const
{
//	int i;
	DBNode *n,*item;

	if(!parent.isValid())	
		item = n = root;
	else
	{
		n = static_cast<DBNode *>(parent.internalPointer());
//		cerrd("%n is "<<n->getNameOf().toLocal8Bit().constData());
		item = n->th_child(row,!show_files);
	}
    
    if (item != NULL)
	{
//		cerrd("%valami");
        return createIndex(row,column,item);
	}
    else
	{
//		cerrd("%semmi");
		return QModelIndex();
	}

}

QModelIndex DBNodeTreeModel::parent(const QModelIndex& index) const
{
//	int prow;
        DBNode *n;
        //DBNode *np;

	if(!index.isValid())
		return QModelIndex();

	n = static_cast<DBNode *>(index.internalPointer());

	if(n->parent == NULL)
		return QModelIndex();

	return createIndex(n->parent->v_idx(!show_files),0,(void *)n->parent);
}


int DBNodeTreeModel::columnCount(const QModelIndex& parent) const
{
	return 2; //Name | Type
}

bool DBNodeTreeModel::hasChildren(const QModelIndex& parent) const
{
	DBNode *n;

	if(!parent.isValid())	n = root;
	else					n = static_cast<DBNode *>(parent.internalPointer());

	if(n == NULL)
		return false;
	if(n->child == NULL)
		return false;
	else
	{
		if(show_files)
			return true;

		n = n->child;
        while(true)
		{
			if(n == NULL)
				return false;
			if(n->type != HC_FILE)
				return true;
			n = n->next;
		}
	}
}

QVariant DBNodeTreeModel::data(const QModelIndex& index,int role) const
{
	DBNode *n;

	if (!index.isValid())
		return QVariant();

	n = static_cast<DBNode *>(index.internalPointer());

    if(role == Qt::DisplayRole)
	{
  		if(index.column() == 1)
				return GuiApp::guiAppPo->guicore->getTypeStrOFNode(n);
		return n->getNameOf();
	}

	if(role == Qt::DecorationRole && index.column() == 0)
	{
		return GuiApp::guiAppPo->guicore->getIconOfNode(n,treeview->isExpanded(index) ? 1 : 0);
	}

	return QVariant();
}

Qt::ItemFlags DBNodeTreeModel::flags(const QModelIndex& index) const
{
	if (!index.isValid())
		return Qt::ItemIsEnabled;

	return Qt::ItemIsEnabled | Qt::ItemIsSelectable;
}

QVariant DBNodeTreeModel::headerData(int section,Qt::Orientation orientation,int role) const
{
	if(section == 0)
		return QString("Name");
	else
		return QString("Type");
}

int DBNodeTreeModel::setRoot(DBNode *newroot)
{
	root = newroot;
	return 0;
}

/**********************************************************************************
* MyTreeView class                                                                *
***********************************************************************************/

MyTreeView::MyTreeView(QWidget *parent)
: QTreeView(parent)
{
	setObjectName("DBTreeView");
	header()->setResizeMode(QHeaderView::Interactive);
	connect(this,SIGNAL(callPopupMenu(const QPoint&,DBNode *)),this,SLOT(popupMenu(const QPoint&,DBNode *)));
	connect(this,SIGNAL(expanded(const QModelIndex&)),this,SLOT(resizecol(const QModelIndex&)));
	connect(this,SIGNAL(collapsed(const QModelIndex&)),this,SLOT(resizecol(const QModelIndex&)));
}


int MyTreeView::resizecol(const QModelIndex &)
{
	resizeColumnToContents(0);
	return 0;
}

void MyTreeView::mousePressEvent(QMouseEvent *event)
{
	void *ptr;
	
	QTreeView::mousePressEvent(event);

	if(event->button() == Qt::RightButton)
	{
		ptr = currentIndex().internalPointer();
		if(ptr != NULL)
			emit callPopupMenu(event->globalPos(),static_cast<DBNode *>(ptr));
	}
}

int MyTreeView::popupMenu(const QPoint& pos,DBNode *ptr)
{
	//!!!
	QMenu *menu = new QMenu(this);
	menu->addAction("hello");
	menu->popup(pos);

	//QMessageBox::information(this,"jcl",static_cast<DBNode *>(ptr)->getNameOf());
	return 0;
}

int MyTreeView::jumpTo(DBNode *n)
{

	if(n == NULL) { cerrd("####################x GOT NULL");}
	else {cerrd(QString("####################### jumpTo--")+n->getNameOf().toLocal8Bit().constData() );}

	cerrd ("MyTreeView::jumpTo");
	int i;
	DBNode *node;
	QModelIndex idx;
	QStack<DBNode *> stack;
	
	node = n;
	while(node != NULL)
	{
	    stack.push(node);
	    node = node->parent;
	}
	
	//Let's search the item!
	//  Match the root position

	while((node = stack.pop()) != idx.internalPointer())
	{
		if(stack.isEmpty())
		{
			//The node placed in different tree part
			cerrd("The Differend tree part");
			return 1;
		}
	}

	//Step down on the tree
	while(n != node)
	{
		if(stack.isEmpty())	
			return 1;
		
		node = stack.pop();
		for(i=0;node != static_cast<DBNode *>((model()->index(i,0,idx)).internalPointer());++i)
		{
			if(i == model()->rowCount(idx))
			{
				//I can't found the item ...
				cerrd("I can't found the item ...");
				return 1;
			}
		}
		idx = model()->index(i,0,idx);
		expand(idx);
	}
	scrollTo(idx,QAbstractItemView::EnsureVisible);
	setCurrentIndex(idx);
	cerrd("MyTreeView::jumpTo END");

	return 0;	
}

/**********************************************************************************
* HCatTreeDWidget class                                                           *
***********************************************************************************/

HCatTreeDWidget::HCatTreeDWidget(QWidget * parent)
: QDockWidget(tr("Tree View"),parent,0)
{
	DBNode *pass_root;
	setObjectName("HCatTreeDWidget");
	eAction = false;
	QFrame *dwf=new QFrame(this);
	dwf->setObjectName("HCatTreeDWidget-f");
	QVBoxLayout *vlay = new QVBoxLayout(dwf);
	vlay->setObjectName("HCatTreeDWidget-f-Lay");

	view = new MyTreeView(dwf);
	pass_root = NULL;
	if(GuiApp::guiAppPo->cdb != NULL)
		pass_root = GuiApp::guiAppPo->cdb->getRootNode();
	model = new DBNodeTreeModel(pass_root,view,false);
	connect(view,SIGNAL(clicked(const QModelIndex &)),this,SLOT(mClick(const QModelIndex &)));
	connect(view,SIGNAL(pressed(const QModelIndex &)),this,SLOT(mClick(const QModelIndex &)));
	connect(view,SIGNAL(entered(const QModelIndex &)),this,SLOT(mClick(const QModelIndex &)));

	view->setRootIsDecorated(true);
	view->setModel(model);
	view->setFocusPolicy(Qt::StrongFocus);

	vlay->addWidget(view);

	setWidget(dwf);
}

int HCatTreeDWidget::setRoot(DBNode *newroot)
{
	disableReceiveAction();
	model->setRoot(newroot);
	//!! nem kell? beraktam, de semmi , szerintem nem kell view->setRootIndex(model->index(0,0));
	view->reset();
	enableReceiveAction();
	return 0;
}

int HCatTreeDWidget::mClick(const QModelIndex & index)
{
	disableReceiveAction();
	emit hitItem(static_cast<DBNode *>(index.internalPointer()));
	enableReceiveAction();
	return 0;
}

int HCatTreeDWidget::openNode(DBNode *n)
{
	if(eAction)
		return 0;
	return view->jumpTo(n);
}

HCatTreeDWidget::~HCatTreeDWidget(void)
{

}

#endif
//end code.
