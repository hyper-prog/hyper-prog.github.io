#!/bin/sh
rm moc*.cpp

