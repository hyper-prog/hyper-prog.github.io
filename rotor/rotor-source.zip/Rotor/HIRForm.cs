/* Hyper's image rotator
   
 Author: Peter Deak (hyper80@gmail.com)
 Homepage: http://hyperprog.com/rotor/
 Copyright (C) 2011
 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Threading;

namespace Rotor
{
    public partial class HyperImageRotatorBase : Form
    {
        private List<ImageObject> idb;

        int ancorpos;
        int pan;
        int gpan, old_gpan;
        int gspeed;
        int max_gspeed;
        int braking_distance;
        int starty;
        int wcap;
        int pp_start, pp_length, pp_end;
        bool moving;
        //private Form popupform;
        int mouseDownStatus;
        string path;
        bool closeddb;
        const int margin = 20;

        //preview pic
        double mscale;
        int preview_show;
        Image preview_image;
        int preview_start_x, preview_start_y;
        int preview_os_sx,preview_os_sy;
        int preview_os_w, preview_os_h;
          
        const int thumbrect_x = 100;
        const int thumbrect_y = 100;

        protected Bitmap gbuffer;

        public HyperImageRotatorBase()
        {
            ancorpos = 1;
            pan = 0;
            gpan = 0;
            old_gpan = 0;
            gspeed = 1;
            max_gspeed = 40;
            starty = 40;
            wcap = 0;
            pp_start = 0;
            pp_length = 0;
            pp_end = 0;
            moving = false;
            mouseDownStatus = 0;
            path = "";
            closeddb = false;
            
            //preview pic
            preview_show = 0;
            preview_image = null;
            preview_start_x = 0;
            preview_start_y = 0;

            idb = new List<ImageObject>();

            InitializeComponent();
            ProgressBar.CheckForIllegalCrossThreadCalls = false;
            RefreshGraph();

            /*path = "D:\\kepek\\1";
            readDirectory();
            opengui();
             */ 
        }

        private void workInBackground(string what)
        {
            Thread thread = new Thread(new ParameterizedThreadStart(workSeparateThread));
            thread.Start(what);    
        }

        private void workSeparateThread(object parameter)
        {
            if((string)(parameter) == "readdir")
                readDirectory();
            if ((string)(parameter) == "apply")
                applyAll();
        }

        private void readDirectory()
        {
            DirectoryInfo dir = new DirectoryInfo(path);
            if (!dir.Exists)
                throw new Exception("The directory does not exists!");

            pan = 0;
            gpan = 0;

            old_gpan = 0;

            FileInfo[] files;
            files = dir.GetFiles("*.jpg", SearchOption.TopDirectoryOnly);

            progressBar.Enabled = true;
            progressBar.Visible = true;
            progressBar.Minimum = 0;
            progressBar.Maximum = files.Length;
            progressBar.Value = 0;
            progressBar.Step = 1;
            
            closeddb = true;
            RefreshGraph();
            closegui();
            idb.Clear();
            foreach (FileInfo fi in files)
            {
                ImageObject newobject = new ImageObject();
                newobject.Filename = fi.FullName;
                idb.Add(newobject);

                progressBar.PerformStep();
            }

            progressBar.Value = 0;
            progressBar.Enabled = false;
            opengui();
            closeddb = false;
            RefreshGraph();
        }

        private void calcObjIdx(int x, int y, out int idx, out int dispXc, out int dispYc)
        {
            int i;
            idx = -1;
            dispXc = -1;
            dispYc = -1;

            if (y > 0 && y < 9)
                dispYc = -3;
            else if (y >= 9 && y < 13)
                dispYc = -2;
            else if (y >= 13 && y < starty)
                dispYc = -1;
            else
                for (i = 0; i < 5; ++i)
                    if (y > starty + i * thumbrect_y && y < starty + (i + 1) * thumbrect_y)
                        dispYc = i;

            for (i = 0; i < (int)System.Math.Ceiling((double)gpanel.Width / (double)thumbrect_x); ++i)
                if (x > i * thumbrect_x && x < (i + 1) * thumbrect_x)
                    dispXc = i;

            idx = dispXc + pan;
        }

        private void RefreshGraph()
        {
            int i;

            if (gpanel == null)
                return;

            if (closeddb)
            {
                gbuffer = new Bitmap(gpanel.Width, gpanel.Height);
                Graphics g = Graphics.FromImage(gbuffer);
               
                g.Clear(Color.Black);
                g.DrawString("Working...", new Font("Arial", 16), Brushes.Red, 100, 60);
                //gpanel.Refresh();
                return;
            }

            gspeed = 1;

            lock ("drawcycle")
            {
                moving = true;
                gbuffer = new Bitmap(gpanel.Width, gpanel.Height);
                do
                {
                    i = drawBuffer(gbuffer);
                    if (preview_show == 0)
                    {
                        gpanel.Refresh();
                        System.Threading.Thread.Sleep(20);
                    }
                }
                while (i != 0);
                if (preview_show != 0)
                {
                    Bitmap g2buffer = new Bitmap(gbuffer);
                    do
                    {
                        gbuffer = new Bitmap(g2buffer);
                        i = showPics(gbuffer);
                        gpanel.Refresh();
                        System.Threading.Thread.Sleep(10);
                    }
                    while (i != 0);
                }
                moving = false;
            }
        }

        private void FillRoundedRect(Graphics g,Brush brush,int radius,int x,int y,int width,int height)
        {

            GraphicsPath p = new GraphicsPath();

            p.AddLine(x + radius, y, x + width - radius, y);
            p.AddArc(x + width - radius, y, radius, radius,270,90);
            p.AddLine(x + width, y + radius, x + width, y + height - radius);
            p.AddArc(x + width - radius, y + height - radius, radius, radius, 0, 90);
            p.AddLine(x + width - radius, y + height, x + radius, y + height);
            p.AddArc(x, y + height-radius, radius, radius, 90, 90);
            p.AddLine(x, y + height - radius, x, y + radius);
            p.AddArc(x, y ,  radius, radius, 180, 90);

            g.FillPath(brush, p);
           
        }

        private int drawBuffer(Bitmap gb)
        {
            Graphics g = Graphics.FromImage(gb);
            int dx;

            dx = 20;
            int i, rst;
            int direction;

            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            Point[] indicatorPoligon = new Point[3];
            indicatorPoligon[0].X = (int)(thumbrect_x * (ancorpos + 0.5f) - 6); indicatorPoligon[0].Y = 9;
            indicatorPoligon[1].X = (int)(thumbrect_x * (ancorpos + 0.5f) + 6); indicatorPoligon[1].Y = 9;
            indicatorPoligon[2].X = (int)(thumbrect_x * (ancorpos + 0.5f));     indicatorPoligon[2].Y = 16;

            //Determine graphical position speed and direction 
            wcap = (int)System.Math.Floor((double)gpanel.Width / (double)thumbrect_x);
            if (old_gpan != thumbrect_x * pan)
            {
                braking_distance = 2 * gspeed + (gspeed / 2) * gspeed;
                if (System.Math.Abs(old_gpan - thumbrect_x * pan) < braking_distance)
                { //slowdown
                    if (gspeed > 1)
                        gspeed--;
                }
                else
                { //speedup
                    if (gspeed < max_gspeed)
                        gspeed++;
                }

                if (old_gpan > thumbrect_x * pan)
                    direction = -1;
                else
                    direction = 1;

                gpan = old_gpan + gspeed * direction;
            }

            dx = (int)(System.Math.Floor((double)gpan / (double)thumbrect_x) * thumbrect_x) - gpan;

            g.Clear(System.Drawing.Color.Black);
            g.FillPolygon(Brushes.Red, indicatorPoligon);
            g.DrawLine(new Pen(Brushes.Red), 0, 12, gpanel.Width, 12);

            //TESTFillRoundedRect(g, Brushes.Blue, 30, 100, 100, 300, 300);

            //position pointer
            if (idb.Count != 0)
            {
                pp_length = (int)System.Math.Floor((double)(wcap * thumbrect_x * gpanel.Width) / (double)(idb.Count * thumbrect_x));
                if (pp_length > gpanel.Width)
                    pp_length = gpanel.Width;
                if ((idb.Count - wcap) == 0)
                    pp_start = 0;
                else
                {
                    pp_start = (int)System.Math.Floor((double)(gpan * (gpanel.Width - pp_length)) / (double)((idb.Count - wcap) * thumbrect_x));
                    if (pp_length + pp_start > gpanel.Width)
                        pp_start = gpanel.Width - pp_length;
                }
                pp_end = pp_start + pp_length;
                g.FillRectangle(Brushes.Yellow, pp_start, 1, pp_length, 8);
            }

            for (i = 0; i < 4; ++i)
                g.DrawLine(new Pen(Brushes.Orange), 0, starty + i * thumbrect_y, gpanel.Width, starty + i * thumbrect_y);

            for (i = (int)System.Math.Floor((double)gpan / (double)thumbrect_x); i < idb.Count; ++i)
            {
                if (i < 0)
                    continue;
                ImageObject imgo = idb[i];

                // Drawing the column
                // g.DrawLine(new Pen(Brushes.Orange), dx, 0, dx, gpanel.Height);
                for (rst = 0; rst < 4; ++rst)
                {
                    int sx, sy;

                    if (rst == 0 || (mouseDownStatus == 1 && i == down_idx && down_dy == rst))
                    {
                        Brush brush;
                        brush = Brushes.Magenta;
                        if (imgo.status == ImageObject.status_NEW) brush = Brushes.LightBlue;
                        if (imgo.status == ImageObject.status_EXIF) brush = Brushes.Yellow;
                        if (imgo.status == ImageObject.status_SET) brush = Brushes.Green;
                        if (imgo.status == ImageObject.status_PANSET) brush = Brushes.Blue;
                        if (imgo.status == ImageObject.status_DELETED) brush = Brushes.Red;
                        if (mouseDownStatus == 1 && i == down_idx && down_dy == rst)
                            brush = Brushes.LightGray;

                        FillRoundedRect(g,brush,10, dx + 3, starty + 3 + rst * thumbrect_y, thumbrect_x - 6, thumbrect_y - 6);
                        if (imgo.status == ImageObject.status_DELETED)
                        {
                            g.DrawLine(new Pen(Brushes.Red, 3.0f), dx + 15, 17, dx + thumbrect_x - 15, starty - 5);
                            g.DrawLine(new Pen(Brushes.Red, 3.0f), dx + 15, starty - 5, dx + thumbrect_x - 15, 17);
                        }
                    }
                    sx = imgo.RotatedThumbImage((rst + imgo.Rotate) % 4).Width;
                    sy = imgo.RotatedThumbImage((rst + imgo.Rotate) % 4).Height;
                    sx = (thumbrect_x - sx) / 2;
                    sy = (thumbrect_y - sy) / 2;
                    g.FillRectangle(Brushes.Black, dx + sx - 3, starty + sy + rst * thumbrect_y - 3,
                        imgo.RotatedThumbImage((rst + imgo.Rotate) % 4).Width + 6,
                        imgo.RotatedThumbImage((rst + imgo.Rotate) % 4).Height + 6);
                    g.DrawImage(imgo.RotatedThumbImage((rst + imgo.Rotate) % 4), dx + sx, starty + sy + rst * thumbrect_y);
                }

                dx += thumbrect_x;

                //If we reach the end of window we will break out from drawing cycle
                if (dx > gpanel.Width)
                    break;
            }

            if (old_gpan != gpan)
            {
                old_gpan = gpan;
                return 1; //need continue
            }
            return 0;
        }

        private void paintGPanel(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (gbuffer != null)
                g.DrawImage(gbuffer, 0, 0);
        }

        int showPics(Bitmap bg)
        {
            if (preview_image == null)
                return 0;

            int gsx, gsy, gex, gey, gw, gh;
            Point[] points = new Point[4];                
            
            Graphics g = Graphics.FromImage(bg);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            Color customColor = Color.FromArgb(200, Color.Gray);
            SolidBrush shadowBrush = new SolidBrush(customColor);
            Color customColor2 = Color.FromArgb(150, Color.Gray);
            SolidBrush shadow2Brush = new SolidBrush(customColor2);

            if (preview_show == 2)
            {
                gsx = preview_start_x;
                gsy = preview_start_y;
                gw = preview_image.Width;
                gh = preview_image.Height;
                gex = gsx + gw;
                gey = gsy + gh;

                points[0] = new Point(preview_os_sx, preview_os_sy);
                points[1] = new Point(preview_os_sx, preview_os_sy + preview_os_h);
                points[2] = new Point(gsx - margin, gey + margin);
                points[3] = new Point(gsx - margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx, preview_os_sy);
                points[1] = new Point(preview_os_sx + preview_os_w, preview_os_sy);
                points[2] = new Point(gex + margin, gsy - margin);
                points[3] = new Point(gsx - margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx + preview_os_w, preview_os_sy);
                points[1] = new Point(preview_os_sx + preview_os_w, preview_os_sy + preview_os_h);
                points[2] = new Point(gex + margin, gey + margin);
                points[3] = new Point(gex + margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx + preview_os_w, preview_os_sy + preview_os_h);
                points[1] = new Point(preview_os_sx, preview_os_sy + preview_os_h);
                points[2] = new Point(gsx - margin, gey + margin);
                points[3] = new Point(gex + margin, gey + margin);
                g.FillPolygon(shadow2Brush, points);


                FillRoundedRect(g, shadowBrush, margin, preview_start_x - margin, preview_start_y - margin,
                                preview_image.Width + margin * 2, preview_image.Height + margin*2);
                g.DrawImage(preview_image, preview_start_x, preview_start_y);
            }

            if (preview_show == 1 || preview_show == 3)
            {
          
                gsx = (int)(preview_os_sx * (1 - mscale) + preview_start_x * mscale);
                gsy = (int)(preview_os_sy * (1 - mscale) + preview_start_y * mscale);
                gex = (int)((preview_os_sx+preview_os_w) * (1 - mscale) + (preview_start_x+preview_image.Width) * mscale);
                gey = (int)((preview_os_sy + preview_os_h) * (1 - mscale) + (preview_start_y + preview_image.Height) * mscale);
                gw = gex - gsx;
                gh = gey - gsy;

                points[0] = new Point(preview_os_sx, preview_os_sy);
                points[1] = new Point(preview_os_sx, preview_os_sy + preview_os_h);
                points[2] = new Point(gsx - margin, gey + margin);
                points[3] = new Point(gsx - margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx, preview_os_sy);
                points[1] = new Point(preview_os_sx+preview_os_w, preview_os_sy);
                points[2] = new Point(gex + margin, gsy - margin);
                points[3] = new Point(gsx - margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx+preview_os_w, preview_os_sy);
                points[1] = new Point(preview_os_sx + preview_os_w, preview_os_sy+preview_os_h);
                points[2] = new Point(gex + margin, gey + margin);
                points[3] = new Point(gex + margin, gsy - margin);
                g.FillPolygon(shadow2Brush, points);

                points[0] = new Point(preview_os_sx + preview_os_w, preview_os_sy+ preview_os_h);
                points[1] = new Point(preview_os_sx , preview_os_sy + preview_os_h);
                points[2] = new Point(gsx - margin, gey + margin);
                points[3] = new Point(gex + margin, gey + margin);
                g.FillPolygon(shadow2Brush, points);


                FillRoundedRect(g, shadowBrush, margin, gsx - margin, gsy - margin, gw + margin * 2, gh + margin*2);
                g.DrawImage(preview_image, gsx, gsy,gw,gh);


                if (preview_show == 1)
                {
                    if (mscale >= 1)
                    {
                        mscale = 1.0f;
                        preview_show = 2;
                        return 1;
                    }
                    else
                    {
                        mscale += 0.1f;
                        return 1;
                    }
                }
                if (preview_show == 3)
                {
                    if (mscale <= 0)
                    {
                        mscale = 0.0f;
                        preview_show = 0;
                        return 1;
                    }
                    else
                    {
                        mscale -= 0.1f;
                        return 1;
                    }
                }
            }
            return 0;
        }

        void mouseOnePointDouble(int x, int y, int idx, int dx, int dy)
        {
            if (moving)
                return;

            if (preview_show == 2)
            {
                preview_show = 3;
                RefreshGraph();
                return;
            }

            using (Image f_img = Image.FromFile(idb[idx].Filename))
            {
                int new_w, new_h, start_x, start_y;
                double imgorig_w, imgorig_h;
                double imgmax_w, imgmax_h;

                if ((idb[idx].Rotate + dy) % 4 == 0)
                    f_img.RotateFlip(RotateFlipType.RotateNoneFlipNone);
                if ((idb[idx].Rotate + dy) % 4 == 1)
                    f_img.RotateFlip(RotateFlipType.Rotate90FlipNone);
                if ((idb[idx].Rotate + dy) % 4 == 2)
                    f_img.RotateFlip(RotateFlipType.Rotate180FlipNone);
                if ((idb[idx].Rotate + dy) % 4 == 3)
                    f_img.RotateFlip(RotateFlipType.Rotate270FlipNone);

                imgorig_w = (double)f_img.Width;
                imgorig_h = (double)f_img.Height;
                imgmax_w = (double)gpanel.Width - 2 * margin;
                imgmax_h = (double)gpanel.Height - 2 * margin;

                if (imgorig_w <= imgmax_w && imgorig_h <= imgmax_h) //scale up!
                {
                    if (imgmax_w / imgorig_w < imgmax_h / imgorig_h) // scale up by W
                    {
                        new_w = (int)imgmax_w;
                        new_h = (int)(imgmax_w / imgorig_w * imgorig_h);
                        start_x = (int)margin;
                        start_y = (int)(margin + (imgmax_h - new_h) / 2);
                    }
                    else //scale up H
                    {
                        new_h = (int)imgmax_h;
                        new_w = (int)(imgmax_h / imgorig_h * imgorig_w);
                        start_y = (int)margin;
                        start_x = (int)(margin + (imgmax_w - new_w) / 2);
                    }
                }
                else //scale down!
                {
                    if (imgorig_w / imgmax_w > imgorig_h / imgmax_h) // Scale down W
                    {
                        new_w = (int)imgmax_w;
                        new_h = (int)(imgmax_w / imgorig_w * imgorig_h);
                        start_x = (int)margin;
                        start_y = (int)(margin + (imgmax_h - new_h) / 2);
                    }
                    else //scale down H
                    {
                        new_h = (int)imgmax_h;
                        new_w = (int)(imgmax_h / imgorig_h * imgorig_w);
                        start_y = (int)margin;
                        start_x = (int)(margin + (imgmax_w - new_w) / 2);
                    }
                }

                preview_image = new Bitmap(f_img, new Size(new_w, new_h));
                preview_start_x = start_x;
                preview_start_y = start_y;
            }

            //preview_os_sx, preview_os_sy;
            preview_os_w = idb[idx].RotatedThumbImage((idb[idx].Rotate + dy) % 4).Width;
            preview_os_h = idb[idx].RotatedThumbImage((idb[idx].Rotate + dy) % 4).Height;
            preview_os_sx = dx*thumbrect_x+(thumbrect_x - preview_os_w) / 2;
            preview_os_sy = starty+dy * thumbrect_y + (thumbrect_y - preview_os_h) / 2;

            preview_show = 1;
            mscale = 0.0f;

            RefreshGraph();
        }

        void mouseOnePointOne(int x, int y, int idx, int dx, int dy)
        {
            if (moving)
                return;

            if (preview_show == 2)
            {
                preview_show = 3;
                RefreshGraph();
                return;
            }

            //Clict to the scrollbar
            if (dy == -3)
            {
                if (x < pp_start) //Click before the scrollbar
                {
                    pan -= 5;
                    if (pan < 0)
                        pan = 0;

                    RefreshGraph();
                    return;
                }
                if (x > pp_end) //Click after the scrollbar
                {
                    pan += 5;
                    if (pan > idb.Count - wcap)
                        pan = idb.Count - wcap;

                    RefreshGraph();
                    return;
                }
                return;
            }

            if (idx < 0 || idx > idb.Count)
                return;

            if (dy == -2) //Change the autoscroll position
            {
                ancorpos = dx;
                RefreshGraph();
                return;
            }

            if (dy == -1) //Click to delete row
            {
                if (idx < 0 || idx > idb.Count)
                    return;
                idb[idx].status = ImageObject.status_DELETED;
            }

            if (dy >= 0 && dy < 4) //Picture rows...
            {
                if (idx < 0 || idx > idb.Count)
                    return;

                idb[idx].status = ImageObject.status_SET;
                idb[idx].Rotate = (idb[idx].Rotate + dy) % 4;
            }

            pan = idx - ancorpos;

            if (pan > idb.Count - wcap)
                pan = idb.Count - wcap;
            if (pan < 0)
                pan = 0;
            RefreshGraph();
        }

        private void gpanelResized(object sender, EventArgs e)
        {
            //check pan value
            if (pan > idb.Count - wcap)
                pan = idb.Count - wcap;
            if (pan < 0)
                pan = 0;
            RefreshGraph();
        }


        private void buttonPre_Click(object sender, EventArgs e)
        {
            pan--;
            if (pan < 0)
                pan = 0;
            RefreshGraph();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {

            pan++;
            if (pan > idb.Count - wcap)
                pan = idb.Count - wcap;
            RefreshGraph();
        }

        private void buttonPre5_Click(object sender, EventArgs e)
        {
            pan -= 5;
            if (pan < 0)
                pan = 0;
            RefreshGraph();
        }

        private void buttonNext5_Click(object sender, EventArgs e)
        {
            pan += 5;
            if (pan > idb.Count - wcap)
                pan = idb.Count - wcap;
            RefreshGraph();
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            pan = 0;
            RefreshGraph();
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            pan = idb.Count - wcap;
            RefreshGraph();
        }

        private void clickOnPanel(object sender, MouseEventArgs e)
        {
        }

        private void doubleclickOnPanel(object sender, MouseEventArgs e)
        {
        }

        void pictBox_Click(object sender, EventArgs e)
        {
            /*if(popupform != null)
                popupform.Close();
             */
        }

        private void srcollMouseOnPanel(object sender, ScrollEventArgs e)
        {
            if (moving || closeddb)
                return;

            int diff;
            diff = e.OldValue - e.NewValue;
            pan = pan + diff;

            if (pan > idb.Count - wcap)
                pan = idb.Count - wcap;
            if (pan < 0)
                pan = 0;
            RefreshGraph();
        }

        int downMouseX, downMouseY;
        int down_dx, down_dy, down_idx;
        private void mouseDownOnPanel(object sender, MouseEventArgs e)
        {
            if (moving || closeddb)
                return;

            downMouseX = e.X;
            downMouseY = e.Y;
            calcObjIdx(downMouseX, downMouseY, out down_idx, out down_dx, out down_dy);

            mouseDownStatus = 1;
            RefreshGraph();
        }

        private void mouseUpOnPanel(object sender, MouseEventArgs e)
        {
            if (moving || closeddb)
                return;

            mouseDownStatus = 0;
            
            int up_dx, up_dy, up_idx;
            calcObjIdx(e.X, e.Y, out up_idx, out up_dx, out up_dy);
            RefreshGraph();

            if (e.Button == MouseButtons.Left)
            {
                //UP-DOWN Same cell
                if (down_dx == up_dx && down_dy == up_dy && down_idx == up_idx)
                {
                    mouseOnePointOne(e.X, e.Y, up_idx, up_dx, up_dy);
                    return;
                }

                //UP-DOWN same Y height
                if (up_idx >= 0 && up_idx < idb.Count &&
                   down_idx >= 0 && down_idx < idb.Count)
                {
                    if (down_dx != up_dx && down_dy == up_dy)
                    {
                        if (down_idx < up_idx)
                        {
                            int i;
                            for (i = down_idx; i < idb.Count; ++i)
                            {
                                idb[i].Rotate = (idb[i].Rotate + up_dy) % 4;
                                idb[i].status = ImageObject.status_PANSET;
                            }
                        }
                        if (down_idx > up_idx)
                        {
                            int i;
                            for (i = down_idx; i >= 0; --i)
                            {
                                idb[i].Rotate = (idb[i].Rotate + up_dy) % 4;
                                idb[i].status = ImageObject.status_PANSET;
                            }
                        }
                        RefreshGraph();
                        return;
                    }
                }
            }

            if (e.Button == MouseButtons.Right)
            {
                if (down_dx == up_dx && down_dy == up_dy && down_idx == up_idx)
                {
                    mouseOnePointDouble(e.X, e.Y, up_idx, up_dx, up_dy);
                    return;
                }
            }
            
        }

        private void mouseMoveOnPanel(object sender, MouseEventArgs e)
        {
         
        }

        private void buttonSelDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult res = fbd.ShowDialog();

            if (res.ToString() == "OK")
            {
                try
                {
                    path = fbd.SelectedPath.ToString();
                    workInBackground("readdir");
                }
                catch (Exception ex)
                {
                    idb.Clear();
                    MessageBox.Show("Error:" + ex.ToString(), "Error");
                    return;
                }
                opengui();
            }
        }

        private void key(object sender, PreviewKeyDownEventArgs e)
        {
            RefreshGraph();
        }

        private static ImageCodecInfo GetEncoderInfo(String mimeType)
        {
            int j;
            ImageCodecInfo[] encoders;
            encoders = ImageCodecInfo.GetImageEncoders();
            for (j = 0; j < encoders.Length; ++j)
            {
                if (encoders[j].MimeType == mimeType)
                    return encoders[j];
            }
            return null;
        }

        private void applyAll()
        {
            bool deletefiles;
            deletefiles = false;

            progressBar.Enabled = true;
            progressBar.Visible = true;
            progressBar.Minimum = 0;
            progressBar.Maximum = idb.Count;
            progressBar.Value = 0;
            progressBar.Step = 1;

            closeddb = true;
            RefreshGraph();

            int deletedcount = 0;
            foreach (ImageObject imgobj in idb)
                if (imgobj.status == ImageObject.status_DELETED)
                    ++deletedcount;

            if (deletedcount > 0)
            {
                DialogResult result;
                result = MessageBox.Show("You marked " + deletedcount + " file to delete!\nDo you really want to delete these files?",
                    "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result.ToString() == "Yes")
                    deletefiles = true;
            }

           
            foreach (ImageObject imgobj in idb)
            {
                if (imgobj.status == ImageObject.status_DELETED)
                {
                    if (deletefiles)
                        System.IO.File.Delete(imgobj.Filename);
                }
                else
                {
                    if (imgobj.Rotate != 0)
                    {
                        using (Image image = Image.FromFile(imgobj.Filename))
                        {
                            long ro = 0;

                            EncoderParameter myEncoderParameter;
                            EncoderParameters myEncoderParameters = new EncoderParameters();

                            ImageCodecInfo usedIC = GetEncoderInfo("image/jpeg");
                            System.Drawing.Imaging.Encoder encoder = System.Drawing.Imaging.Encoder.Transformation;

                            if (imgobj.Rotate == 1) ro = (long)EncoderValue.TransformRotate90;
                            if (imgobj.Rotate == 2) ro = (long)EncoderValue.TransformRotate180;
                            if (imgobj.Rotate == 3) ro = (long)EncoderValue.TransformRotate270;

                            myEncoderParameter = new EncoderParameter(encoder, ro);
                            myEncoderParameters.Param[0] = myEncoderParameter;


                            PropertyItem[] propItems = image.PropertyItems;
                            foreach (PropertyItem propItem in propItems)
                            {
                                if (propItem.Id == 0x0112)
                                {
                                    byte one = 1;
                                    propItem.Value.SetValue(one, 0);
                                    image.SetPropertyItem(propItem);
                                }
                            }

                            image.Save(imgobj.Filename + "_rotated", usedIC, myEncoderParameters);
                            image.Dispose();
                        }

                        System.IO.File.Delete(imgobj.Filename);
                        System.IO.File.Move(imgobj.Filename + "_rotated", imgobj.Filename);
                    }
                }
                progressBar.PerformStep();
            }
            MessageBox.Show("Finished!", "Transformation status");

            progressBar.Value = 0;
            progressBar.Enabled = false;

            closeddb = false;
            idb.Clear();
            closegui();
            RefreshGraph();
        }

        private void buttonApply_Click(object sender, EventArgs e)
        {
            workInBackground("apply");
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            foreach (ImageObject imgobj in idb)
            {
                imgobj.Rotate = ImageObject.rotate_0;
                imgobj.status = ImageObject.status_NEW;
            }
            RefreshGraph();
        }

        private void closegui()
        {
            pan = 0;
            gpan = 0;
            old_gpan = 0;
            gspeed = 1;
            max_gspeed = 40;
            starty = 40;
            wcap = 0;
            pp_start = 0;
            pp_length = 0;
            pp_end = 0;
            moving = false;
            
            buttonNext.Enabled = false;
            buttonNext5.Enabled = false;
            buttonLast.Enabled = false;
            buttonPre.Enabled = false;
            buttonPre5.Enabled = false;
            buttonFirst.Enabled = false;
            buttonApply.Enabled = false;
            buttonReset.Enabled = false;
            buttonExif.Enabled = false;
           // buttonExif.Enabled = false;
        }

        private void opengui()
        {
            buttonNext.Enabled = true;
            buttonNext5.Enabled = true;
            buttonLast.Enabled = true;
            buttonPre.Enabled = true;
            buttonPre5.Enabled = true;
            buttonFirst.Enabled = true;
            buttonApply.Enabled = true;
            buttonReset.Enabled = true;
            buttonExif.Enabled = true;
            //buttonExif.Enabled = true;
        }

        private void buttonExif_Click(object sender, EventArgs e)
        {
            foreach (ImageObject imgobj in idb)
            {
                if (imgobj.exif_orientation == 1)
                {
                    imgobj.Rotate = ImageObject.rotate_0;
                    imgobj.status = ImageObject.status_EXIF;
                }
                if (imgobj.exif_orientation == 6)
                {
                    imgobj.Rotate = ImageObject.rotate_90;
                    imgobj.status = ImageObject.status_EXIF;
                }
                if (imgobj.exif_orientation == 3)
                {
                    imgobj.Rotate = ImageObject.rotate_180;
                    imgobj.status = ImageObject.status_EXIF;
                }
                if (imgobj.exif_orientation == 8)
                {
                    imgobj.Rotate = ImageObject.rotate_270;
                    imgobj.status = ImageObject.status_EXIF;
                }
            }
            RefreshGraph();
        }

        private void aboutButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hyper's image rotator\n\n"+
                            "Fast lossless jpeg rotator program\n"+
                            "Version: 1.1\n"+
                            "http://hyperprog.com/rotor/\n\n" +
                            "Author: P�ter De�k\n"+
                            "E-mail: hyper80@gmail.com\n"+
                            "Copyright (C)"
                , "Informations", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    // /////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////////
    class MyDrawPanel : System.Windows.Forms.Panel
    {
        public MyDrawPanel()
        {
            this.DoubleBuffered = true;
        }
    }

    // /////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////////
    // /////////////////////////////////////////////////////////////////////////////

    class ImageObject
    {
        public const int status_UNREAD = -1;
        public const int status_NEW = 0;
        public const int status_EXIF = 1;
        public const int status_SET = 2;
        public const int status_PANSET = 3;
        public const int status_DELETED = 4;

        public int status;

        public int exif_orientation;

        public const int rotate_0 = 0;
        public const int rotate_90 = 1;
        public const int rotate_180 = 2;
        public const int rotate_270 = 3;

        private int rotate;

        public int Rotate
        {
            get { return rotate; }
            set { rotate = System.Math.Abs(value) % 4; }
        }

        public ImageObject()
        {
            filename = "_ERROR_";
            rotate = rotate_0;
            status = status_UNREAD;
            timage = new Image[4];
            exif_orientation = 0;
        }

        private string filename;
        private Image[] timage;
        private double scale_factor;

        public string Filename
        {
            get { return filename; }
            set
            {
                const int thumbmax_x = 80;
                const int thumbmax_y = 80;

                filename = value;
                using (Image image = Image.FromFile(filename))
                {
                    PropertyItem[] propItems = image.PropertyItems;

                    int new_w, new_h;
                    if (image.Width >= image.Height)
                    {
                        scale_factor = image.Width / thumbmax_x;
                        new_w = thumbmax_x;
                        new_h = (int)(image.Height / scale_factor);
                    }
                    else
                    {
                        scale_factor = image.Height / thumbmax_y;
                        new_h = thumbmax_y;
                        new_w = (int)(image.Width / scale_factor);
                    }
                    timage[0] = new Bitmap(image, new Size(new_w, new_h));
                    timage[1] = new Bitmap(timage[0]);
                    timage[2] = new Bitmap(timage[0]);
                    timage[3] = new Bitmap(timage[0]);

                    timage[1].RotateFlip(RotateFlipType.Rotate90FlipNone);
                    timage[2].RotateFlip(RotateFlipType.Rotate180FlipNone);
                    timage[3].RotateFlip(RotateFlipType.Rotate270FlipNone);

                    foreach (PropertyItem propItem in propItems)
                    {
                        /*Exif data: 0x0112 	Orientation 	int16u 	IFD0 	
                                1 = Horizontal (normal)
                                2 = Mirror horizontal
                                3 = Rotate 180
                                4 = Mirror vertical
                                5 = Mirror horizontal and rotate 270 CW
                                6 = Rotate 90 CW
                                7 = Mirror horizontal and rotate 90 CW
                                8 = Rotate 270 CW   */
                        if (propItem.Id == 0x0112)
                        {
                            exif_orientation = Int16.Parse(propItem.Value.GetValue(0).ToString());
                        }

                    }
                }

                //Set initial status
                status = status_NEW;
                rotate = rotate_0;
            }
        }

        public Image FullImage
        {
            get { throw new Exception("I don't store the original image in memory!"); }
        }

        public Image ThumbImage
        {
            get { return timage[0]; }
        }

        public Image RotatedThumbImage(int rotate)
        {
            return timage[rotate];
        }
    }
}