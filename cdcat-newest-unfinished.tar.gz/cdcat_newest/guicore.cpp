/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Base gui contol classes (guicore.cpp)
****************************************************************************/
#include "base.h"

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

#include "dbase.h"
#include "icons.h"

#include "main_run.h"

#include "guimain.h"
#include "guicore.h"
#include "hctree.h"
#include "hclist.h"
#include "hcinfo.h"

//UI:
#include "ui_createnewd.h"
#include "ui_addmedia.h"

GuiCore::GuiCore(void)
{
	mwptr = NULL;
	lst_current = NULL;
	lst_current_t = false;
}

void GuiCore::connectSubwidgets(AppMainWindow *mwptrp)
{
	mwptr = mwptrp;
	connect(treedw,SIGNAL(hitItem(DBNode *)),listdw,SLOT(openNode(DBNode *)));
	connect(listdw,SIGNAL(openedItem(DBNode *)),treedw,SLOT(openNode(DBNode *)));
	connect(listdw,SIGNAL(hitItem(DBNode *,bool)),this,SLOT(listItemChanged(DBNode *,bool)));

	connect(infodw,SIGNAL(ceEventReq()),this,SLOT(commentEditEvent()));
	connect(infodw,SIGNAL(coEventReq()),this,SLOT(showContentEvent()));
}

int GuiCore::listItemChanged(DBNode *n,bool pnode)
{
	lst_current = n;
	lst_current_t = pnode;
	mwptr->showStatusNode(lst_current);
	infodw->showNode(lst_current,lst_current_t);
	return 0;
}

QIcon	GuiCore::getIconOfNode(DBNode *n,int mode)
{
    switch(n->type)
	{
		case HC_CATALOG:	
		case HC_CATLNK:
				return QIcon("images/type_catalog.png");
		case HC_MEDIA:		
				switch((qobject_cast<DBMedia *>(n->DBdata))->type)
				{
					case UNKNOWN : return QIcon("images/type_unknown.png"); 
					case CD      : return QIcon("images/type_cd.png");
					case DVD     : return QIcon("images/type_dvd.png");  
					case HARDDISC: return QIcon("images/type_hdd.png");
					case FLOPPY  : return QIcon("images/type_floppy.png"); 
					case NETPLACE: return QIcon("images/type_network.png"); 
					case FLASHDRV: return QIcon("images/type_flashdrive.png"); 
					case OTHERD  : return QIcon("images/type_other.png"); 
				}
		case HC_DIRECTORY:	
				if(mode == 1)
                    return QIcon("images/type_folderopen.png");
				else
					return QIcon("images/type_folderclose.png");
			case HC_FILE:		
				return QIcon("images/type_simplefile.png");
	}
	return QIcon();
}

QString GuiCore::getTypeStrOFNode(DBNode *n,int mode)
{
    switch(n->type)
	{
		case HC_CATALOG:	return QString(" ")+QObject::tr("Catalog");
		case HC_MEDIA:
				switch((qobject_cast<DBMedia *>(n->DBdata))->type)
				{
					case UNKNOWN : return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("Unknown(DB)")+QString(")");        
					case CD      : return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("CD")+QString(")"); 
					case DVD     : return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("DVD")+QString(")"); 
					case HARDDISC: return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("HardDisc")+QString(")"); 
					case FLOPPY  : return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("Floppy")+QString(")"); 
					case NETPLACE: return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("NetworkDrv")+QString(")"); 
					case FLASHDRV: return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("FlashDrv")+QString(")"); 
					case OTHERD  : return QString(" ")+QObject::tr("Media")+QString("(")+
									       QObject::tr("OtherDevice")+QString(")"); 
				}
		case HC_DIRECTORY:	return QString(" ")+QObject::tr("Directory");
		case HC_FILE:		return QString(" ")+QString("File");
		case HC_CATLNK:		return QString(" ")+QString("Catalog Link");

	}
	return QString("");
}

int GuiCore::showNodeStatEvent(void)
{
	QString str;
	if(lst_current == NULL)
	{
        QMessageBox::warning(mwptr,tr("Error:"),tr("There is no selected item in the middle list box!"),
			tr("Ok"),0);
		return 0;
	}

	str = tr("The size of \"%1\" : \n %2 \n %3 file /%4 directory")
			.arg(lst_current->getNameOf()) 
			.arg(QString().sprintf("%.2f Mb",GuiApp::guiAppPo->cdb->getSize(lst_current)))
			.arg(GuiApp::guiAppPo->cdb->getCountFiles(lst_current))
			.arg(GuiApp::guiAppPo->cdb->getCountDirs (lst_current)); 
  
	QMessageBox::information(mwptr,tr("The resoult:"),str,
                                           tr("Ok"),0);
	return 0;
}

int GuiCore::newDbEvent(void)
{
	cerrd("GuiCore::newDbEvent");
	
	Ui_CreateNewDialog dialogbase;
	QDialog *dialog = new QDialog(mwptr);
	dialogbase.setupUi(dialog);

	if(!dialog->exec())
	{
		cerrd("Cancelled...");
		delete dialog;
		cerrd("GuiCore::newDbEvent END");
		return 0;
	}
	
	while(closeDbEvent() !=0);
	GuiApp::guiAppPo->cdb = new DataBase(GuiApp::guiAppPo->ccfg);
	
	GuiApp::guiAppPo->cdb->setDBName( dialogbase.name_line_edit->text() );
	GuiApp::guiAppPo->cdb->setDBOwner( dialogbase.owner_line_edit->text() );
	GuiApp::guiAppPo->cdb->setComment( dialogbase.comment_text_edit->toPlainText() );
	
	
	listdw->setRoot(GuiApp::guiAppPo->cdb->getRootNode());
	treedw->setRoot(GuiApp::guiAppPo->cdb->getRootNode());
	//treedw->openNode(GuiApp::guiAppPo->cdb->getRootNode());

	delete dialog;
	cerrd("GuiCore::newDbEvent END");
	return 0;
}

int GuiCore::closeDbEvent(void)
{
	cerrd("GuiCore::closeDbEvent");
	delete GuiApp::guiAppPo->cdb;
	GuiApp::guiAppPo->cdb = NULL;
	treedw->setRoot(NULL);
	listdw->setRoot(NULL);
	cerrd("GuiCore::closeDbEvent END");
	return 0;
}

int GuiCore::openDbEvent(void)
{

	int ret_val;
	QString fn;
	char *str;
	cerrd("GuiCore::openDbEvent");

	fn = QFileDialog::getOpenFileName(mwptr,tr("CdCat databases (*.hcf )"),QString(),"*.hcf");
	if(fn.isEmpty())
		return 0;


	while(closeDbEvent() !=0);
	GuiApp::guiAppPo->cdb = new DataBase(GuiApp::guiAppPo->ccfg);

	cerrd("Start opening...");
	str = strdup(fn.toLocal8Bit().constData());
	if((ret_val = GuiApp::guiAppPo->cdb->openDB(str)) != 0 )
	{ // An error occured
		cerrd(".end with error!");
		QMessageBox::warning(mwptr,tr("Error while opening..."),
							 "An error occured",tr("Ok"),0);
		GuiApp::guiAppPo->cdb = NULL;
		treedw->setRoot(NULL);
		listdw->setRoot(NULL);
    }
	else
	{
		cerrd(".end with success!");
		treedw->setRoot(GuiApp::guiAppPo->cdb->getRootNode());
		listdw->setRoot(GuiApp::guiAppPo->cdb->getRootNode());
	}

	cerrd("GuiCore::openDbEvent END");
	free(str);
	return 0;
}

/*
int GuiSlave::openEvent(void)
 {
  char fnc[256];
  QString fn;
  int ret_val=0;

  strcpy(fnc,(const char *)fn);
  while(closeEvent() !=0);
  panelsOFF();


  if(mainw->db == NULL)
     mainw->db = new DataBase();

  PWw *pww = new PWw(mainw,mainw->app);
  mainw->db->pww = pww;
  progress(pww);

  if((ret_val=mainw->db->openDB(fnc)) != 0 )
   { // An error occured
     QMessageBox::warning(mainw,tr("Error while opening..."),
                          mainw->db->errormsg,tr("Ok"),0);
     mainw->db = NULL;
     standON = NodePwd = NULL;
     panelsOFF();
   }
   
  checkversion(mainw,mainw->db); 


  progress(pww);
  panelsON();
  progress(pww);


  //Save the opened file to the history
  //QMessageBox::information(0,"new history element",fn);
  if (ret_val == 0 && !fn.isEmpty())
   {
   
    if(mainw->cconfig->hlist.grep(QRegExp(QString("^")+QString(fn)+QString("$"))).isEmpty())
     {   
      mainw->cconfig->hlist.append(fn);
      mainw->historyMenu->insertItem(*get_t_open_icon(),fn);
      if ((int)mainw->cconfig->hlist.count() > (int)mainw->cconfig->historysize)
       {
          (mainw->cconfig->hlist).remove (mainw->cconfig->hlist.begin());
          mainw->historyMenu->removeItemAt(0);
       }
     }  
   }

  progress(pww);
  pww->end();
  if(mainw->db != NULL)
     mainw->db->pww = NULL;
  delete pww;
  return 0;
 }*/

//////////////////////////////////////////////////////////////////////////////////
int GuiCore::addMediaEvent(void)
{
	cerrd("*** GuiCore::addMediaEvent ***");
	
	AddMediaDialog *dialog = new AddMediaDialog(mwptr);
	
	if(dialog->exec())
	{
                QMessageBox::information(mwptr,"I will read","Not implemented");


	}

	delete dialog;
	return 0;
}
//////////////////////////////////////////////////////////////////////////////////
AddMediaDialog::AddMediaDialog(QWidget *parent)
{

	setupUi(this);

	QDirModel *dirModel = new QDirModel();
	dirView->setModel(dirModel);
}

AddMediaDialog::~AddMediaDialog()
{
}

int AddMediaDialog::autoAssignStateChanged(void)
{
	return 0;
}
//////////////////////////////////////////////////////////////////////////////////


CommentEditDialog::CommentEditDialog(QWidget *parent,QString objname,QString ccomm)
:QDialog(parent)
{
	ui.setupUi(this);
	ui.node_name->setText(objname);
	ui.comment_text->setPlainText(ccomm);
}

int GuiCore::commentEditEvent(void)
{
	CommentEditDialog *ceditdialog = 
		new CommentEditDialog(mwptr,lst_current->getNameOf(),QString(lst_current->getCommentOf()).replace("#","\n"));

	if(ceditdialog->exec())
		lst_current->setCommentOf(QString(ceditdialog->ui.comment_text->toPlainText()).replace("\n","#"));
	
	delete ceditdialog;
	infodw->showNode(lst_current,lst_current_t);
	return 0;
}

int GuiCore::showContentEvent(void)
{
	QMessageBox::information(0,"b","b");
	return 0;
}


#endif
//end code.
