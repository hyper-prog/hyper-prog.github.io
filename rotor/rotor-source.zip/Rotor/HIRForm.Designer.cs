/* Hyper's image rotator
   
 Author: Peter Deak (hyper80@gmail.com)
 Homepage: http://hyperprog.com/rotor/
 Copyright (C) 2011
 
 */
namespace Rotor
{
    partial class HyperImageRotatorBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HyperImageRotatorBase));
            this.buttonSelDir = new System.Windows.Forms.Button();
            this.buttonApply = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonPre = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.mpanel = new System.Windows.Forms.Panel();
            this.aboutButton = new System.Windows.Forms.Button();
            this.buttonExif = new System.Windows.Forms.Button();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonPre5 = new System.Windows.Forms.Button();
            this.buttonNext5 = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.gpanel = new Rotor.MyDrawPanel();
            this.mpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSelDir
            // 
            resources.ApplyResources(this.buttonSelDir, "buttonSelDir");
            this.buttonSelDir.Name = "buttonSelDir";
            this.buttonSelDir.UseVisualStyleBackColor = true;
            this.buttonSelDir.Click += new System.EventHandler(this.buttonSelDir_Click);
            // 
            // buttonApply
            // 
            resources.ApplyResources(this.buttonApply, "buttonApply");
            this.buttonApply.Name = "buttonApply";
            this.buttonApply.UseVisualStyleBackColor = true;
            this.buttonApply.Click += new System.EventHandler(this.buttonApply_Click);
            // 
            // buttonFirst
            // 
            resources.ApplyResources(this.buttonFirst, "buttonFirst");
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // buttonLast
            // 
            resources.ApplyResources(this.buttonLast, "buttonLast");
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonPre
            // 
            resources.ApplyResources(this.buttonPre, "buttonPre");
            this.buttonPre.Name = "buttonPre";
            this.buttonPre.UseVisualStyleBackColor = true;
            this.buttonPre.Click += new System.EventHandler(this.buttonPre_Click);
            // 
            // buttonNext
            // 
            resources.ApplyResources(this.buttonNext, "buttonNext");
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // mpanel
            // 
            resources.ApplyResources(this.mpanel, "mpanel");
            this.mpanel.Controls.Add(this.aboutButton);
            this.mpanel.Controls.Add(this.buttonExif);
            this.mpanel.Controls.Add(this.buttonReset);
            this.mpanel.Name = "mpanel";
            // 
            // aboutButton
            // 
            resources.ApplyResources(this.aboutButton, "aboutButton");
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.UseVisualStyleBackColor = true;
            this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
            // 
            // buttonExif
            // 
            resources.ApplyResources(this.buttonExif, "buttonExif");
            this.buttonExif.Name = "buttonExif";
            this.buttonExif.UseVisualStyleBackColor = true;
            this.buttonExif.Click += new System.EventHandler(this.buttonExif_Click);
            // 
            // buttonReset
            // 
            resources.ApplyResources(this.buttonReset, "buttonReset");
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonPre5
            // 
            resources.ApplyResources(this.buttonPre5, "buttonPre5");
            this.buttonPre5.Name = "buttonPre5";
            this.buttonPre5.UseVisualStyleBackColor = true;
            this.buttonPre5.Click += new System.EventHandler(this.buttonPre5_Click);
            // 
            // buttonNext5
            // 
            resources.ApplyResources(this.buttonNext5, "buttonNext5");
            this.buttonNext5.Name = "buttonNext5";
            this.buttonNext5.UseVisualStyleBackColor = true;
            this.buttonNext5.Click += new System.EventHandler(this.buttonNext5_Click);
            // 
            // progressBar
            // 
            resources.ApplyResources(this.progressBar, "progressBar");
            this.progressBar.Name = "progressBar";
            this.progressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // gpanel
            // 
            resources.ApplyResources(this.gpanel, "gpanel");
            this.gpanel.Name = "gpanel";
            this.gpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.paintGPanel);
            this.gpanel.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.key);
            this.gpanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouseMoveOnPanel);
            this.gpanel.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclickOnPanel);
            this.gpanel.Scroll += new System.Windows.Forms.ScrollEventHandler(this.srcollMouseOnPanel);
            this.gpanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clickOnPanel);
            this.gpanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouseDownOnPanel);
            this.gpanel.Resize += new System.EventHandler(this.gpanelResized);
            this.gpanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mouseUpOnPanel);
            // 
            // HyperImageRotatorBase
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.buttonNext5);
            this.Controls.Add(this.buttonPre5);
            this.Controls.Add(this.mpanel);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.buttonPre);
            this.Controls.Add(this.buttonLast);
            this.Controls.Add(this.buttonFirst);
            this.Controls.Add(this.buttonApply);
            this.Controls.Add(this.buttonSelDir);
            this.Controls.Add(this.gpanel);
            this.Name = "HyperImageRotatorBase";
            this.mpanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonSelDir;
        private System.Windows.Forms.Button buttonApply;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonPre;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Panel mpanel;
        private System.Windows.Forms.Button buttonReset;
        private MyDrawPanel gpanel;
        private System.Windows.Forms.Button buttonPre5;
        private System.Windows.Forms.Button buttonNext5;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Button buttonExif;
        private System.Windows.Forms.Button aboutButton;
    }
}

