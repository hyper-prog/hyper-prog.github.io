﻿/*
  C# HyperChat
  Copyright (C) Peter Deak (hyper80@gmail.com)
  License GPL
 
  This program is only for test & education pusposely
*/

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Threading;
using System.Collections.Generic;

namespace HyperChat
{
    class HyperChat
    {
        public static void Main()
        {
            Application.Run(new MainWindow());
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////
    // Network related classes
    //////////////////////////////////////////////////////////////////////////////////////////

    class MessageReceivedEventArg : EventArgs
    {
        private string message;
        public string Message { get { return message; } }
        public MessageReceivedEventArg(string message)
        { this.message = message; }
    }

    class ConnectionEstablishedEventArg : EventArgs
    {
        private int id;
        private string info;
        public int Id { get { return id; } }
        public string Info { get { return info; } }
        public ConnectionEstablishedEventArg(int id, string info)
        { this.id = id; this.info = info; }
    }

    class ConnectionClosedEventArg : EventArgs
    {
        private int id;
        public int Id { get { return id; } }
        public ConnectionClosedEventArg(int id)
        { this.id = id; }
    }

    class NetCore
    {
        const int TCPPORT = 9999;
        const int maxlength = 1000;

        TcpListener listener;
        List<TcpClient> clients;

        private messagereceiver mr;
        public delegate void messagereceiver(string receiver);
        public void setMessageReceiver(messagereceiver receiver) 
        {
            mr = receiver; 
        }

        public NetCore()
        {
            listener = null;
            clients = new List<TcpClient>();
        }

        public void Listen()
        {
            if (listener != null)
            {
                throw new Exception("Duplicate listening exception!");
            }
            IPAddress localAddr = IPAddress.Any;
            listener = new TcpListener(localAddr, TCPPORT);
            listener.Start();

            listener.BeginAcceptTcpClient(new AsyncCallback(AcceptNewClient), listener);
        }

        public void Connect(string server)
        {
            TcpClient client;
            try
            {
                client = new TcpClient(server, TCPPORT);
                client.ReceiveBufferSize = 2048;
                client.SendBufferSize = 2048;
                lock ("lock1")
                {
                    clients.Add(client);
                }

                Thread clientthread = new Thread(new ParameterizedThreadStart(handleclient));
                clientthread.Start(client);

                emitCEEvent(0, "server is " + client.Client.RemoteEndPoint.ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception occured:" + e.ToString(), "\n");
                return;
            }
        }

        private void AcceptNewClient(IAsyncResult iar)
        {
            TcpClient client;
            TcpListener listener = (TcpListener)iar.AsyncState;

            lock ("lock1")
            {
                client = listener.EndAcceptTcpClient(iar);
                client.ReceiveBufferSize = 2048;
                client.SendBufferSize = 2048;
                clients.Add(client);
            }

            Thread clientthread = new Thread(new ParameterizedThreadStart(handleclient));
            clientthread.Start(client);

            emitCEEvent(0, "remote is " + client.Client.RemoteEndPoint.ToString());

            listener.BeginAcceptTcpClient(new AsyncCallback(AcceptNewClient), listener);
        }

        private void handleclient(object o)
        {
            int readed;
            string str;
            byte[] buffer = new byte[maxlength];
            NetworkStream stream;
            TcpClient tcpclient = o as TcpClient;
            if (o == null)
                return;
            stream = tcpclient.GetStream();
            try
            {
                while (true)
                {
                        str = "";
                        try
                        {
                            readed = stream.Read(buffer, 0, buffer.Length);
                        }
                        catch
                        {
                            if (tcpclient.Connected)
                                continue;
                            else
                                readed = 0;
                        }

                        if (readed != 0)
                        {
                            str = System.Text.Encoding.UTF8.GetString(buffer, 0, readed);
                            str = str.TrimEnd(new char[] { '\n', '\r' });
                        }
                        if (readed == 0 || str == "COMMAND=close")
                        {
                            lock ("lock1")
                            {
                                clients.Remove(tcpclient);
                            }
                            tcpclient.Close();
                            emitCCEvent(0);
                            break;
                        }
                        emitMREvent(str, tcpclient);
                }
            }
            catch (SocketException se)
            {
                MessageBox.Show("SocketException occured:" + se.ToString());
                lock ("lock1")
                {
                    clients.Remove(tcpclient);
                }
                tcpclient.Close();
                emitCCEvent(0);
            }
        }

        public void Close()
        {
            lock ("lock1")
            {
                foreach (TcpClient client in clients)
                {
                    client.Close();
                    emitCCEvent(0);
                }
                clients.Clear();
            }

            if (listener != null)
            {
                listener.Stop();
                listener = null;

            }

        }

        public void Send(string message)
        {
            Send(message, null);
        }

        public void Send(string message,object exclude)
        {
            lock ("lock1")
            {
                if (clients.Count == 0)
                {
                    Exception e = new Exception("Cannot send data:Not connected!");
                    throw e;
                }
                byte[] buffer = new byte[maxlength];
                NetworkStream stream;
                foreach (TcpClient client in clients)
                {
                    if(client != exclude)
                        if (client.Connected)
                        {
                            buffer = System.Text.Encoding.UTF8.GetBytes(message);
                            stream = client.GetStream();
                            stream.Write(buffer, 0, buffer.Length);
                            stream.Flush();
                        }
                }
            }
        }

        public delegate void ConnectionEstablishedHandler(object obj, ConnectionEstablishedEventArg arg);
        public event ConnectionEstablishedHandler ConnectionEstablished;

        public delegate void ConnectionClosedHandler(object obj, ConnectionClosedEventArg arg);
        public event ConnectionClosedHandler ConnectionClosed;

        private void emitCEEvent(int id, string info)
        {
            ConnectionEstablishedEventArg evarg = new ConnectionEstablishedEventArg(id, info);
            ConnectionEstablished(this, evarg);
        }

        private void emitCCEvent(int id)
        {
            ConnectionClosedEventArg evarg = new ConnectionClosedEventArg(id);
            ConnectionClosed(this, evarg);
        }

        private void emitMREvent(string m,object sender)
        {
            lock ("mrev")
            {
                mr(m);
                Send(m, sender);
            }
        }
    }


    //////////////////////////////////////////////////////////////////////////////////////////
    // Get a text line (A popup dialog with a Text field)
    //////////////////////////////////////////////////////////////////////////////////////////

    class GetLineForm : System.Windows.Forms.Form
    {
        private string server = "";
        public string Server
        {
            get { return server; }
        }

        private TextBox t;

        public GetLineForm(System.Windows.Forms.Form parent, string caption, string title, string def)
        {
            t = new TextBox();
            Label l = new Label();
            Button b = new Button();

            Text = caption;

            l.Text = title;
            t.Text = def;
            b.Text = "Ok";

            l.Location = new Point(5, 5); l.Size = new Size(Width - 20, l.Height);
            t.Location = new Point(5, l.Bottom + 5); t.Size = new Size(Width - 20, t.Height);
            b.Location = new Point(5, t.Bottom + 5); b.Size = new Size(Width - 20, b.Height);

            Controls.Add(l);
            Controls.Add(t);
            Controls.Add(b);
            Size = new Size(l.Width + 20, l.Height + t.Height + b.Height + 60);
            MaximumSize = Size;
            MinimumSize = Size;
            StartPosition = FormStartPosition.CenterParent;

            b.Click += new EventHandler(okClicked);

            while (server == "")
                ShowDialog(parent);
        }

        private void okClicked(object o, EventArgs a)
        {
            if (t.Text != "")
            {
                server = t.Text;
                Close();
            }
            else
            {
                MessageBox.Show("Don't leave empty!", "Warning");
            }
        }
    }
}
