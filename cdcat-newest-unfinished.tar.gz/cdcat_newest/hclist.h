/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  List browser of catalog structure (hclist.h)
****************************************************************************/

#ifndef CDCAT_HCLIST_H_
#define CDCAT_HCLIST_H_

#include "base.h"

#include <QObject>

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

#define NORMAL_NODE 0
#define PD_NODE		1

#define MAX_SORTMOD 10


class DBNode;

class DBListItem
{
	public:
		int ntype;
		DBNode *dbnode;
		QString c[3];

		/* POS:
			0 - NotUsed/Reserved
			1 - P.dir
			2 - Catalog (Never occured)
			3 - CatLnk - Upper pos
			4 - Media
			5 - Directory
			6 - File
			7 - CatLnk - Bottom pos
			8 - NotUsed/Reserved		*/
		int sortmod;

	public:

		DBListItem(DBNode *connection,int _ntype=NORMAL_NODE);
		~DBListItem(void);

	public:
		static int sortc;
		static bool order;
		static bool clplaceu;

};

class MyListView;

typedef DBListItem * DBListItemPtr;
class DBNodeListModel : public QAbstractItemModel
{
	Q_OBJECT

	private:
		int sumRows; 
		MyListView *treeview;
		QList<DBListItem *> *lst;
		
	public:
		DBNode *n_root,*n_parent,*n_current;

	public:
		DBNodeListModel(DBNode *start,MyListView *parent = 0);
		~DBNodeListModel(void);
		
		void clear(void);
		void addItem(DBListItem *item);

		void update(void);
		QModelIndex getIndexOfNode(DBNode *n);

		DBListItem *firstNode(void) { return lst->first(); };
		DBListItem *lastNode(void)  { return lst->last(); };

		//have to implement:
	public:
		QModelIndex index(int row,int column,const QModelIndex& parent=QModelIndex()) const;
		QModelIndex parent(const QModelIndex& index) const;
		int	   rowCount(const QModelIndex& parent=QModelIndex()) const;
		int	   columnCount(const QModelIndex& parent=QModelIndex()) const;
		bool	   hasChildren(const QModelIndex& parent=QModelIndex()) const;
		QVariant   data(const QModelIndex& index,int role=Qt::DisplayRole) const;
		Qt::ItemFlags flags(const QModelIndex& index) const;
		
		void sort(int column,Qt::SortOrder order=Qt::AscendingOrder);
		
		QVariant	headerData(int section,Qt::Orientation orientation,int role=Qt::DisplayRole) const;

	signals: 
		void dataChanged(const QModelIndex & topLeft, const QModelIndex & bottomRight);

		void rowsRemoved(const QModelIndex & parent,int start,int end);
		void rowsAboutToBeRemoved(const QModelIndex & parent,int start,int end);
};

class MyListView : public QTreeView
{
	Q_OBJECT

	private:
		DBNodeListModel *model;

	public:
		MyListView(DBNode *start,QWidget *parent);
		~MyListView(void);

	public:
		bool isParent(DBNode *n);
		int setRoot(DBNode *newroot);

	public slots:
		int nread(DBNode *n,DBNode *setselected = NULL);
		//int movecursor(QTreeWidgetItem * current, QTreeWidgetItem * previous);
		int mdClick(const QModelIndex & index);
		int stepUp(void);
		int stepDown(void);

		int emitItemCh(void);
		int setCurrent_byPoint(QPoint p);

	protected:
		void keyPressEvent(QKeyEvent *e);
		void wheelEvent(QWheelEvent *e);

		void mousePressEvent(QMouseEvent *e);
		void mouseDoubleClickEvent(QMouseEvent *e);
		void mouseMoveEvent(QMouseEvent *e);
		void mouseReleaseEvent(QMouseEvent *e);

	signals:
		void openedItem(DBNode *n);
		void currItemChanged(DBNode *n);
};


class HCatListDWidget : public QDockWidget
{
	Q_OBJECT

	private:
		bool eAction;
	    MyListView *mlv;

	public:
	    HCatListDWidget(QWidget * parent = 0);
	    ~HCatListDWidget(void);

	public:
		void disableReceiveAction() { eAction = true; }
		void enableReceiveAction()  { eAction = true; }

	public slots:
	    int openNode(DBNode *n);
    	int mClick(const QModelIndex & index);
		int itemChanged(DBNode *n);
		int setRoot(DBNode *newroot);

	private slots:
		int nodeSuccesfullOpened(DBNode *n);
		int refreshColor(void);
	
	signals:
	    void hitItem(DBNode *n,bool pnode);
		void openedItem(DBNode *n);
	    
};


#endif
#endif
//end code.
