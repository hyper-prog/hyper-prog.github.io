/*
  TreeGenerator
  (OpenGL GLSL Environment generator)

  Copyright (C) Peter Deak (hyper80@gmail.com)
  http://hyperprog.com

  Platform: C++ Qt (http://qt.nokia.com)

  License GPL

  This program is only for test & education pusposely & fun ;-) */
#include "glew/GL/glew.h"

#include <QtCore>
#include <QtGui>
#include <QtSql>
#include <QtOpenGL>

#include "datadef.h"

#include "dconsole.h"

#include "db.h"
#include "tree.h"
#include "mainwindow.h"

HFactory * ElementParameters::factory = NULL;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

Db::Db(void)
{
        innerdb.clear();
}


Db::~Db(void)
{
        list<ElementParameters *>::iterator i;
        for(; !innerdb.empty() ;)
        {
                i = innerdb.begin();
        delete (*i);
                innerdb.erase(i);
        }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
TextureDatabase * TextureDatabase::instance = NULL;

TextureDatabase::TextureDatabase(void)
{
        texture_map.clear();
        texture_status.clear();
        readed=false;
        instance = this;
        path = "";
}

int TextureDatabase::read_textures(QString dir)
{
        if(readed)
                return 0;
        QFileInfoList files;
        QStringList filters;
    filters << "*.png";

        QDir *texdir = new QDir(dir);
        files = texdir->entryInfoList(filters,QDir::Files,QDir::Name);
        path = texdir->absolutePath();
        delete texdir;

        QList<QFileInfo>::iterator i;
        for(i=files.begin() ; i != files.end() ; ++i)
        {
                if(i->exists())
                {
                        texture_map[i->fileName()] = -1;
                        texture_status[i->fileName()] = 0;
                }
        }

        readed=true;
        return 0;
}

int TextureDatabase::fill_htablesfields(HTable *t)
{
        int idx;
        HDataField *f;

        t->firstField();
        while((f = t->nextField()) != NULL)
        {
                if	(
                                (f->sqlSelectHead().startsWith("texture_") && f->getWhoami() == "HCharHash")	 ||
                                (f->sqlSelectHead().startsWith("texturemask_") && f->getWhoami() == "HCharHash")
                        )
                {
                        HCharHash *h = (HCharHash *)f;

                        h->keys.clear();
                        h->values.clear();

                        idx=1;
                        QMap<QString, int>::const_iterator i = texture_map.constBegin();
                        while (i != texture_map.constEnd())
                        {
                                h->keys.push_back(i.key());
                                h->values.push_back(i.key());

                                ++idx;
                                ++i;
                        }
                }
        }
        return 0;
}

int TextureDatabase::getTexidByName(QString name)
{
        int idx;

        idx = texture_status.value(name,-1);
        if(idx == -1 )
        {
                QMessageBox::warning(0,"Text�ra database",QString("I can't find the labeled texture\nin the texture database!\n(%1)").arg(path + "/" + name));
                texture_status[name] = 2;
                return 0;
        }
        if(idx == 2 )
        {   //if the last failed
                return 0;
        }

        if(idx == 0) //unloaded
        {
                int k;
        QImage img_tex;
                img_tex.load(path + "/" + name);

                if(img_tex.isNull())
                {
                        QMessageBox::warning(0,"Texture loading",QString("Texture loading: Suck, I can't open the file:\n%1").arg(path + "/" + name));
                        texture_status[name] = 2;
                }
                texture_map[name] = k = board->bindTexture(img_tex,GL_TEXTURE_2D);
                texture_status[name] = 1;
                return k;
        }
        return texture_map[name];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

ElementParameters::ElementParameters(void)
{
        name="unnamed";
        state = 0;
        display_list = 0;
        triangles = 0;

        if(factory == NULL)
        {
                factory	= new HFactory(tdata_cont);
        }
}

HTable * ElementParameters::getAndIndependentHTableInstance(void)
{
        return NULL;
}

void ElementParameters::initializeLinkHTable(void)
{
        link = NULL;
}

void ElementParameters::sync(void)
{

}

void ElementParameters::drawMe(TreeGenerator *gen)
{

}

///////////////////////////////////////////////////////////////////////////////////////////////////

HTable * EnvParameters::getAndIndependentHTableInstance(void)
{
        return factory->genHTable("envparameters");
}

void EnvParameters::initializeLinkHTable(void)
{
        link = factory->genHTable("envparameters");
}

void EnvParameters::sync(void)
{
        if(link != NULL)
                copy_htable_to_envparameters(link,this);
}

void EnvParameters::drawMe(TreeGenerator *gen)
{
        ;
}

int copy_htable_to_envparameters(HTable *ht,EnvParameters *ep)
{
        ep->state = 0;
        ep->name = ht->fieldBySqlName("name")->getValue().toString();
        ep->tex_ground		=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_ground")->getValue().toString() );
        ep->mask_ground		=	TextureDatabase::instance->getTexidByName( "full.png" );

        ep->tex_sky			=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_sky")->getValue().toString() );
        ep->mask_sky		=	TextureDatabase::instance->getTexidByName( "full.png" );


        ep->startx			= ht->fieldBySqlName("startx")->getValue().toDouble();
        ep->endx			= ht->fieldBySqlName("endx")->getValue().toDouble();
        ep->startz			= ht->fieldBySqlName("startz")->getValue().toDouble();
        ep->endz			= ht->fieldBySqlName("endz")->getValue().toDouble();

        ep->partx			= ht->fieldBySqlName("partx")->getValue().toDouble();
        ep->partz			= ht->fieldBySqlName("partz")->getValue().toDouble();


        return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////

HTable * TreeParameters::getAndIndependentHTableInstance(void)
{
        return factory->genHTable("treeparameters");
}

void TreeParameters::initializeLinkHTable(void)
{
        link = factory->genHTable("treeparameters");
}

void TreeParameters::sync(void)
{
        if(link != NULL)
                copy_htable_to_treeparameters(link,this);
}

void TreeParameters::drawMe(TreeGenerator *gen)
{
        gen->buildTree(this);
}

int copy_htable_to_treeparameters(HTable *ht,TreeParameters *tp)
{
        tp->state = 0;

        tp->name = ht->fieldBySqlName("name")->getValue().toString();
        tp->startpos.x = ht->fieldBySqlName("startpos_x")->getValue().toDouble();
        tp->startpos.y = ht->fieldBySqlName("startpos_y")->getValue().toDouble();
        tp->startpos.z = ht->fieldBySqlName("startpos_z")->getValue().toDouble();
        tp->treestartpos = tp->startpos;

        tp->startdirection.x = ht->fieldBySqlName("startdirection_x")->getValue().toDouble();
        tp->startdirection.y = ht->fieldBySqlName("startdirection_y")->getValue().toDouble();
        tp->startdirection.z = ht->fieldBySqlName("startdirection_z")->getValue().toDouble();

        tp->directionVar.x = ht->fieldBySqlName("directionvar_x")->getValue().toDouble();
        tp->directionVar.y = ht->fieldBySqlName("directionvar_y")->getValue().toDouble();
        tp->directionVar.z = ht->fieldBySqlName("directionvar_z")->getValue().toDouble();
        tp->directionVarLength.x = ht->fieldBySqlName("directionvarlength_x")->getValue().toDouble();
        tp->directionVarLength.y = ht->fieldBySqlName("directionvarlength_y")->getValue().toDouble();
        tp->directionVarLength.z = ht->fieldBySqlName("directionvarlength_z")->getValue().toDouble();
        tp->dirGenFactorHeiht = ht->fieldBySqlName("dirgenfactorheiht")->getValue().toDouble();
        tp->dirGenFactorWidth = ht->fieldBySqlName("dirgenfactorwidth")->getValue().toDouble();
        tp->dirGenFactorFlat  = ht->fieldBySqlName("dirgenfactorflat")->getValue().toDouble();

        tp->trunkstartradius = ht->fieldBySqlName("trunkstartradius")->getValue().toDouble();
        tp->treestartradius = tp->trunkstartradius;

        tp->minimumradius = ht->fieldBySqlName("minimumradius")->getValue().toDouble();
        tp->trunkthinfactor = ht->fieldBySqlName("trunkthinfactor")->getValue().toDouble();
        tp->trunkfullness = ht->fieldBySqlName("trunkfullness")->getValue().toDouble();
        tp->segmentlength = ht->fieldBySqlName("segmentlength")->getValue().toDouble();
        tp->rootminheight = ht->fieldBySqlName("rootminheight")->getValue().toDouble();
        tp->rootmaxheight = ht->fieldBySqlName("rootmaxheight")->getValue().toDouble();

        tp->knob_plusrad = ht->fieldBySqlName("knob_plusrad")->getValue().toDouble();
        tp->knob_centerheight = ht->fieldBySqlName("knob_centerheight")->getValue().toDouble();
        tp->knob_length = ht->fieldBySqlName("knob_length")->getValue().toDouble();

        tp->minsegmentnum = ht->fieldBySqlName("minsegmentnum")->getValue().toDouble();
        tp->maxsegmentnum = ht->fieldBySqlName("maxsegmentnum")->getValue().toDouble();
        tp->branchShorteningFactor = ht->fieldBySqlName("branchshorteningfactor")->getValue().toDouble();
        tp->globalMinBranchLength = ht->fieldBySqlName("globalminbranchlength")->getValue().toDouble();
        tp->hashFactor = ht->fieldBySqlName("hashfactor")->getValue().toDouble();
        tp->branchFactor = ht->fieldBySqlName("branchfactor")->getValue().toDouble();
        tp->dirChFactor = ht->fieldBySqlName("dirchfactor")->getValue().toDouble();
        tp->smallBranchEndFactor = ht->fieldBySqlName("smallbranchendfactor")->getValue().toDouble();
        tp->endingBranchRadius = ht->fieldBySqlName("endingbranchradius")->getValue().toDouble();
        tp->branchingMinRadFactor = ht->fieldBySqlName("branchingminradfactor")->getValue().toDouble();
        tp->branchingMaxRadFactor = ht->fieldBySqlName("branchingmaxradfactor")->getValue().toDouble();
        tp->maxLeafBranchRadius = ht->fieldBySqlName("maxleafbranchradius")->getValue().toDouble();
        tp->leafFactor = ht->fieldBySqlName("leaffactor")->getValue().toDouble();

        tp->ttex_fullupnum = ht->fieldBySqlName("ttex_fullupnum")->getValue().toInt();
        tp->maxdeep = ht->fieldBySqlName("maxdeep")->getValue().toInt();

        tp->tex_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_leaf")->getValue().toString() );
        tp->mask_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texturemask_leaf")->getValue().toString() );
        tp->tex_trunk	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_trunk")->getValue().toString() );
        tp->mask_trunk	=	TextureDatabase::instance->getTexidByName( "full.png" );

        tp->leaftype = 1;
        tp->leafObject = (void *) new LeafParameters();
        ((LeafParameters *)(tp->leafObject))->leafLength = ht->fieldBySqlName("leaflength")->getValue().toDouble();
        ((LeafParameters *)(tp->leafObject))->leafWidth = ht->fieldBySqlName("leafwidth")->getValue().toDouble();

        return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
HTable * GrassParameters::getAndIndependentHTableInstance(void)
{
        return factory->genHTable("grassparameters");
}

void GrassParameters::initializeLinkHTable(void)
{
        link = factory->genHTable("grassparameters");
}

void GrassParameters::sync(void)
{
        if(link != NULL)
                copy_htable_to_grassparameters(link,this);
}

void GrassParameters::drawMe(TreeGenerator *gen)
{
        gen->buildGrass(this);
}

int copy_htable_to_grassparameters(HTable *ht,GrassParameters *gp)
{
        gp->state = 0;

        gp->name = ht->fieldBySqlName("name")->getValue().toString();

        gp->sx = ht->fieldBySqlName("startinx")->getValue().toDouble();
        gp->sz = ht->fieldBySqlName("startinz")->getValue().toDouble();
        gp->ex = ht->fieldBySqlName("endinx")->getValue().toDouble();
        gp->ez = ht->fieldBySqlName("endinz")->getValue().toDouble();
        gp->y = ht->fieldBySqlName("iny")->getValue().toDouble();

        gp->density = ht->fieldBySqlName("density")->getValue().toDouble();

        gp->startpos.x = ht->fieldBySqlName("startpos_x")->getValue().toDouble();
        gp->startpos.y = ht->fieldBySqlName("startpos_y")->getValue().toDouble();
        gp->startpos.z = ht->fieldBySqlName("startpos_z")->getValue().toDouble();

        gp->dir.x = ht->fieldBySqlName("startdirection_x")->getValue().toDouble();
        gp->dir.y = ht->fieldBySqlName("startdirection_y")->getValue().toDouble();
        gp->dir.z = ht->fieldBySqlName("startdirection_z")->getValue().toDouble();

        gp->sidedir.x = ht->fieldBySqlName("sidedir_x")->getValue().toDouble();
        gp->sidedir.y = ht->fieldBySqlName("sidedir_y")->getValue().toDouble();
        gp->sidedir.z = ht->fieldBySqlName("sidedir_z")->getValue().toDouble();

        gp->height = ht->fieldBySqlName("height")->getValue().toDouble();
        gp->minHeight = ht->fieldBySqlName("minheight")->getValue().toDouble();
        gp->maxHeight = ht->fieldBySqlName("maxheight")->getValue().toDouble();
        gp->startthick = ht->fieldBySqlName("startthick")->getValue().toDouble();
        gp->endthick = ht->fieldBySqlName("endthick")->getValue().toDouble();
        gp->segmentlength = ht->fieldBySqlName("segmentlength")->getValue().toDouble();
        gp->plusflexfactor = ht->fieldBySqlName("plusflexfactor")->getValue().toDouble();

        gp->directionVar.x = ht->fieldBySqlName("directionvar_x")->getValue().toDouble();
        gp->directionVar.y = ht->fieldBySqlName("directionvar_y")->getValue().toDouble();
        gp->directionVar.z = ht->fieldBySqlName("directionvar_z")->getValue().toDouble();

        gp->directionVarGenMin.x = ht->fieldBySqlName("directionvargenmin_x")->getValue().toDouble();
        gp->directionVarGenMin.y = ht->fieldBySqlName("directionvargenmin_y")->getValue().toDouble();
        gp->directionVarGenMin.z = ht->fieldBySqlName("directionvargenmin_z")->getValue().toDouble();
        gp->directionVarGenMax.x = ht->fieldBySqlName("directionvargenmax_x")->getValue().toDouble();
        gp->directionVarGenMax.y = ht->fieldBySqlName("directionvargenmax_y")->getValue().toDouble();
        gp->directionVarGenMax.z = ht->fieldBySqlName("directionvargenmax_z")->getValue().toDouble();

        gp->number = ht->fieldBySqlName("number")->getValue().toInt();

        gp->maxNumber = ht->fieldBySqlName("maxnumber")->getValue().toInt();
        gp->minNumber = ht->fieldBySqlName("minnumber")->getValue().toInt();

        gp->tex_grass	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_leaf")->getValue().toString() );
        gp->mask_grass	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texturemask_leaf")->getValue().toString() );

        return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
HTable * BigLeafParameters::getAndIndependentHTableInstance(void)
{
        return factory->genHTable("bigleafparameters");
}

void BigLeafParameters::initializeLinkHTable(void)
{
        link = factory->genHTable("bigleafparameters");
}

void BigLeafParameters::sync(void)
{
        if(link != NULL)
                copy_htable_to_bigleafparameters(link,this);
}

void BigLeafParameters::drawMe(TreeGenerator *gen)
{
        gen->generateBigLeaf(this);
}

int copy_htable_to_bigleafparameters(HTable *ht,BigLeafParameters *bp)
{
        bp->state = 0;

        bp->name = ht->fieldBySqlName("name")->getValue().toString();

        bp->texmode = ht->fieldBySqlName("texmode")->getValue().toInt();

        bp->startpos.x = ht->fieldBySqlName("startpos_x")->getValue().toDouble();
        bp->startpos.y = ht->fieldBySqlName("startpos_y")->getValue().toDouble();
        bp->startpos.z = ht->fieldBySqlName("startpos_z")->getValue().toDouble();

        bp->updir.x = ht->fieldBySqlName("updirection_x")->getValue().toDouble();
        bp->updir.y = ht->fieldBySqlName("updirection_y")->getValue().toDouble();
        bp->updir.z = ht->fieldBySqlName("updirection_z")->getValue().toDouble();

        bp->number = ht->fieldBySqlName("number")->getValue().toDouble();
        bp->maxNumber = ht->fieldBySqlName("minnumber")->getValue().toDouble();
        bp->minNumber = ht->fieldBySqlName("maxnumber")->getValue().toDouble();

        //bp->leandir.x = ht->fieldBySqlName("")->getValue().toDouble();
        //bp->leandir.y = ht->fieldBySqlName("")->getValue().toDouble();
        //bp->leandir.z = ht->fieldBySqlName("")->getValue().toDouble();

        bp->alpha = ht->fieldBySqlName("alpha")->getValue().toDouble();
        bp->beta = ht->fieldBySqlName("beta")->getValue().toDouble();
        //bp->startangle = ht->fieldBySqlName("")->getValue().toDouble();
        bp->minStartangle = ht->fieldBySqlName("minstartangle")->getValue().toDouble();
        bp->maxStartangle = ht->fieldBySqlName("maxstartangle")->getValue().toDouble();
        //bp->endangle = ht->fieldBySqlName("")->getValue().toDouble();
        bp->minEndangle = ht->fieldBySqlName("minendangle")->getValue().toDouble();
        bp->maxEndangle = ht->fieldBySqlName("maxendangle")->getValue().toDouble();
        //bp->length = ht->fieldBySqlName("")->getValue().toDouble();
        bp->minLength = ht->fieldBySqlName("minlength")->getValue().toDouble();
        bp->maxLength = ht->fieldBySqlName("maxlength")->getValue().toDouble();
        bp->width = ht->fieldBySqlName("width")->getValue().toDouble();
        bp->segmentlength = ht->fieldBySqlName("segmentlength")->getValue().toDouble();

        bp->plusflexfactor_all = ht->fieldBySqlName("plusflexfactor_all")->getValue().toDouble();
        bp->plusflexfactor_leafend = ht->fieldBySqlName("plusflexfactor_leafend")->getValue().toDouble();

        bp->tex_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_leaf")->getValue().toString() );
        bp->mask_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texturemask_leaf")->getValue().toString() );

        return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////

HTable * PalmTreeParameters::getAndIndependentHTableInstance(void)
{
        return factory->genHTable("palmtreeparameters");
}

void PalmTreeParameters::initializeLinkHTable(void)
{
        link = factory->genHTable("palmtreeparameters");
}

void PalmTreeParameters::sync(void)
{
        if(link != NULL)
                copy_htable_to_palmtreeparameters(link,this);
}

void PalmTreeParameters::drawMe(TreeGenerator *gen)
{
        gen->buildTree(this);
}

int copy_htable_to_palmtreeparameters(HTable *ht,PalmTreeParameters *tp)
{
    tp->state = 0;

    tp->name = ht->fieldBySqlName("name")->getValue().toString();
    tp->startpos.x = ht->fieldBySqlName("startpos_x")->getValue().toDouble();
    tp->startpos.y = ht->fieldBySqlName("startpos_y")->getValue().toDouble();
    tp->startpos.z = ht->fieldBySqlName("startpos_z")->getValue().toDouble();
    tp->treestartpos = tp->startpos;

    tp->trunkstartradius = ht->fieldBySqlName("trunkstartradius")->getValue().toDouble();
    tp->treestartradius = tp->trunkstartradius;

    tp->trunkfullness = ht->fieldBySqlName("trunkfullness")->getValue().toDouble();

    tp->rootmaxheight = ht->fieldBySqlName("rootmaxheight")->getValue().toDouble();
    tp->rootminheight = tp->rootmaxheight;

    tp->knob_plusrad = ht->fieldBySqlName("knob_plusrad")->getValue().toDouble();
    tp->knob_centerheight = ht->fieldBySqlName("knob_centerheight")->getValue().toDouble();
    tp->knob_length = ht->fieldBySqlName("knob_length")->getValue().toDouble();

    tp->segmentlength = ht->fieldBySqlName("segmentlength")->getValue().toDouble();

    tp->minsegmentnum = ht->fieldBySqlName("minsegmentnum")->getValue().toDouble();
    tp->maxsegmentnum = ht->fieldBySqlName("maxsegmentnum")->getValue().toDouble();

    tp->hashFactor = 0.0;
    tp->branchFactor = 0.0;

    tp->tex_trunk	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_trunk")->getValue().toString() );
    tp->mask_trunk	=	TextureDatabase::instance->getTexidByName( "full.png" );

    tp->trunkthinfactor = ht->fieldBySqlName("trunkthinfactor")->getValue().toDouble();

    tp->startdirection.x = ht->fieldBySqlName("startdirection_x")->getValue().toDouble();
    tp->startdirection.y = ht->fieldBySqlName("startdirection_y")->getValue().toDouble();
    tp->startdirection.z = ht->fieldBySqlName("startdirection_z")->getValue().toDouble();

    tp->directionVar.x = ht->fieldBySqlName("directionvar_x")->getValue().toDouble();
    tp->directionVar.y = ht->fieldBySqlName("directionvar_y")->getValue().toDouble();
    tp->directionVar.z = ht->fieldBySqlName("directionvar_z")->getValue().toDouble();
    tp->directionVarLength.x = ht->fieldBySqlName("directionvarlength_x")->getValue().toDouble();
    tp->directionVarLength.y = ht->fieldBySqlName("directionvarlength_y")->getValue().toDouble();
    tp->directionVarLength.z = ht->fieldBySqlName("directionvarlength_z")->getValue().toDouble();

    tp->ttex_fullupnum = ht->fieldBySqlName("ttex_fullupnum")->getValue().toInt();

    tp->leaftype = 2;
    tp->leafObject = (void *) new BigLeafParameters();

    ((BigLeafParameters *)(tp->leafObject))->updir = tp->startdirection;

    ((BigLeafParameters *)(tp->leafObject))->number = ht->fieldBySqlName("number")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->maxNumber = ht->fieldBySqlName("maxnumber")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->minNumber = ht->fieldBySqlName("minnumber")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->alpha = ht->fieldBySqlName("alpha")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->beta = ht->fieldBySqlName("beta")->getValue().toDouble();

    ((BigLeafParameters *)(tp->leafObject))->texmode = ht->fieldBySqlName("texmode")->getValue().toInt();

    ((BigLeafParameters *)(tp->leafObject))->minStartangle = ht->fieldBySqlName("minstartangle")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->maxStartangle = ht->fieldBySqlName("maxstartangle")->getValue().toDouble();

    ((BigLeafParameters *)(tp->leafObject))->minEndangle = ht->fieldBySqlName("minendangle")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->maxEndangle = ht->fieldBySqlName("maxendangle")->getValue().toDouble();

    ((BigLeafParameters *)(tp->leafObject))->minLength = ht->fieldBySqlName("minlength")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->maxLength = ht->fieldBySqlName("maxlength")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->width = ht->fieldBySqlName("width")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->segmentlength = ht->fieldBySqlName("leafsegmentlength")->getValue().toDouble();

    ((BigLeafParameters *)(tp->leafObject))->plusflexfactor_all = ht->fieldBySqlName("plusflexfactor_all")->getValue().toDouble();
    ((BigLeafParameters *)(tp->leafObject))->plusflexfactor_leafend = ht->fieldBySqlName("plusflexfactor_leafend")->getValue().toDouble();

    ((BigLeafParameters *)(tp->leafObject))->tex_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texture_leaf")->getValue().toString() );
    ((BigLeafParameters *)(tp->leafObject))->mask_leaf	=	TextureDatabase::instance->getTexidByName( ht->fieldBySqlName("texturemask_leaf")->getValue().toString() );



    return 0;
}

//end code.
