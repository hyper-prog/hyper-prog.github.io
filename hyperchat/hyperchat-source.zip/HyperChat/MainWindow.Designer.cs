﻿namespace HyperChat
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonNetAction = new System.Windows.Forms.Button();
            this.msgBody = new System.Windows.Forms.RichTextBox();
            this.sendMsg = new System.Windows.Forms.TextBox();
            this.buttonSend = new System.Windows.Forms.Button();
            this.drawPanel = new System.Windows.Forms.Panel();
            this.textNick = new System.Windows.Forms.TextBox();
            this.labelWorkMode = new System.Windows.Forms.Label();
            this.comboWorkMode = new System.Windows.Forms.ComboBox();
            this.labelNick = new System.Windows.Forms.Label();
            this.groupBoxNetStuff = new System.Windows.Forms.GroupBox();
            this.buttonWhite = new System.Windows.Forms.Button();
            this.buttonRed = new System.Windows.Forms.Button();
            this.buttonBlue = new System.Windows.Forms.Button();
            this.buttonGreen = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonStyle = new System.Windows.Forms.Button();
            this.buttonYellow = new System.Windows.Forms.Button();
            this.buttonOrange = new System.Windows.Forms.Button();
            this.panelStyle = new System.Windows.Forms.Panel();
            this.buttonSavePics = new System.Windows.Forms.Button();
            this.buttonMagenta = new System.Windows.Forms.Button();
            this.buttonBlack = new System.Windows.Forms.Button();
            this.groupBoxNetStuff.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonExit.Location = new System.Drawing.Point(513, 10);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Quit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonNetAction
            // 
            this.buttonNetAction.Location = new System.Drawing.Point(233, 11);
            this.buttonNetAction.Name = "buttonNetAction";
            this.buttonNetAction.Size = new System.Drawing.Size(91, 23);
            this.buttonNetAction.TabIndex = 3;
            this.buttonNetAction.Text = "Connect";
            this.buttonNetAction.UseVisualStyleBackColor = true;
            this.buttonNetAction.Click += new System.EventHandler(this.buttonNetAction_Click);
            // 
            // msgBody
            // 
            this.msgBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.msgBody.Location = new System.Drawing.Point(12, 87);
            this.msgBody.Name = "msgBody";
            this.msgBody.Size = new System.Drawing.Size(344, 226);
            this.msgBody.TabIndex = 4;
            this.msgBody.Text = "";
            // 
            // sendMsg
            // 
            this.sendMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.sendMsg.Location = new System.Drawing.Point(12, 319);
            this.sendMsg.Name = "sendMsg";
            this.sendMsg.Size = new System.Drawing.Size(263, 20);
            this.sendMsg.TabIndex = 5;
            this.sendMsg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sendMsg_KeyPress);
            // 
            // buttonSend
            // 
            this.buttonSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSend.Location = new System.Drawing.Point(281, 317);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 6;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // drawPanel
            // 
            this.drawPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.drawPanel.BackColor = System.Drawing.Color.Black;
            this.drawPanel.Location = new System.Drawing.Point(362, 87);
            this.drawPanel.Name = "drawPanel";
            this.drawPanel.Size = new System.Drawing.Size(226, 226);
            this.drawPanel.TabIndex = 7;
            this.drawPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.drawPanel_Paint);
            this.drawPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.drawPanel_MouseMove);
            this.drawPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.drawPanel_MouseDown);
            this.drawPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.drawPanel_MouseUp);
            // 
            // textNick
            // 
            this.textNick.Location = new System.Drawing.Point(45, 61);
            this.textNick.Name = "textNick";
            this.textNick.Size = new System.Drawing.Size(100, 20);
            this.textNick.TabIndex = 8;
            // 
            // labelWorkMode
            // 
            this.labelWorkMode.AutoSize = true;
            this.labelWorkMode.Location = new System.Drawing.Point(6, 16);
            this.labelWorkMode.Name = "labelWorkMode";
            this.labelWorkMode.Size = new System.Drawing.Size(76, 13);
            this.labelWorkMode.TabIndex = 9;
            this.labelWorkMode.Text = "Network mode";
            this.labelWorkMode.Click += new System.EventHandler(this.labelWorkMode_Click);
            // 
            // comboWorkMode
            // 
            this.comboWorkMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboWorkMode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboWorkMode.Items.AddRange(new object[] {
            "Client mode",
            "Server mode"});
            this.comboWorkMode.Location = new System.Drawing.Point(95, 13);
            this.comboWorkMode.Name = "comboWorkMode";
            this.comboWorkMode.Size = new System.Drawing.Size(121, 21);
            this.comboWorkMode.TabIndex = 10;
            this.comboWorkMode.Tag = "";
            this.comboWorkMode.SelectedIndexChanged += new System.EventHandler(this.comboWorkMode_SelectedIndexChanged);
            // 
            // labelNick
            // 
            this.labelNick.AutoSize = true;
            this.labelNick.Location = new System.Drawing.Point(12, 64);
            this.labelNick.Name = "labelNick";
            this.labelNick.Size = new System.Drawing.Size(29, 13);
            this.labelNick.TabIndex = 11;
            this.labelNick.Text = "Nick";
            // 
            // groupBoxNetStuff
            // 
            this.groupBoxNetStuff.Controls.Add(this.labelWorkMode);
            this.groupBoxNetStuff.Controls.Add(this.comboWorkMode);
            this.groupBoxNetStuff.Controls.Add(this.buttonNetAction);
            this.groupBoxNetStuff.Location = new System.Drawing.Point(12, 10);
            this.groupBoxNetStuff.Name = "groupBoxNetStuff";
            this.groupBoxNetStuff.Size = new System.Drawing.Size(343, 42);
            this.groupBoxNetStuff.TabIndex = 12;
            this.groupBoxNetStuff.TabStop = false;
            this.groupBoxNetStuff.Text = "Network";
            this.groupBoxNetStuff.Enter += new System.EventHandler(this.groupBoxNetStuff_Enter);
            // 
            // buttonWhite
            // 
            this.buttonWhite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonWhite.BackColor = System.Drawing.Color.White;
            this.buttonWhite.Location = new System.Drawing.Point(362, 61);
            this.buttonWhite.Name = "buttonWhite";
            this.buttonWhite.Size = new System.Drawing.Size(24, 20);
            this.buttonWhite.TabIndex = 13;
            this.buttonWhite.UseVisualStyleBackColor = false;
            this.buttonWhite.Click += new System.EventHandler(this.buttonWhite_Click);
            // 
            // buttonRed
            // 
            this.buttonRed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRed.BackColor = System.Drawing.Color.Red;
            this.buttonRed.Location = new System.Drawing.Point(390, 61);
            this.buttonRed.Name = "buttonRed";
            this.buttonRed.Size = new System.Drawing.Size(24, 20);
            this.buttonRed.TabIndex = 14;
            this.buttonRed.UseVisualStyleBackColor = false;
            this.buttonRed.Click += new System.EventHandler(this.buttonRed_Click);
            // 
            // buttonBlue
            // 
            this.buttonBlue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBlue.BackColor = System.Drawing.Color.LightSkyBlue;
            this.buttonBlue.Location = new System.Drawing.Point(418, 61);
            this.buttonBlue.Name = "buttonBlue";
            this.buttonBlue.Size = new System.Drawing.Size(24, 20);
            this.buttonBlue.TabIndex = 15;
            this.buttonBlue.UseVisualStyleBackColor = false;
            this.buttonBlue.Click += new System.EventHandler(this.buttonBlue_Click);
            // 
            // buttonGreen
            // 
            this.buttonGreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGreen.BackColor = System.Drawing.Color.Lime;
            this.buttonGreen.Location = new System.Drawing.Point(446, 61);
            this.buttonGreen.Name = "buttonGreen";
            this.buttonGreen.Size = new System.Drawing.Size(24, 20);
            this.buttonGreen.TabIndex = 16;
            this.buttonGreen.UseVisualStyleBackColor = false;
            this.buttonGreen.Click += new System.EventHandler(this.buttonGreen_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClear.Location = new System.Drawing.Point(555, 316);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(33, 19);
            this.buttonClear.TabIndex = 17;
            this.buttonClear.Text = "C";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonStyle
            // 
            this.buttonStyle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStyle.Location = new System.Drawing.Point(499, 316);
            this.buttonStyle.Name = "buttonStyle";
            this.buttonStyle.Size = new System.Drawing.Size(10, 19);
            this.buttonStyle.TabIndex = 18;
            this.buttonStyle.UseVisualStyleBackColor = true;
            this.buttonStyle.Click += new System.EventHandler(this.buttonStyle_Click);
            // 
            // buttonYellow
            // 
            this.buttonYellow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonYellow.BackColor = System.Drawing.Color.Yellow;
            this.buttonYellow.Location = new System.Drawing.Point(474, 61);
            this.buttonYellow.Name = "buttonYellow";
            this.buttonYellow.Size = new System.Drawing.Size(24, 20);
            this.buttonYellow.TabIndex = 19;
            this.buttonYellow.UseVisualStyleBackColor = false;
            this.buttonYellow.Click += new System.EventHandler(this.buttonYellow_Click);
            // 
            // buttonOrange
            // 
            this.buttonOrange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOrange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonOrange.Location = new System.Drawing.Point(502, 61);
            this.buttonOrange.Name = "buttonOrange";
            this.buttonOrange.Size = new System.Drawing.Size(24, 20);
            this.buttonOrange.TabIndex = 20;
            this.buttonOrange.UseVisualStyleBackColor = false;
            this.buttonOrange.Click += new System.EventHandler(this.buttonOrange_Click);
            // 
            // panelStyle
            // 
            this.panelStyle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelStyle.Location = new System.Drawing.Point(513, 316);
            this.panelStyle.Name = "panelStyle";
            this.panelStyle.Size = new System.Drawing.Size(36, 19);
            this.panelStyle.TabIndex = 21;
            this.panelStyle.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStyle_Paint);
            // 
            // buttonSavePics
            // 
            this.buttonSavePics.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSavePics.Location = new System.Drawing.Point(362, 317);
            this.buttonSavePics.Name = "buttonSavePics";
            this.buttonSavePics.Size = new System.Drawing.Size(75, 23);
            this.buttonSavePics.TabIndex = 23;
            this.buttonSavePics.Text = " Save to file";
            this.buttonSavePics.UseVisualStyleBackColor = true;
            this.buttonSavePics.Click += new System.EventHandler(this.buttonSavePics_Click);
            // 
            // buttonMagenta
            // 
            this.buttonMagenta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMagenta.BackColor = System.Drawing.Color.Magenta;
            this.buttonMagenta.Location = new System.Drawing.Point(530, 61);
            this.buttonMagenta.Name = "buttonMagenta";
            this.buttonMagenta.Size = new System.Drawing.Size(24, 20);
            this.buttonMagenta.TabIndex = 24;
            this.buttonMagenta.UseVisualStyleBackColor = false;
            this.buttonMagenta.Click += new System.EventHandler(this.buttonMagenta_Click);
            // 
            // buttonBlack
            // 
            this.buttonBlack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBlack.BackColor = System.Drawing.Color.Black;
            this.buttonBlack.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonBlack.Location = new System.Drawing.Point(558, 61);
            this.buttonBlack.Name = "buttonBlack";
            this.buttonBlack.Size = new System.Drawing.Size(24, 20);
            this.buttonBlack.TabIndex = 25;
            this.buttonBlack.UseVisualStyleBackColor = false;
            this.buttonBlack.Click += new System.EventHandler(this.buttonBlack_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 345);
            this.Controls.Add(this.buttonBlack);
            this.Controls.Add(this.buttonMagenta);
            this.Controls.Add(this.buttonSavePics);
            this.Controls.Add(this.panelStyle);
            this.Controls.Add(this.buttonOrange);
            this.Controls.Add(this.buttonYellow);
            this.Controls.Add(this.buttonStyle);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonGreen);
            this.Controls.Add(this.buttonBlue);
            this.Controls.Add(this.buttonRed);
            this.Controls.Add(this.buttonWhite);
            this.Controls.Add(this.groupBoxNetStuff);
            this.Controls.Add(this.labelNick);
            this.Controls.Add(this.textNick);
            this.Controls.Add(this.drawPanel);
            this.Controls.Add(this.buttonSend);
            this.Controls.Add(this.sendMsg);
            this.Controls.Add(this.msgBody);
            this.Controls.Add(this.buttonExit);
            this.MinimumSize = new System.Drawing.Size(600, 372);
            this.Name = "MainWindow";
            this.Text = "HyperChat C# :-)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainWindow_FormClosing);
            this.groupBoxNetStuff.ResumeLayout(false);
            this.groupBoxNetStuff.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonNetAction;
        private System.Windows.Forms.RichTextBox msgBody;
        private System.Windows.Forms.TextBox sendMsg;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.Panel drawPanel;
        private System.Windows.Forms.TextBox textNick;
        private System.Windows.Forms.Label labelWorkMode;
        private System.Windows.Forms.Label labelNick;
        private System.Windows.Forms.GroupBox groupBoxNetStuff;
        private System.Windows.Forms.Button buttonWhite;
        private System.Windows.Forms.Button buttonRed;
        private System.Windows.Forms.Button buttonBlue;
        private System.Windows.Forms.Button buttonGreen;
        private System.Windows.Forms.ComboBox comboWorkMode;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonStyle;
        private System.Windows.Forms.Button buttonYellow;
        private System.Windows.Forms.Button buttonOrange;
        private System.Windows.Forms.Panel panelStyle;
        private System.Windows.Forms.Button buttonSavePics;
        private System.Windows.Forms.Button buttonMagenta;
        private System.Windows.Forms.Button buttonBlack;
    }


}

