/*
  TreeGenerator
  (OpenGL GLSL Environment generator)

  Copyright (C) Peter Deak (hyper80@gmail.com)
  http://hyperprog.com

  Platform: C++ Qt (http://qt.nokia.com)

  License GPL

  This program is only for test & education pusposely & fun ;-) */
#include <QtGui/QApplication>
#include "mainwindow.h"

#include <datalib.h>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	HSqlInterface::setSqlMode("QtSqlite_Win");
    MainWindow w;
    w.show();
    return a.exec();
}
