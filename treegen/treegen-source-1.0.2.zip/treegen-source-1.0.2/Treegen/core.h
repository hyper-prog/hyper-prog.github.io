/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */
#ifndef CORE_H
#define CORE_H

#include <QtCore>
#include <QtGui>
#include <QtOpenGL>

class Vertex
{
public:
	double x,y,z,w;

	Vertex(void) 
		{ x=0; y=0; z=0; w=1; }
	Vertex(double xx,double yy,double zz) 
		{ x=xx; y=yy; z=zz; w=1; }

	inline double X(void) { return w==1 ? x : (x/w); }
	inline double Y(void) { return w==1 ? y : (y/w); }
	inline double Z(void) { return w==1 ? z : (z/w); }

	Vertex *operator=(Vertex *v) 
		{
			x=v->x; y=v->y;	z=v->z;	w=v->w;
			return this;
		};

	void add(Vertex *v);

	void normalizeXYZvect(void);
	void addVectWithLength(Vertex *v,double length);

	void toOpenGL(void);
	void setNormalThisMinus(Vertex *v);
	QString toString(void);

#ifdef CORE_DEBUG
	void toSDebug(void);
#endif //CORE_DEBUG
};

class Matrix4x4
{
public:
	double d[16];

	Matrix4x4(void);
	inline void   set(int o,int s,double data) 
		{ d[o*4+s] = data; }
	inline double get(int o,int s) 
		{ return d[o*4+s]; }

	void mulVertex(Vertex* v);
	void mulMe(Matrix4x4* m);
	void setTo(Matrix4x4* m);
	void setColTo(int col,Vertex *v);
	Vertex *getCol(int col);
	#ifdef CORE_DEBUG
	void toSDebug(void);
	#endif //CORE_DEBUG
};

Vertex* ringGenerator(int n,Vertex *cen,Vertex *dir,double r,int m=0);
Vertex*	getRandomDirection(Vertex *parentdir,Vertex *dlen,Vertex *startpoint,Vertex *treestartpoint,
						   double parentradius,double hfactor,double wfactor,double tfactor);  

Vertex* normalFrom3Vertex(Vertex *a,Vertex *b,Vertex *c);
void setNormalFrom3Vertex(Vertex *a,Vertex *b,Vertex *c);


#endif
