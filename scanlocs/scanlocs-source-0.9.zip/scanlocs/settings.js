var zoomfactor = 8;
var center_lat = 47.523254;
var center_long = 21.628968;
