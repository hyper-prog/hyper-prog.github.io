/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 

  Core DataBase module (dbase.h)
****************************************************************************/
#ifndef CDCAT_DBASE_HEADER
#define CDCAT_DBASE_HEADER

#include <QtCore>

// values for class DBNode::type
#define HC_UNINITIALIZED 0 
#define HC_CATALOG       1
#define HC_MEDIA         2 
#define HC_DIRECTORY     3 
#define HC_FILE          4 
#define HC_MP3TAG        5 
#define HC_CONTENT       6
#define HC_CATLNK        7
#define HC_ARCHIV        8 

//values for class DBMedia::type
#define UNKNOWN          0
#define CD               1
#define DVD              2
#define HARDDISC         3 
#define FLOPPY           4
#define NETPLACE         5 
#define FLASHDRV         6
#define OTHERD           7
#define AUDIOCD          8

//values for class DBFile::sizeType
#define BYTE             0 
#define KBYTE            1
#define MBYTE            2
#define GBYTE            3

//values for class DataBase::sortM( value )
#define NUMBER           0
#define NAME             1
#define TYPE             2
#define TIME             3

#define MAX_STORED_SIZE (128*1024)

class QFileInfo;
class CConfig;

class DBActionHandler : public QObject
{
	Q_OBJECT
	
	private:
		bool err;

	public:

		DBActionHandler(void)
			{ err = false; };
		~DBActionHandler(void)
			{	};

	public:
		bool iserror(void)  { return err; }
		void seterror(void) { err = true; }
		void reset(void)    { err = false; }
	
		virtual int     errorOccured(int code,QString msg,QString a1="",QString a2="",QString a3="");
		virtual QString textQuestion(QString msg);
		virtual int     chooseQuestion(QString msg,QString a1="",QString a2="",QString a3="");
		virtual void    warningMessage(QString msg);
};

class DBMedia;
class DBNode : public QObject
{
	Q_OBJECT

	public:
		int type; /*
				0 - uninitialized 
				1 - catalog 
				2 - media
				3 - directory     
				4 - file    
				5 - mp3tag
				6 - content   
				7 - catlnk   
				8 - archive.prop.		*/ 

		DBNode *next;   //neighbour node. (Same level)
		DBNode *child;  //one level below
		DBNode *parent; //the parent element (Upper level)

		// see the DB* classes below
		QObject *DBdata;
  
	public:
		/** Constructor t:UNINITIALIZED , p:NULL */
		DBNode(void);    
  
		/** Constructor t:type , p:parent */
		DBNode(int t,DBNode *p);    
  
		/** Destructor frees all memory allocation */  
		~DBNode(void);

		/** return the name of the node,which can be media name, catalog name,
			file name, directory name */
		QString getNameOf(void); 

		/** return the last modification date of the node,which can be media, catalog,
			file, directory */
		QDateTime getLastModOf(void); 

		/** return the full path of the node. */
		QString getFullPath(void);   
			
		/** tell to the database that you modified it, and save the modification time. */
		void touchDB(void);

		/** Vertical index of the this element */
		int v_idx(bool skip_files=false);
		
		/** Return the i'th child of the node */
		DBNode* th_child(int idx,bool skip_files=false);

		/** Get the media ptr of this node */
		DBMedia *getMediaPtr(void);

		/** Get the owner's name of this node*/
		QString getOwnerOf(void);

		/** Get comment of this node*/
		QString getCommentOf(void);
		void    setCommentOf(QString c);

};

/*
 *    DB ... classes:
 */ 

/** Catalog type node. Type number is 1 = HC_CATALOG */
class DBCatalog : public QObject 
{
	Q_OBJECT

	public:
		QString name;
		QString owner;
		QString comment;
		/** Readed path */
		QString rpath; 

		/** Writed to the disc  1=yes 0=no */
		int  writed; 

		/** Locally encoded file name of the database. (If you opened it or save it yet.) */
		char filename[256];    
			
		QDateTime modification;

		/** If the database opened from an existing file it contains
			the version of the datafile. */
		QString fileversion;

		/** Tell to the database that you modified it, and save the modification time. */
		void touch(void);
		
	public:
		DBCatalog(void);
		~DBCatalog(void);
  
		/** n:name , o:owner , c:comment */
		DBCatalog (QString n,QString o,QString c);
		/** n:name , o:owner , c:comment, mod:modification */
		DBCatalog (QString n,QString o,QString c,QDateTime mod); 
};

/** Media type node. Type number is 2 = HC_MEDIA */
class DBMedia : public QObject
{
	Q_OBJECT

	public:
		/** The media name. (must be unique) */
		QString name;
		/** The unique serial number of the media */
		int  number;

		/** Owner of the media. If not defined is NULL */
		QString owner; 

		/**Media type 0-unknown 1-CD 2-DVD 3-HardDisc 4-Floppy 5-NetworPlace 6-FlashDrive 7-OtherDevice */  
		int  type;
			
		QDateTime modification;
		QString   comment;
  
		/** Is the media borrowed? NULL=>No ; String=>Yes , contains: for who? */
		QString   borrowing; 

	public:
		/** Return the type of media as string */
		QString getMTypeName(void);
		/** Set the type of media by string */
		int	setMTypeName(QString n);

		DBMedia(void);
		/** n:name , nu:number o:owner , t:type , c:comment */
		DBMedia(QString n,int nu,QString o,int t,QString c); 
		/** n:name , nu:number o:owner , t:type , c:comment, mod:modification */
		DBMedia(QString n,int nu,QString o,int t,QString c,QDateTime mod); 

		~DBMedia(void);
}; 

/** Directory type node. Type number is 3 = HC_DIRECTORY */
class DBDirectory : public QObject
{
	Q_OBJECT

	public:
		QString   name;
		QDateTime modification;
		QString   comment;
  
	public:
		DBDirectory(void);
		/** n:name , mod:modification , c:comment */
		DBDirectory(QString n,QDateTime mod,QString c);
		~DBDirectory(void);
};

/** File type node. Type number is 4 = HC_FILE */
class DBFile : public QObject
{
	Q_OBJECT

	public: 
		QString   name;
		QDateTime modification;
		QString  comment;

		/** Filesize in sizeType unit. */
		float size;
		/** The unit of file size. 0=byte 1=Kb 2=Mb 3=Gb  */
		int   sizeType; 

		/** the root pointer of other DBNodes. Other properties of file (can be mp3tag of etc...) */
		DBNode *prop;

	public:
		/** Set the size */
		int setSize(float n,int t);
		/** Set the size by string */
		int setSize(QString sstr);

		/** Query the size */
		float getSize(void);
		/** Query the size unit code */
		int getSizeType(void);
		/** Query the size unit String*/
		QString getSizeTypeString(void);
		/** Query the whole size data string */
		QString getSizeString(void);
		/** Query the size in bytes */
		long getSizeBytes(void);

		DBFile(void);
		/** n:name , mod:modification , c:comment , s:size , st:sizeType */
		DBFile(QString n,QDateTime mod,QString c,float s,int st);
		~DBFile(void);
};
 
/** Mp3Tag type node. Type number is 5 = HC_MP3TAG */
class DBMp3Tag : public QObject
{
	Q_OBJECT

	public:
		QString artist;
		QString title;
		QString comment;
		QString album;
		QString year;
		int		track;
 
	public:
		DBMp3Tag(void);
		/** a:artist , t:title , c:commnet , al:album , y:year , r:track*/
		DBMp3Tag(QString art,QString tit,QString comm,QString alb,QString yea,int tra = 0);
		~DBMp3Tag(void);
}; 

/** Content type node. Type number is 6 = HC_CONTENT */
class DBContent : public QObject
{
	Q_OBJECT

	public:
		unsigned char *bytes;
		unsigned long  storedSize;

	public:
		DBContent(void);
		DBContent(unsigned char *pbytes,unsigned long pstoredSize);
  
		~DBContent(void);
};

/** Catalog link node. Type number is 7 = HC_CATLNK */
class DBCatLnk : public QObject 
{
	Q_OBJECT

	public:
		QString name;
		char *location;
		QString comment;

	public:
		DBCatLnk(void);
		DBCatLnk(QString pname,const char *plocation,QString pcomment);
		~DBCatLnk(void);
};

/** The program Database */
class DataBase : public QObject 
{
	Q_OBJECT  
  
	private:
		DBActionHandler *myhandler,*nullhandler;
		CConfig *myconfig;

		//These are cache variables! Do not set any of them!
		//Automatically set from the CConfig class before every filesystem scan
		bool		  cache_storeMp3tags;
		bool		  cache_v1_over_v2;
		bool		  cache_storeMp3techinfo;
		bool		  cache_storeAvitechinfo;
		bool		  cache_storeContent;
		QString		  cache_storedFiles;
		unsigned long cache_storeLimit;

	public:
		DataBase(CConfig *configobj);
		~DataBase(void);

		void setActionHandler(DBActionHandler *h) 
			{ if(h != NULL) myhandler = h; }

		void resetActionHandler(void) 
			{ myhandler = nullhandler; }

	public:			
		static QString date_to_str(QDateTime dt);

		void checkversion(void);

		void  setDBName (QString n);
		void  setDBOwner(QString o);
		void  setComment(QString c);
  
		QString& getDBName (void);
		QString& getDBOwner(void);
		QString& getComment(void);

		DBNode *getRootNode(void) 
			{ return root; }

		/** Freeing the database. STRONGLY RECOMMEND TO USE THIS INSTEAD OF "delete root;" !! */
		void clear(void);

		/** save the full database to the file, if the file specified before:
			The file opened or saved before this function. */
		int saveDB (void);

		/** Save the full database to the specified file. */
		int saveAsDB (char *filename);

		/** Open the catalog from a file */   
		int openDB (char *filename);
			
		/** insert a new catalog from filename into the existing catalog. */
		int insertDB (char *filename);

		/** Scan a new media from the disk specified in "what" with name "name" and "number" ...
			and immediately added to the database! */
		int addMedia (QString what,QString name,int number,int type);
		int addMedia (QString what,QString name,int number,int type,QString owner);

		/** Add a catalog link to the database */
		void addLnk(const char *loc);
    
		void deleteNode (DBNode *d);

		/** sort the media in the catalog */
		void sortM (int mode);

   
		double  getSize (DBNode *s,int level=0);
		unsigned long getCountFiles (DBNode *s,int level=0);
		unsigned long getCountDirs  (DBNode *s,int level=0);

		/** Search in the database. 
			! THE CALLER HAVE TO DELETE THE RETURNED DATA !
			 pattern => the pattern of the search
			 start => "" -> ROOT ; Media name -> A selected media 
			 owner => "" -> ALL OWNER ; Name -> Search in a property of the specified owner 
			 wildcart => Search with wildcard instead of regex
			 casesens => Case sensitive or not.
			 search_in => Combination of "X" - Search for everything
						                 "m" - media name
										 "d" - directory name
										 "f" - file name
										 "c" - comment 
										 "o" - content
										 "a" - tag artist
										 "t" - tag title
										 "b" - tag album 
										 "n" - tag comment
									eg: "fat" - Serach in file name artist and title */
		QList<QPointer<DBNode> > *find(QString pattern,QString start = "",QString owner = "",
							bool wildcard = false,bool casesens = false,QString search_in = "X");

		/**
			Export the database to HTML format.
				file => The target file
				monly => Media only
				medialist =>  EMPTY - Export all media
								otherwise comma (;) separated list of exported media names
				show => Combination of "F" - List files too  
									   "C" - Comments
									   "T" - MP3 tags
									   "D" - Modification dates
									   "S" - Show size
									   "1" - (CSV only) Separated field for catalog name
									   "2" - (CSV only) Separated field for media name and catalog name 
									eg: "cd" - Show only the media,dir with modification date
										"fcts" - Show media,dir,file with comment and tag and size but mod. date*/
		int exportHtml(QString file,bool monly=false,QString medialist="",QString show="fctds");
		/** Export to TXT file */
		int exportTxt (QString file,bool monly=false,QString medialist="",QString show="fctds");
		/** Export tot CSV file */
		int exportCsv (QString file,bool monly=false,QString medialist="",QString show="2ctds");
  

	signals:
		void working(void);
			   
	private:
		DBNode *root;

		QStack<DBNode *> *d_stack;

		QList<QPointer<DBNode> > * found_items;

		/** Return the p'th position media node */
		DBNode *getMOnPos(int p);
		void updateCacheVars(void);

		int scanFsToNode (QString what,DBNode *to);
		int scanFileProp (QFileInfo *fi,DBFile *fc);
 
	public:

  /**
   funtions /below/ for make import from another formats:
    The get..  function try to specify a node and return that node's pointer.
    If the return value is NULL the node is not exist in that environment
    (environment: catalog/needn't to specify of course/ in case getMedia..
                   media or directory in case getDir..  
		   media but rather directory in case getFile.. )
    so you have to use the put... functions to make the node.
    
    Always test the existion a node before you try to create it !!
    
    example:
     you want to add "MY_CD/install/sources/cdcat.tar.bz2" where is MY_CD is the media name:
     
      Node *env,*curr;
      curr = getMediaNode("MY_CD");
      if(curr == NULL) curr = putMediaNode("MY_CD", ... );
      
      env = curr;

      curr = getDirectoryNode(env,"install");
      if(curr == NULL) curr = putDirectoryNode(env,"install", ... );
      
      env = curr; //we want to search/insert the "sources" directory in "install" directory.
      
      curr = getDirectoryNode(env,"sources");
      if(curr == NULL) curr = putDirectoryNode(env,"sources", ... );

      env = curr; 
      
      curr = getFileNode(env,"cdcat.tar.bz2");
      if(curr == NULL) curr = putFileNode(env,"cdcat.tar.bz2", ... );
  */
		DBNode * getMediaNode(QString name);
		DBNode * putMediaNode(QString name,int number,QString owner,int type,QString comment);
		DBNode * getMediaNode(int id);

		//step only one directory with one call!   
		//the meddir can be media or directoy depend it's will be the first directory or not.
		DBNode * getDirectoryNode(DBNode *meddir,QString name);
		DBNode * putDirectoryNode(DBNode *meddir,QString name,QDateTime modification,QString comment);
   
		DBNode * getFileNode(DBNode *directory,QString name);
		DBNode * putFileNode(DBNode *directory,QString name,QDateTime modification,QString comment,int sizeType,float size);
   
		DBNode * putTagInfo (DBNode *file,QString artist,QString title,QString comment,QString album,QString year,int track);
     
};

#endif
//end code.
