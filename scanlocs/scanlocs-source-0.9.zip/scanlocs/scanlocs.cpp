/* ScanLocs - Picture folder location data scanner

    Copyright (C) Peter Deak  http://hyperprog.com
        2012

    GPL v2
*/

#include <iostream>
#include <QtCore>

#define VERSION	0.9

using namespace std;

class LocationItem
{
    public:

    QString loc;
    QString name;
    QString gps_lat,gps_long;
    QDate date;
    QString startfile;
};

class Nod
{
    public:
    LocationItem *data;

    Nod *next,*same;
    Nod(void) { next = NULL; same = NULL; }
};

Nod* locs;

double DDIFF = 2.0;
bool   quiet = false;

double distanceFromLongLatDifference(double lat1,double long1,double lat2,double long2)
{
    double  rlat1=lat1*(M_PI/180),
            rlat2=lat2*(M_PI/180),
            rlong1=long1*(M_PI/180),
            rlong2=long2*(M_PI/180);

    if(lat1 == lat2 && long1 == long2)
        return 0.0;

    return 6371.009*sqrt( (rlat1-rlat2)*(rlat1-rlat2) + cos(rlat1)*(rlong1-rlong2)*cos(rlat1)*(rlong1-rlong2) );
}

void addToList(LocationItem* newitem)
{
    Nod *n = new Nod();
    n->data = newitem;

    if(locs == NULL)
        locs = n;
    else
    {
        Nod *tmp = locs;
        while(tmp->next != NULL)
            tmp = tmp->next;
        tmp->next = n;
    }
}

int read_infofile(QString fname,QString path,QString firstfilename)
{
    QString line;

    QFile f;
    f.setFileName(fname);
    if(f.open(QIODevice::ReadOnly))
    {
        QStringList lst;
        while(!f.atEnd())
        {
            line = QString::fromLocal8Bit(f.readLine());
            lst = line.split(";");
            if(lst.count() >= 3)
            {
                LocationItem *loc = new LocationItem();
                loc->loc = path;
                loc->name = lst[0];
                loc->date = QDate::fromString(lst[1],"yyyy.MM.dd");
                if(!loc->date.isValid())
                    loc->date = QDate::fromString(lst[1],"yyyy-MM-dd");

                loc->gps_lat   = (QString(lst[2]).split(","))[0];
                loc->gps_long  = (QString(lst[2]).split(","))[1];
                loc->startfile = firstfilename;
                if(lst.count() > 3 && !lst[3].trimmed().isEmpty())
                    loc->startfile = lst[3].trimmed();

                addToList(loc);
            }
        }
        f.close();
    }
    return 0;
}


int scandir(QString path)
{
    QDir dir;

    dir.setPath(path);

    QString firstfilename;
    QFileInfoList subdirs;
    QFileInfoList infofiles;
    QFileInfoList imgfiles;

    //Get first image file of the directory
    imgfiles = dir.entryInfoList(QString("*.jpg;*.JPG;*.Jpg;*.jpeg;*.JPEG;*.Jpeg;*.png;*.PNG;*.Png").split(";"),QDir::Files,QDir::Name);
    QFileInfoList::Iterator imgfiles_iterator = imgfiles.begin();
    firstfilename = "";
    if(imgfiles_iterator != imgfiles.end())
        firstfilename = imgfiles_iterator->fileName();

    //Get config files of this directory
    infofiles = dir.entryInfoList(QString("location.info").split(";"),QDir::Files);
    QFileInfoList::Iterator infofiles_iterator = infofiles.begin();
    while(infofiles_iterator != infofiles.end())
    {
        if(!quiet)
            cout << "\t\tREAD:" << infofiles_iterator->fileName().toLocal8Bit().constData() << endl;
        read_infofile(infofiles_iterator->absolutePath() + "/" + infofiles_iterator->fileName(),
                      infofiles_iterator->absolutePath(),
                      firstfilename);
        ++infofiles_iterator;
    }

    //Scans the subdirectories
    subdirs = dir.entryInfoList(QStringList(),QDir::Dirs);
    QFileInfoList::Iterator subdirs_iterator = subdirs.begin();
    while(subdirs_iterator != subdirs.end())
    {
        if(subdirs_iterator->fileName() != "." && subdirs_iterator->fileName() != "..")
        {
            QString d;
            d = subdirs_iterator->absolutePath()+"/"+subdirs_iterator->fileName();
            if(!quiet)
                cout << "\t" << d.toLocal8Bit().constData() << endl;
            scandir(d);
        }

        ++subdirs_iterator;
    }

    return 0;
}

void printOut()
{
    Nod *run = locs;
    while(run != NULL)
    {
        Nod *r=run;
        while(r!=NULL)
        {
            cout << r->data->name.toLocal8Bit().constData()
                 << "("
                 << r->data->date.toString("yyyy-MM-dd").toLocal8Bit().constData()
                 << ") -> ";
            r=r->same;
        }
        cout << endl;
        run = run->next;
    }
}

void eliminateSameloc(void)
{
    Nod *mrun=locs;
    Nod *srun=NULL;
    Nod *pre_srun=NULL;

    while(mrun != NULL)
    {
        next_run:
        pre_srun = mrun;
        srun     = mrun->next;
        while(srun != NULL)
        {
            if(DDIFF > distanceFromLongLatDifference(mrun->data->gps_lat.toDouble(),mrun->data->gps_long.toDouble(),
                                                     srun->data->gps_lat.toDouble(),srun->data->gps_long.toDouble()))
            {
                Nod *nn = mrun;
                while(nn->same != NULL)
                    nn=nn->same;
                nn->same = new Nod();
                nn->same->data = srun->data;

                Nod *todel=pre_srun->next;
                pre_srun->next = srun->next;
                delete todel;
                goto next_run;
            }
            pre_srun = srun;
            srun     = srun->next;
        }

        mrun = mrun->next;
    }
}

void sortByDate(void)
{
    Nod *run = locs;
    while(run != NULL)
    {
        bool ch = true;

        while(ch)
        {
            Nod *r=run;
            ch = false;
            while(r!=NULL)
            {
                if(r->same != NULL && r->data->date > r->same->data->date)
                {
                    //swap data pointers
                    LocationItem *tmp;
                    tmp = r->data;
                    r->data = r->same->data;
                    r->same->data = tmp;

                    ch = true;
                }
                r=r->same;
            }
        }
        run = run->next;
    }
}

QString generate_js(void)
{
    QString out;
    QString html;

    out = "var mymarkers = [\n";
    Nod *run = locs;
    Nod *subrun;
    while(run != NULL)
    {
        html = "";
        subrun = run;
        while(subrun != NULL)
        {
            html += QString("<div class=\"maplabel\">"
                                "<table class=\"ltable\">"
                                    "<tr><td><a href=\"file://%1/\"><h2>%2</h2>%3</a></td><td>")
                        .arg(subrun->data->loc)
                        .arg(subrun->data->name)
                        .arg(subrun->data->date.toString("yyyy MMMM dd"));

            if(! subrun->data->startfile.isEmpty() )
            {
                html += QString("<a href=\"file://%1/\"><img style=\"width:120px; height:100px;\" src=\"file://%2\"/></a>")
                                   .arg(subrun->data->loc)
                                   .arg(subrun->data->loc + "/" + subrun->data->startfile);
            }

            html += QString("</td></tr></table></div>");

            subrun = subrun->same;
        }

        out += QString("[\'%1\',%2,%3,2,\'%4\'],\n")
                .arg(run->data->name)
                .arg(run->data->gps_lat)
                .arg(run->data->gps_long)
                .arg(html);

        run = run->next;
    }

    out += "];\n";
    return out;
}

void help(void)
{
    cout << "ScanLocs - Directory structure GPS location scanner\n\n"
         << "Usage: scanlocs <DIRECTORY_TO_SCAN> [-d=N] [-q] [-v] [-h]\n"
         << "Parameters:\n"
         << "\t-d=N\tSet the minimum distance between two point in kilometer\n\t\t(Below this distance they are melded to one)\n"
         << "\t-q\tDo not print the scanned directories\n"
         << "\t-v\tPrint the program version and exit\n"
         << "\t-h\tPrint this help and exit\n\n"
         << "The program will generate a \"locs.js\" file." << endl;
}

int main(int argi,char **argc)
{
    int i;
    QString scandirpath="";

    if(argi <= 1)
    {
        cout << "Error: Too few parameters!"<< endl;
        help();
        return 0;
    }

    for(i=1;i < argi;++i)
    {
        if(!strncmp(argc[i],"-d",2))
        {
            float d;
            if(sscanf(argc[i],"-d=%f",&d) == 1)
                DDIFF = d;
        }

        if(!strcmp(argc[i],"-q"))
            quiet = true;

        if(!strcmp(argc[i],"-v"))
        {
            cout << "ScanLocs Version: " << VERSION << "\n"
                 << "Author: Peter Deak (http://hyperprog.com)" << endl;
            return 0;
        }

        if(!strcmp(argc[i],"-h"))
        {
            help();
            return 0;
        }

        if(strncmp(argc[i],"-",1) && strlen(argc[i]) > 1 && scandirpath.isEmpty())
            scandirpath = QString(argc[i]);
    }

    if(scandirpath.isEmpty())
    {
        cout << "Error: Empty path passed! See help!\n" << endl;
        return 0;
    }

    QDir testdir(scandirpath);

    if(!testdir.exists())
    {
        cout << "Error: Not valid path passed!\n" << endl;
        return 0;
     }

    locs = NULL;

    if(!quiet)
        cout << "START SCANNING:" << scandirpath.toLocal8Bit().constData() << endl;
    scandir(scandirpath);
    if(!quiet)
        cout << "DONE." << endl;

    eliminateSameloc();
    sortByDate();

    /*
    cout << "----------------" << endl;
    printOut();
    */

    QFile of;
    of.setFileName("locs.js");
    if(of.open(QIODevice::WriteOnly))
    {
        of.write(generate_js().toUtf8());
        of.close();
    }
    return 0;
}

//End code.
