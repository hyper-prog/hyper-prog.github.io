
You can get the source from http://renamer.sourceforge.net 

Internationalization:

Under windows, the program try to load rnx_lang.qm file and 
use the compilation of this file.
So If you want to use your own language compilation make the .qm file
(with QTLinguist) then rename the file to rnx_lang.qm 
This file must be placed in the actual directory.

----------------------------------------------------------------------------
Magyarit�s:

Ha azt akaod, hogy a progi magyarul szoljon hozz�d 
nevezd �t a "rnx_hu.qm" f�jlt "rnx_lang.qm" re!
Ha a progi munkakonyvt�ra az a k�nyvt�r ahol ez a fordit�sf�jl 
elhelyezkedik akkor be tud t�lt�dni �s minden remenyem szerint a progi magyaul
fog m�k�dni.

