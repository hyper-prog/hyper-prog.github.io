/* 
    gSAFE First tutorial 
	(general Sql dAtabase FrontEnd)

   (C) 2010 Peter Deak  (hyper80@gmail.com)
   
	License: GPL

*/
#ifndef GSAFETUTORIAL_GSAFE
#define GSAFETUTORIAL_GSAFE

#include <QtCore>
#include <QtGui>
#include "datalib.h"
#include "dialib.h"


class MainDialog : public QDialog , public HDialogData
{
	Q_OBJECT 

	public:

	MainDialog(QWidget *parent,bool createemptydb);
	~MainDialog();
	
	HTable *ptable;
	HList *plist;
	
	public slots:
		int showError(QString err);
		int insertRecord(void);
		int editRecord(QString id);


};

//code

#endif