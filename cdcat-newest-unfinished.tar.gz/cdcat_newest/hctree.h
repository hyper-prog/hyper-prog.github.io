/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Tree model/view/widget of catalog structure (hctree.h)
****************************************************************************/

#ifndef CDCAT_HCTREE_H_
#define CDCAT_HCTREE_H_

#include "base.h"

#include <QObject>

#ifdef APP_GUI_MODE

#include <QtCore>
#include <QtGui>

class DBNode;
class QMouseEvent;
class DBNodeTreeModel : public QAbstractItemModel
{
	Q_OBJECT

	private:
		bool show_files;
		DBNode * root;
		QTreeView *treeview;

	public:
		DBNodeTreeModel(DBNode *start,QTreeView *parent = 0,bool files_are_visible=false);
		~DBNodeTreeModel(void);

		int setRoot(DBNode *newroot);

	public:
		QModelIndex index(int row,int column,const QModelIndex& parent=QModelIndex()) const;
		QModelIndex parent(const QModelIndex& index) const;
		int		rowCount(const QModelIndex& parent=QModelIndex()) const;
		int		columnCount(const QModelIndex& parent=QModelIndex()) const;
		bool		hasChildren(const QModelIndex& parent=QModelIndex()) const;
		QVariant	data(const QModelIndex& index,int role=Qt::DisplayRole) const;
		Qt::ItemFlags flags(const QModelIndex& index) const;

		QVariant	headerData(int section,Qt::Orientation orientation,int role=Qt::DisplayRole) const;
};

class MyTreeView : public QTreeView
{
	Q_OBJECT

	public:
		MyTreeView(QWidget *parent);

	protected:
		void mousePressEvent(QMouseEvent *event);

	public slots:
		int popupMenu(const QPoint& pos,DBNode *ptr);
		int resizecol(const QModelIndex &);
		int jumpTo(DBNode *n);
		
	signals:
		void callPopupMenu(const QPoint& pos,DBNode *ptr);

};

class HCatTreeDWidget : public QDockWidget
{
	Q_OBJECT

	private:
		bool eAction;
		MyTreeView *view;
		DBNodeTreeModel *model;

		void disableReceiveAction() { eAction = true; }
		void enableReceiveAction()  { eAction = false; }

	public:
		HCatTreeDWidget(QWidget * parent = 0);
		~HCatTreeDWidget(void);

	public slots:
		int mClick(const QModelIndex & index);
		int openNode(DBNode *n);
		int setRoot(DBNode *newroot);

	signals:
		void hitItem(DBNode *n);
};

#endif 
#endif
//end code
