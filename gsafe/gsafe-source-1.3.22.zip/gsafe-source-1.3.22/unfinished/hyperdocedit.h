/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2007 Peter Deak  (hyper80@gmail.com)

    hyperdocedit.h 

    WARNING THIS CODE IS UNFINISHED! DO NOT USE!
*/

#ifndef GSAFE__HYPERDOCEDIT_HEADER_X_ 
#define GSAFE__HYPERDOCEDIT_HEADER_X_ 


#include <QtCore>
#include <QtGui>

#include <hyperdoceditbase.h>

#define DONT_DELETE_HYPDOC  0
#define DELETE_HYPDOC       1

#define MODE_HTML 0
#define MODE_TEXT 1

class QWidget;
class HyperDoc;
class QListBoxItem;
class QLineEdit;
class HTable;
class HFloatTables;

class HyperDocEdit : public QWidget , public Ui::HyperDocEditBase
{
    Q_OBJECT

    protected:
        int dhdoc_del_mode;
        QString editedname,currentField;
        int selectedtext;
        HyperDoc *hypdoc;

        HTable       *selectedHT;
        HFloatTables *selectedHF;

    public:
        HyperDocEdit(QWidget *parent,int pdhdoc_del_mode=DONT_DELETE_HYPDOC);
        ~HyperDocEdit(void);

    public slots:
        int setHyperDoc(HyperDoc *hd);
        int plainChanged(void);
        int autoChanged(void);

        virtual int openReq(void);
        virtual int saveReq(void);
        virtual int saveasReq(void);
        virtual int closeReq(void);

    protected slots:
    
        int refreshConnections(void);
        int refreshConnections2(void);
        int refreshConnections3(void);
        int refreshConnections4(void);

        int comboTLSlot(int i);
        int comboListTLSlot(int i);
        int comboFieldsSlot(int i);
        int comboResSlot(int i);

        int text_changed(void);
        int html_changed(void);

        int toolInsertData(void);
        int toolInsertRes(void);
        int toolInsertDataRes(int mode);
        int toolInsertTable(void);
        int toolInsertCond(void);
        int toolInsertIter(void);


        int etUndo(void);
        int etRedo(void);
        
        int etCopy(void);
        int etCut(void);
        int etPaste(void);
        
        int etStrong(void);
        int etItaly(void);
        int etUnder(void);

        int etLeft(void);
        int etCenter(void);
        int etRight(void);
        int etJust(void);

        int textStyle (int i);
        int textFamily(const QString &str);
        int textSize(const QString &str);


        int checkTextChanged(int state);
        int checkHtmlChanged(int state);
    
    protected:
        QString getSelected(void);
        void closeEvent(QCloseEvent *e);

    private:
        bool nowchaged;

    signals:

        void closeRequest(void);
        void changeCaption(const QString& cap);

};


class HyperDocEditSql : public HyperDocEdit
{
    Q_OBJECT

    public:

        HyperDocEditSql(QWidget *parent,QString tablename,
                                        QString keyfname,
                                        QString expfname,
                                        QString contentfname,
                                        int pdhdoc_del_mode=DONT_DELETE_HYPDOC);

        ~HyperDocEditSql(void);

    public slots:
         virtual int shadowOpen(QString name,int mode=0);

        virtual int openReq(void);
        virtual int saveReq(void);
        virtual int saveasReq(void);
        virtual int closeReq(void);

    protected:
        QString p_table,p_key,p_exp,p_cont;

    private:
};

#endif