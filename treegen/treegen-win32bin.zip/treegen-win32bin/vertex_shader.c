/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */

/* VERTEX SHADER CODE */
uniform vec3 wind;														
uniform float shaking;													
attribute float globalflex;												
attribute float localflex;												
attribute vec3  shakedir;												

varying vec4 diffuse,ambientGlobal,ambient;
varying vec3 normal,lightDir,halfVector;
varying float dist;

void main()
{
	vec4 ecPos;
	vec3 aux;

	vec4 translated_gl_Vertex = vec4(gl_Vertex);		

	if(globalflex != 0.0)												
	{																	
		translated_gl_Vertex[0] += wind[0]*globalflex;										
		translated_gl_Vertex[1] += wind[1]*globalflex;										
		translated_gl_Vertex[2] += wind[2]*globalflex;										
	}																	
	if(localflex != 0.0)												
	{																	
		translated_gl_Vertex[0] += shakedir[0]*localflex*shaking;							
		translated_gl_Vertex[1] += shakedir[1]*localflex*shaking;							
		translated_gl_Vertex[2] += shakedir[2]*localflex*shaking;							
	}

	gl_Position = gl_ModelViewProjectionMatrix * translated_gl_Vertex;						
	gl_TexCoord[0] = gl_TextureMatrix[0] * gl_MultiTexCoord0;			

	normal = normalize(gl_NormalMatrix * gl_Normal);
		
	/* these are the new lines of code to compute the light's direction */
	ecPos = gl_ModelViewMatrix * translated_gl_Vertex;
	aux = vec3(gl_LightSource[0].position-ecPos);
	lightDir = normalize(aux);
	dist = length(aux);
	
	halfVector = normalize(gl_LightSource[0].halfVector.xyz);
	
	/* Compute the diffuse, ambient and globalAmbient terms */
	diffuse = gl_FrontMaterial.diffuse * gl_LightSource[0].diffuse;
	
	/* The ambient terms have been separated since one of them */
	/* suffers attenuation */
	ambient = gl_FrontMaterial.ambient * gl_LightSource[0].ambient;
	ambientGlobal = gl_LightModel.ambient * gl_FrontMaterial.ambient;
}
/*END*/
