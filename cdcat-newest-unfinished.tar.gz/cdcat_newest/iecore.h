/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Engine 

  Import Export Core module (iecore.h)
****************************************************************************/

#ifndef CDCAT_IECORE_HEADER
#define CDCAT_IECORE_HEADER

#include <QtCore>

#define EXP_HTML 0
#define EXP_CSV  1
#define EXP_TXT  2

class DataBase;
class QTextStream;
class DBNode;

class DBExportEngine : public QObject
{
	Q_OBJECT

	private:
		int m;
		bool mo;
		bool cR,tR,dR,sR,fR,s1R,s2R;
		QString medial;
		DataBase *db;
		QTextStream *out;

		QStack<DBNode *> *stack;

	public:
		DBExportEngine(DataBase *database);
		~DBExportEngine(void);

	public:
		QString errormsg;

		int writeDB(QString file,int mode,bool monly,QString medialist,QString show);

	private:
		int doHtml(void);
		int doTxt (void);
		int doCsv (void);

	signals:
		void working(void);

};

class DBImportEngine : public QObject
{
	Q_OBJECT

	private:
	public:

};

#endif
//end code.
