﻿/*
  C# HyperChat
  Copyright (C) Peter Deak (hyper80@gmail.com)
  License GPL
 
  This program is only for test & education pusposely
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Threading;
using System.IO;

namespace HyperChat
{
    public partial class MainWindow : Form
    {
        Thread recvthread;
        StrQueue recvq;

        const int SERVER = 0;
        const int CLIENT = 1;

        const int DFAR_FLUSH = 0;
        const int DFAR_CLEAR = 1;

        const int WAIT = 100;
     
        private int netmode;
        
        protected Bitmap backgroundImage;
        
        private NetCore netcore;

        private bool connected = false;
        public bool Connected
        { get { return connected; } }

        private Color drawcolor,recv_color;
        private int drawstyle;

        private List<Line> receivedLines;
        private List<Line> receivedRects;

        public MainWindow()
        {
            netcore = new NetCore();
            recvq = new StrQueue('*');
            receivedLines = new List<Line>();
            receivedRects = new List<Line>();

            InitializeComponent();  
        
            comboWorkMode.SelectedIndex = 0;
            backgroundImage = new Bitmap(drawPanel.Width, drawPanel.Height);
            drawcolor = Color.White;
            recv_color = Color.White;
            drawstyle = 0;
            buttonWhite.Text = "X";
            
            netmode = CLIENT;

            clearDrawWindow(false);
          
            recvthread = new Thread(new ThreadStart(ProcessingRecv));
            recvthread.Start();
 
            netcore.ConnectionEstablished += new NetCore.ConnectionEstablishedHandler(netcore_ConnectionEstablished);
            netcore.ConnectionClosed += new NetCore.ConnectionClosedHandler(netcore_ConnectionClosed);

            netcore.setMessageReceiver(MessageReceiver);

            drawStyleToStylePanel();
       }

        void netcore_ConnectionEstablished(object obj, ConnectionEstablishedEventArg arg)
        {
            connected = true;
           
            StatusChange(0);
            if (netmode == SERVER)
            {
                AppendText("*** Client connected from "+arg.Info+"\n");
            }
            if (netmode == CLIENT)
            {
                AppendText("*** Connected to " + arg.Info + "\n");
            }
        }

        void netcore_ConnectionClosed(object obj, ConnectionClosedEventArg arg)
        {
            connected = false;
            StatusChange(1);
            if (netmode == SERVER)
            {
                AppendText("*** Client disconnected \n");
            }
            if (netmode == CLIENT)
            {
                AppendText("*** Disconnected \n");
            }
        }

        void MessageReceiver(string message)
        {
            recvq.StoreToProcessing(message);
        }

        private void ProcessingRecv()
        {
            try
            {
                while (netcore != null)
                {
                    Thread.Sleep(WAIT);

                    lock ("linebuffer")
                    {
                        receivedLines.Clear();
                        receivedRects.Clear();
                    }
                    if (!recvq.Empty())
                    {
                            while (!recvq.Empty())
                                processingMessage(recvq.Next());

                            DrawFromFar(DFAR_FLUSH);
                    }
                }
            }
            catch
            { return; }
        }
       
        private void processingMessage(string msg)
        {
            string cmd;
            string nick;
            string eff_message;
            string disp_message;
            string sendfilereq;
            int sx,sy,ex,ey;


            disp_message = "";
            cmd = "";
            nick = "";
            eff_message = "";
            sx = sy = ex = ey = -1;
            sendfilereq = "";
            string[] parts = msg.Split(new char[] { ';' });
            foreach (string part in parts)
            {
                if (part == "" || part == "\n" || part == "\n\r")
                {
                    continue;
                }
                string[] subparts = part.Split(new char[] { '=' });
                if (subparts.Length != 2)
                {
                    continue;
                }

                try
                {
                    switch (subparts[0])
                    {
                        case "NICK": nick = subparts[1];           break;
                        case "DATA": eff_message = subparts[1];    break;
                        case "DSX": sx = Int32.Parse(subparts[1]); cmd = "line";  break;
                        case "DSY": sy = Int32.Parse(subparts[1]); cmd = "line";  break;
                        case "DEX": ex = Int32.Parse(subparts[1]); cmd = "line";  break;
                        case "DEY": ey = Int32.Parse(subparts[1]); cmd = "line";  break;
                        case "FSX": sx = Int32.Parse(subparts[1]); cmd = "fill";  break;
                        case "FSY": sy = Int32.Parse(subparts[1]); cmd = "fill";  break;
                        case "FEX": ex = Int32.Parse(subparts[1]); cmd = "fill";  break;
                        case "FEY": ey = Int32.Parse(subparts[1]); cmd = "fill";  break;
                        case "DC":
                            switch (subparts[1])
                            {
                                case "white":   recv_color = Color.White;       break;
                                case "red":     recv_color = Color.Red;         break;
                                case "blue":    recv_color = Color.LightSkyBlue; break;
                                case "green":   recv_color = Color.Lime;        break;
                                case "yellow":  recv_color = Color.Yellow;      break;
                                case "orange":  recv_color = Color.Orange;      break;
                                case "magenta": recv_color = Color.Magenta;     break;
                                case "black":   recv_color = Color.Black;       break;
                            }
                            break;
                        case "COMMAND":
                            cmd = subparts[1];
                            break;
                        case "SENDFILEREQ":
                            sendfilereq = subparts[1];
                            break;
                    }
                }
                catch 
                {
                }
            }

            if (eff_message != "")
            {
                
                //disp_message = nick + "> " + eff_message;
                disp_message = "[ " + DateTime.Now.Hour.ToString() + ":" +
                                   DateTime.Now.Minute.ToString() + ":" +
                                   DateTime.Now.Second.ToString() + " - "+nick+" ]" + "\n " + eff_message;
                AppendText(disp_message);
            }

            if (sx != -1 && sy != -1 && ex != -1 && ey != -1)
            {
                lock ("linebuffer")
                {
                    if(cmd == "line")
                        receivedLines.Add(new Line(recv_color, sx, sy, ex, ey));
                    else
                        receivedRects.Add(new Line(recv_color, sx, sy, ex, ey));
                }
            }

            if (cmd == "CLEAR")
            {
                DrawFromFar(DFAR_CLEAR);
            }

            if (sendfilereq != "")
            {
                AppendText("*** Send file request:"+sendfilereq+"\n");

            }
        }

        private void sendTheMsg()
        {
            string str,snick;
            if (!connected)
            {   
                msgBody.AppendText("*** No server connection!\n");
                return;
            }

            str = sendMsg.Text;
            sendMsg.Text = "";
            str += "\n";

            if (textNick.Text == "")
                snick = "NO-NICK";
            else
                snick = textNick.Text;

            msgBody.AppendText("[ " + DateTime.Now.Hour.ToString() + ":" +
                                      DateTime.Now.Minute.ToString() + ":" +
                                      DateTime.Now.Second.ToString() + " - " + snick + " ]" + "\n " + str);
            netcore.Send("NICK=" + snick + ";DATA=" + str + ";*\n");
            msgBody.ScrollToCaret();
        }

        private string getColorString()
        {
            if (drawcolor == Color.White)
                return "DC=white;";
            if (drawcolor == Color.Red)
                return "DC=red;";
            if (drawcolor == Color.LightSkyBlue)
                return "DC=blue;";
            if (drawcolor == Color.Lime)
                return "DC=green;";
            if (drawcolor == Color.Yellow)
                return "DC=yellow;";
            if (drawcolor == Color.Orange)
                return "DC=orange;";
            if (drawcolor == Color.Magenta)
                return "DC=magenta;";
            if (drawcolor == Color.Black)
                return "DC=black;";
            throw new Exception("Unknown color");
        }

        public void sendLineDrawing(int sx, int sy, int ex, int ey)
        {
            string sdata = "";

            sdata += getColorString();

            sdata += "DSX=" + sx.ToString() + ";";
            sdata += "DSY=" + sy.ToString() + ";";
            sdata += "DEX=" + ex.ToString() + ";";
            sdata += "DEY=" + ey.ToString() + ";";

            sdata += "*\n";
            netcore.Send(sdata);
        }

        public void sendFillRectDrawing(int sx, int sy, int ex, int ey)
        {
            string sdata = "";

            sdata += getColorString();

            sdata += "FSX=" + sx.ToString() + ";";
            sdata += "FSY=" + sy.ToString() + ";";
            sdata += "FEX=" + ex.ToString() + ";";
            sdata += "FEY=" + ey.ToString() + ";";

            sdata += "*\n";
            netcore.Send(sdata);
            //sdata += "\n\r";
            //sendq.StoreToProcessing(sdata);
        }


        public void sendClearWindow()
        {
            netcore.Send("COMMAND=CLEAR;*\n");
            //sendq.StoreToProcessing("COMMAND=CLEAR;");
        }

        delegate void AppendTextCallback(string str);
        private void AppendText(string str)
        {
            if (msgBody.InvokeRequired)
            {
                AppendTextCallback cb = new AppendTextCallback(AppendText);
                msgBody.Invoke(cb, new object[] { str });
            }
            else
            {
                msgBody.AppendText(str);
                msgBody.ScrollToCaret();
            }
        }

        delegate void DrawFromFarCallback(int func);
        private void DrawFromFar(int func)
        {
            if(drawPanel.InvokeRequired)
            {
                DrawFromFarCallback cb = new DrawFromFarCallback(DrawFromFar);
                drawPanel.Invoke(cb, new object[] { func  });
            }
            else
            {
                if (func == DFAR_FLUSH)
                {
                    lock ("linebuffer")
                    {
                        foreach (Line l in receivedLines)
                            drawLineToPanel_PROCESSING(l.COLOR,l.SX,l.SY,l.EX,l.EY);
                        foreach (Line l in receivedRects)
                            this.beginFillToPanel_PROCESSING(l.COLOR, l.SX, l.SY, l.EX, l.EY);
                        draw_FLUSH();
                    }
                }
                if (func == DFAR_CLEAR)
                    clearDrawWindow(false);
            }
        }

        delegate void StatusChangeCallback(int status);
        private void StatusChange(int status)
        {
            if (buttonNetAction.InvokeRequired)
            {
                StatusChangeCallback cb = new StatusChangeCallback(DrawFromFar);
                buttonNetAction.Invoke(cb, new object[] { status });
            }
            else
            {
                if (netmode == SERVER && status == 0)
                {
                    ;//nothing
                }
                if (netmode == SERVER && status == 1)
                {
                    ;//nothing
                }
                if (netmode == CLIENT && status == 0)
                {
                    buttonNetAction.Text = "Disconnect";
                    buttonNetAction.Enabled = true;
                }
                if (netmode == CLIENT && status == 1)
                {
                    buttonNetAction.Enabled = false;
                }
            }
        }


        private string getServername()
        {
            GetLineForm gsnf = new GetLineForm(this, "Server", "Give the server address or name", "");
            return gsnf.Server;
        }

        //===================================================================//

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboWorkMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboWorkMode.Text == "Client mode")
            {
                buttonNetAction.Text = "Connect";
                netmode = CLIENT;
            }

            if (comboWorkMode.Text == "Server mode")
            {
                buttonNetAction.Text = "Listen";
                netmode = SERVER;
            }
        }

        public void drawLineToPanel(int sx, int sy, int ex, int ey,bool Send)
        {
            lock ("painting")
            {
                Graphics graph = Graphics.FromImage(backgroundImage);
                graph.DrawLine(new Pen(drawcolor), sx, sy, ex, ey);

                Graphics targetgr = drawPanel.CreateGraphics();
                targetgr.DrawImage(backgroundImage, 0, 0);
                lastX = ex;
                lastY = ey;
            
                if (Send && Connected)
                {
                    sendLineDrawing(sx, sy, ex, ey);
                }
            }
        }

        public void drawLineToPanel_PROCESSING(Color color,int sx, int sy, int ex, int ey)
        {
            lock ("painting")
            {
                Graphics graph = Graphics.FromImage(backgroundImage);
                graph.DrawLine(new Pen(color), sx, sy, ex, ey);
            }
        }

        private void beginFillToPanel_PROCESSING(Color color,int sx, int sy,int ex,int ey)
        {
            lock ("painting")
            {
                Graphics graph = Graphics.FromImage(backgroundImage);
                SolidBrush brush = new SolidBrush(color);
                graph.FillRectangle(brush, new Rectangle(sx,sy,ex-sx, ey-sy));
            }
        }
     
        public void draw_FLUSH()
        {
            lock ("painting")
            {
                Graphics targetgr = drawPanel.CreateGraphics();
                targetgr.DrawImage(backgroundImage, 0, 0);
            }
        }


        private void limiter90(ref int x,ref int y,int lineStartX,int lineStartY)
        {
            if (Math.Abs(lineStartX - x) < Math.Abs(lineStartY - y))
                x = lineStartX;
            else
                y = lineStartY;
        }

        private void limiter45(ref int x,ref int y,int lineStartX,int lineStartY)
        {
            int avgdiff;
            avgdiff = (Math.Abs(lineStartX - x) + Math.Abs(lineStartY - y)) / 2;
            if (x < lineStartX) x = lineStartX - avgdiff;
            else x = lineStartX + avgdiff;
            if (y < lineStartY) y = lineStartY - avgdiff;
            else y = lineStartY + avgdiff;
        }


        private int lineStartX, lineStartY;
        public void beginExclusiveLineToPanel(int x, int y)
        {
            lineStartX = x;
            lineStartY = y;
        }
        public void drawExclusiveLineToPanel(int x, int y, int style)
        {
            if (style == 1)
                limiter90(ref x,ref y, lineStartX, lineStartY);
            if (style == 2)
                limiter45(ref x, ref y, lineStartX, lineStartY);

            lock ("painting")
            {
                Graphics targetgr = drawPanel.CreateGraphics();
                targetgr.DrawImage(backgroundImage, 0, 0);
                targetgr.DrawLine(new Pen(drawcolor), lineStartX, lineStartY, x, y);
            }
        }
        public void endExclusiveLineToPanel(int x, int y, int style)
        {
            if (style == 1)
                limiter90(ref x,ref y, lineStartX, lineStartY);
            if (style == 2)
                limiter45(ref x,ref y, lineStartX, lineStartY);

            drawLineToPanel(lineStartX, lineStartY, x, y, true);
        }

        private void beginFillToPanel(int x, int y,bool Send)
        {
            lock ("painting")
            {
                Graphics graph = Graphics.FromImage(backgroundImage);
                SolidBrush brush = new SolidBrush(drawcolor);
                graph.FillRectangle(brush, new Rectangle(x - 3, y - 3, 6, 6));

                Graphics targetgr = drawPanel.CreateGraphics();
                targetgr.DrawImage(backgroundImage, 0, 0);
            }
            if (Send && Connected)
                sendFillRectDrawing(x-3,y-3,x+3,y+3);
        }
     
        public void clearDrawWindow(bool Send)
        {
            Graphics graph = Graphics.FromImage(backgroundImage);

            graph.FillRectangle(Brushes.Black, 0, 0, backgroundImage.Width, backgroundImage.Height);

            Graphics targetgr = drawPanel.CreateGraphics();
            targetgr.DrawImage(backgroundImage, 0, 0);

            if (Send && Connected)
                sendClearWindow();
        }

        private int lastX,lastY;
        private void drawPanel_MouseDown(object sender, MouseEventArgs e)
        {
            //down
            lastX = e.X;
            lastY = e.Y;
            if (drawstyle == 1 ||
                drawstyle == 2 ||
                drawstyle == 3   )
                beginExclusiveLineToPanel(e.X,e.Y);
            if(drawstyle == 4)
                beginFillToPanel(e.X,e.Y,true);
        }
        private void drawPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if(drawstyle == 0)
                    drawLineToPanel(lastX, lastY, e.X, e.Y,true);
                else if (drawstyle == 1 ||
                         drawstyle == 2 ||
                         drawstyle == 3)
                         drawExclusiveLineToPanel(e.X, e.Y,drawstyle-1);
                if (drawstyle == 4)
                    beginFillToPanel(e.X, e.Y,true);
            }
        }
        private void drawPanel_MouseUp(object sender, MouseEventArgs e)
        {
            if (drawstyle == 1 ||
                drawstyle == 2 ||
                drawstyle == 3)
                endExclusiveLineToPanel(e.X, e.Y, drawstyle - 1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearDrawWindow(true);
        }

        private void buttonNetAction_Click(object sender, EventArgs e)
        {
            if (!connected)
            {
                comboWorkMode.Enabled = false;
                if (netmode == SERVER)
                {
                    AppendText("*** Start listening \n");
                    try
                    {
                        buttonNetAction.Enabled = false;
                        netcore.Listen();
                    }
                    catch(Exception e1)
                    {
                        MessageBox.Show(e1.ToString(), "Error");
                    }
                }

                if (netmode == CLIENT)
                {
                    AppendText("*** Start connecting \n");
                    try
                    {
                        buttonNetAction.Enabled = false;
                        netcore.Connect(getServername());
                    }
                    catch(Exception e2)
                    {
                        MessageBox.Show(e2.ToString(), "Error");
                    }
                }
            }
            else
            {
                netcore.Close();
                netcore = null;
            }
        }

        private void buttonWhite_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "X";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.White;
        }
        private void buttonRed_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "X";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.Red;
        }
        private void buttonBlue_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "X";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.LightSkyBlue;
        }
        private void buttonGreen_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "X";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.Lime;
        }
        private void buttonYellow_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "X";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.Yellow;
        }
        private void buttonOrange_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "X";
            buttonMagenta.Text = "";
            buttonBlack.Text = "";
            drawcolor = Color.Orange;
        }
        private void buttonMagenta_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "X";
            buttonBlack.Text = "";
            drawcolor = Color.Magenta;
        }
        private void buttonBlack_Click(object sender, EventArgs e)
        {
            buttonWhite.Text = "";
            buttonBlue.Text = "";
            buttonRed.Text = "";
            buttonGreen.Text = "";
            buttonYellow.Text = "";
            buttonOrange.Text = "";
            buttonMagenta.Text = "";
            buttonBlack.Text = "X";
            drawcolor = Color.Black;
        }
           
        private void buttonSend_Click(object sender, EventArgs e)
        {
            sendTheMsg();
        }

        private void sendMsg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r' && sendMsg.Text != "")
            {
                sendTheMsg();
            }
        }

        private void MainWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            recvthread.Abort();
            if (connected)
            {
                netcore.Close();
                netcore = null;
            }
            //Have to wait a little time until the net closes the connection correctly 
            Thread.Sleep(500);

        }

        private void buttonStyle_Click(object sender, EventArgs e)
        {
            drawstyle = (drawstyle + 1) % 5;
            drawStyleToStylePanel();
        }

        private void drawStyleToStylePanel()
        {
            int w, h;
            Graphics gr = panelStyle.CreateGraphics();
            w = panelStyle.Width;
            h = panelStyle.Height;
        
            gr.FillRectangle(Brushes.LightGray,0,0,w,h);
            if (drawstyle == 0)
            {
                gr.DrawLine(new Pen(Color.Black), 5, 5 , 8, 12);
                gr.DrawLine(new Pen(Color.Black), 8,12 , 10, 7);
                gr.DrawLine(new Pen(Color.Black), 10,7 , 16,13);
                gr.DrawLine(new Pen(Color.Black), 16,13, 21,10);
                gr.DrawLine(new Pen(Color.Black), 21,10, 25,10);
                return;
            }
            if (drawstyle == 1)
            {
                gr.DrawArc(new Pen(Color.Black), new Rectangle(5, 5, 4, 4), 0, 360);
                gr.DrawArc(new Pen(Color.Black), new Rectangle(w-9, h-9, 4, 4), 0, 360);
                gr.DrawLine(new Pen(Color.Black), 7, 7, w - 7, h -7);
                
                return;
            }
            if (drawstyle == 2)
            {
                gr.DrawLine(new Pen(Color.Black), 10, h / 2, w - 10, h / 2);
                gr.DrawLine(new Pen(Color.Black), w / 2, 5, w / 2, h - 5);
                return;
            }
            if (drawstyle == 3)
            {
                gr.DrawLine(new Pen(Color.Black),10, 5, w - 10, h -5);
                gr.DrawLine(new Pen(Color.Black),10, h - 5, w -10, 5);
                return;
            }
            if (drawstyle == 4)
            {
                gr.FillRectangle(Brushes.Black,new Rectangle(w/2-5,h/2-5,10,10));
                gr.DrawRectangle(new Pen(Color.White), new Rectangle(w / 2 - 5, h / 2 - 5, 10, 10));
            }
        }

        private void drawPanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics targetgr = drawPanel.CreateGraphics();
            targetgr.DrawImage(backgroundImage, 0, 0);
        }

        private void panelStyle_Paint(object sender, PaintEventArgs e)
        {
            drawStyleToStylePanel();
        }

        private void buttonSendFile_Click(object sender, EventArgs e)
        {
            //Stream myStream;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 0;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //if ((myStream = openFileDialog1.OpenFile()) != null)
                //{
                   
                    netcore.Send("SENDFILEREQ="+ openFileDialog1.FileName+";*");
                    AppendText("*** Send filesend request");
                    // Insert code to read the stream here.
                    //myStream.Close();
                //}
            }

        }

        private void buttonSavePics_Click(object sender, EventArgs e)
        {
            try
            {
                Image image = new Bitmap(backgroundImage);
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "PNG Bitmap (*.PNG)|*.PNG";
                sfd.FilterIndex = 0;

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    image.Save(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error during the save:"+ee.ToString());
            }
        }

        private void groupBoxNetStuff_Enter(object sender, EventArgs e)
        {

        }

        private void labelWorkMode_Click(object sender, EventArgs e)
        {

        }



    }

    class Line
    {
        private int sx;
        private int sy;
        private int ex;
        private int ey;
        private Color color;
        
        public int SX { set { sx = value; } get { return sx; } }
        public int SY { set { sy = value; } get { return sy; } }
        public int EX { set { ex = value; } get { return ex; } }
        public int EY { set { ey = value; } get { return ey; } }
        public Color COLOR { set { color = value; } get { return color; } }

        public Line()
        {
            this.sx = 0;
            this.sy = 0;
            this.ex = 0;
            this.ey = 0;
            this.color = Color.Red;
        }
        
        public Line(Color color,int sx,int sy,int ex,int ey)
        {
            this.sx = sx;
            this.sy = sy;
            this.ex = ex;
            this.ey = ey;
            this.color = color;
        }
    }

    class StrQueue
    {
        private char separator;
        private string sq;
        public StrQueue(char separator)
        {
            this.separator = separator;
            sq = "";
        }

        public void StoreToProcessing(string str)
        {
            lock (this)
            {
                sq += str;
            }
        }

        public string Next()
        {
            lock (this)
            {
                int i;
                string str;
                i = sq.IndexOf(separator);
                str = sq.Substring(0, i);
                sq = sq.Remove(0, i + 1);

                return str;
            }
        }

        public string All()
        {
            lock (this)
            {
                return sq;
            }
        }

        public bool Empty()
        {
            lock (this)
            {
                if (sq.Length == 0)
                    return true;
                else
                    return false;
            }
        }
    }

}