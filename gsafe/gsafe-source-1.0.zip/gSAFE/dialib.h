/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

	dialib.h +MOC
*/

#ifndef GSAFE__DIALIB_HEADER_FILE_X_
#define GSAFE__DIALIB_HEADER_FILE_X_

#include <datalib.h>
#include <guilib.h>

#include <QtCore>
#include <QtGui>


/** �ltal�nos fel�let�p�t� seg�dobjektum. Alkalmas gyors fel�letgener�l�sra ism�tl�d� egyszer�
 *	dial�gusboxok, widgetek vagy fel�letr�szek eset�n */
class HDialogData
{
	public:
		HDialogData(void);

		/** Meghat�rozott grafikus k�rnyezetet hoz l�tre.
		 *	Param�terek haszn�lat�t l�sd HDialog::HDialog -n�l. */
		int makeGui(QWidget *basew,QString caption=0,
					HTableBase *dobj1=NULL,HTableBase *dobj2=NULL,
					QString func="Ok|EscC|Vert",
					QString ttext =0,
					QString tbutt1=0,QString tbutt2=0,QList<QPixmap *> *toolbuttons=NULL,
					int xsize=320,int ysize=240 );

    public:
        bool EscC;
        bool t1C;
        bool t2C;
		bool inscroll;
		bool deletedata;
		bool declose;
        HDispTable *table1,*table2;
        HDispList  *list1 ,*list2;
        QPushButton *toolbutton1,*toolbutton2,*closebutton;
		QScrollArea *sv1,*sv2;
		QToolButton *pixTool[8];
};

/** �ltal�nos gyorsan fel�p�thet� param�terezhet� dial�gusbox */
class HDialog : public QDialog , public HDialogData  
{
    Q_OBJECT

    public:
        //static quick caller function (alloc a object exec, and delete it.)
        static int run(QWidget *parent=0,QString caption=0,HTableBase *dobj1=NULL,
                        HTableBase *dobj2=NULL,QString func="Ok|EscC|Vert",QString ttext =0,
                        QString tbutt1=0,QString tbutt2=0,QList<QPixmap *> *toolbuttons=NULL,int xsize=320,int ysize=240);

        HDialog(QWidget *parent=0,       //parent widget of the dialog
                QString caption=0,       //Title of the window
                HTableBase *dobj1=NULL,        //Data object 1
                HTableBase *dobj2=NULL,        //Data object 2
                QString func="Ok|EscC|Vert",   // "Ok"-Ok/CloseButton ,
											   // "OkIsAccept" - accept the dialog is Ok pressed. (Otherwise it mean close())
                                               // "EscC"-Close when hit Esc ,
                                               // "DHoriz" or "DVert" - data obj place
                                               // "THoriz" or "TVert" - toolbutt obj place
                                               // "AutoExec" - automaticall exec the dialog
                                               // "TB1cl" - Close dialog after hit toolbutton 1
                                               // "TB2cl" - Close dialog after hit toolbutton 1
                                               // "InScroll" - Place the Tables/List into scrollwindow
											   // "DestructiveClose" - Dectructive close the dialog
											   // "DeleteData" - Delete the metadata object
											   // "StrToE" - Call Stretch To End after initializin HDiapTable
											   // "ToolCenter" - Toolbuttons strentch to center

                QString ttext =0,        //Title text
                QString tbutt1=0,        //Toolbutton 1 text , "" if no exists
                QString tbutt2=0,        //Toolbutton 1 text , "" if no exists
				QList<QPixmap *> *toolbuttons=NULL, //Toolbuttons
                int xsize=320,           //Initial window size X
                int ysize=240            //Initial window size Y
               );    

		

		~HDialog(void);

    protected:
        void keyPressEvent(QKeyEvent *e);

    public:
	    QWidget *parent_dialog;
		
		QToolButton *getToolButtObj(int i) { return pixTool[i]; }

	public:
		QFrame *get1DispCont(void) { if(table1 != NULL) return table1;
									 if(list1 != NULL)  return list1;
									 return NULL;						};

 		QFrame *get2DispCont(void) { if(table2 != NULL) return table2;
									 if(list2 != NULL)  return list2;
									 return NULL;						};

    private slots:
        int  tbutton1Cl(void);  
        int  tbutton2Cl(void); 
		int  lic(void);
        
    signals:
        void tbutton1Clicked(void);
        void tbutton2Clicked(void);
		void listItemChanged(void);

};

class QWidget;
class QString;
class QLineEdit;

/** Adatbek�r� seg�doszt�ly */
class GetTextBox : public QDialog
{
	Q_OBJECT

	public:
		GetTextBox(QWidget *parent,QString cap,QString text,QList<QString> exptexts);
	
		QList<QString> results;
		QList<QLineEdit *> ledits;

	public slots:
		int clickOk(void);		

};


#endif
