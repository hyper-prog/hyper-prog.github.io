/* 
	FAKE Console

   (C) 2005 Peter Deak  (hyper80@gmail.com)

	fcon.cpp
*/

#include "base.h"

#include <QtCore/QtCore>

#ifdef APP_GUI_MODE

#include <QtGui/QtGui>

#include "fcon.h"


#else

#include <iostream>
using namespace std;

void sdebug(QString s)
{
	cerr << s.toLocal8Bit().constData() <<endl;

}

#endif
//end code
