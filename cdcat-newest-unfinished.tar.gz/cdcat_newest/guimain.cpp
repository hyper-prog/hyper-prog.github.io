/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Gui 

  Main gui module (guimain.cpp)
****************************************************************************/
#include "guimain.h"

#ifdef APP_GUI_MODE

#include <QtGui>

#include "main_run.h"
#include "config.h"
#include "hctree.h"
#include "hclist.h"
#include "hcinfo.h"
#include "icons.h" 
#include "guicore.h"
#include "fcon.h"

#define GUICOREPTR ((GuiApp::guiAppPo)->guicore)

AppMainWindow::AppMainWindow()
: QMainWindow(0)
{	

//dconsole();

	setWindowTitle(QString("///goAhead!-->")+VERSION);

	//statusbar
	statusbar = new QStatusBar(this);
	setStatusBar(statusbar);
	statusbar->showMessage("Welcome!"); 

	setWindowIcon(QIcon("images/cdcat.png"));
	//subwidgets
	GUICOREPTR->treedw = new HCatTreeDWidget(this);
	addDockWidget(Qt::LeftDockWidgetArea,GUICOREPTR->treedw);
	GUICOREPTR->listdw = new HCatListDWidget(this);
	setCentralWidget(GUICOREPTR->listdw);
	GUICOREPTR->infodw = new HCatInfoDWidget(this);
	addDockWidget(Qt::RightDockWidgetArea,GUICOREPTR->infodw);
	GUICOREPTR->connectSubwidgets(this);

	//Toolbars
	ctoolbar = new QToolBar("Catalog toolbar");
	ctoolbar->setObjectName(tr("Catalog"));
	ctoolbar->addAction(QIcon("images/new.png"/**get_t_new_icon()*/)   ,tr( "Create a new, empty catalog and close the previous." ),
			GUICOREPTR,SLOT(newDbEvent()));
	ctoolbar->addAction(QIcon("images/open.png")  ,tr( "Open a catalog from a file." ),
			GUICOREPTR,SLOT(openDbEvent()));
	ctoolbar->addAction(QIcon("images/save.png")  ,tr( "Save all modifications to the disc." ),
			this,SLOT(close()));
	ctoolbar->addAction(QIcon("images/saveas.png"),tr( "Save the catalog to a new file." ),
			this,SLOT(close()));
	ctoolbar->addAction(QIcon("images/close.png") ,tr( "Close the actual catalog." ),
			GUICOREPTR,SLOT(closeDbEvent()));

	mtoolbar = new QToolBar(tr("Actions toolbar"));
	mtoolbar->setObjectName("ModTool");
	mtoolbar->addAction(QIcon("images/addmedia.png")   ,tr( "Add a new media to the catalog." ),
			GUICOREPTR,SLOT(addMediaEvent()));
	mtoolbar->addAction(QIcon("images/rescanmedia.png"),tr( "Rescan the selected media." ),
			this,SLOT(close()));
	mtoolbar->addAction(QIcon("images/deleteitem.png"),tr( "Delete the selected media from the catalog." ),
			this,SLOT(close()));

	stoolbar = new QToolBar(tr("Seek toolbar"));
	stoolbar->setObjectName("SeekTool");
	stoolbar->addAction(QIcon("images/find.png"),tr( "Search an element in the database(catalog).You can search filenames, directory names, name parts or mp3 tags etc..." ),
			this,SLOT(close()));
	stoolbar->addAction(QIcon("images/seekonpanel.png"),tr( "Search an element in the current list." ),
			this,SLOT(close()));

	otoolbar = new QToolBar(tr("Config toolbar"));
	otoolbar->setObjectName("ConfTool");
	otoolbar->addAction(QIcon("images/config.png"),tr( "Configuration of the program." ),
			this,SLOT(close()));
	otoolbar->addAction(QIcon("images/colorconfig.png"),tr( "Set Colors..." ),
			this,SLOT(close()));

	htoolbar = new QToolBar(tr("Help toolbar"));
	htoolbar->setObjectName("HelpTool");
	htoolbar->addAction(QIcon("images/help.png"),tr( "Help" ),
			this,SLOT(close()));
	htoolbar->addAction(QIcon("images/info.png"),tr( "About" ),
			this,SLOT(close()));
	
	addToolBar(Qt::TopToolBarArea,ctoolbar);
	addToolBar(Qt::TopToolBarArea,mtoolbar);
	addToolBar(Qt::TopToolBarArea,stoolbar);
	addToolBar(Qt::TopToolBarArea,otoolbar);
	addToolBar(Qt::TopToolBarArea,htoolbar);

	//menu:
	fileMenu   = menuBar()->addMenu(tr("Catalog"));
    editMenu   = menuBar()->addMenu(tr("Edit"));
	viewMenu   = menuBar()->addMenu(tr("View"));
	inoutMenu  = menuBar()->addMenu(tr("Import/Export"));
	othersMenu = menuBar()->addMenu(tr("Others"));
	helpMenu   = menuBar()->addMenu(tr("Help"));

	viewMenu->addAction(GUICOREPTR->treedw->toggleViewAction());
	viewMenu->addAction(GUICOREPTR->listdw->toggleViewAction());
	viewMenu->addAction(GUICOREPTR->infodw->toggleViewAction());
	viewMenu->addSeparator();
	viewMenu->addAction(ctoolbar->toggleViewAction());
	viewMenu->addAction(mtoolbar->toggleViewAction());
	viewMenu->addAction(stoolbar->toggleViewAction());
	viewMenu->addAction(otoolbar->toggleViewAction());
	viewMenu->addAction(htoolbar->toggleViewAction());

	fileMenu->addAction(QIcon("images/new.png")   ,tr("New..."),
			GUICOREPTR,SLOT(newDbEvent()),QKeySequence("CTRL+N"));
	fileMenu->addAction(QIcon("images/open.png")  ,tr("Open..."),
			GUICOREPTR,SLOT(openDbEvent()),QKeySequence("CTRL+O"));
    fileMenu->addAction(QIcon("images/save.png")  ,tr("Save"),
			this,SLOT(close()),QKeySequence("CTRL+S"));
	fileMenu->addAction(QIcon("images/saveas.png"),tr("Save As..."),
			this,SLOT(close()));
	fileMenu->addSeparator();

	recentMenu = fileMenu->addMenu(QIcon("images/openlast.png"),tr("Recent files..."));
		recentMenu->addAction("test");
	/* !!! 
    historyMenu = new QPopupMenu();
    fileMenu->insertItem(*get_t_open_icon(),tr("Recent files..."),historyMenu);
    connect( historyMenu, SIGNAL(activated(int)), guis, SLOT(openHistoryElementEvent(int)));

    for(QStringList::Iterator it = cconfig->hlist.begin(); it != cconfig->hlist.end(); ++it){
        if (!QString(*it).isEmpty()){
            historyMenu->insertItem(*get_t_open_icon(),QString(*it));
        }
    }
	*/
	fileMenu->addSeparator();

    fileMenu->addAction(QIcon("images/close.png") ,tr("Close"),
			GUICOREPTR,SLOT(closeDbEvent()),QKeySequence("CTRL+W"));
    fileMenu->addSeparator();
    fileMenu->addAction(QIcon("images/quit.png"),tr("Quit"),this,SLOT(close()),QKeySequence("ESC"));

	
    editMenu->addAction(QIcon("images/addmedia.png")   ,tr("Add media..."),
			GUICOREPTR,SLOT(addMediaEvent()),QKeySequence("A"));
    editMenu->addAction(QIcon("images/addcatlink.png")       ,tr("Add a link to a CdCAt Catalog..."),
			this,SLOT(close()),QKeySequence("CTRL+L"));
    editMenu->addAction(QIcon("images/rescanmedia.png"),tr("Rescan media..."),
			this,SLOT(close()),QKeySequence("CTRL+R"));
    editMenu->addSeparator();    
    editMenu->addAction(QIcon("images/insertcatalog.png"),tr("Insert Catalog..."),
			this,SLOT(close()));
    editMenu->addSeparator();
    editMenu->addAction(QIcon("images/renameitem.png"),tr("Rename node..."),
			this,SLOT(close()),QKeySequence("CTRL+E"));
    editMenu->addAction(QIcon("images/renumberitem.png"),tr("Re-Number media node..."),
			this,SLOT(close()));
    editMenu->addAction(QIcon("images/deleteitem.png"),tr("Delete node"),
			this,SLOT(close()));
    editMenu->addSeparator();
    editMenu->addAction(tr("Sort media by number"),
			this,SLOT(close()));
    editMenu->addAction(tr("Sort media by name"),
			this,SLOT(close()));
    editMenu->addAction(tr("Sort media by type"),
			this,SLOT(close()));
    editMenu->addAction(tr("Sort media by time"),
			this,SLOT(close()));
   
    othersMenu->addAction(QIcon("images/find.png"),tr("Seek in database..."),
			this,SLOT(close()),QKeySequence("CTRL+F"));
    othersMenu->addAction(QIcon("images/seekonpanel.png"),tr("Seek in the panel"),
			this,SLOT(close()),QKeySequence("ALT+S"));    
    othersMenu->addAction(QIcon("images/borrowing.png"),tr("Borrowing info..."),
			this,SLOT(close()),QKeySequence("CTRL+B"));
    othersMenu->addAction(tr("Node size"),
			GUICOREPTR,SLOT(showNodeStatEvent()),QKeySequence("Space"));
    othersMenu->addAction(QIcon("images/config.png"),tr("Configuration..."),
			this,SLOT(close()),QKeySequence("CTRL+G"));
    othersMenu->addAction(QIcon("images/colorconfig.png"),tr("Set Colors..."),
			this,SLOT(close()));

	inoutMenu->addAction(QIcon("images/import.png"),tr("Import database (csv/gtktalog)")
			,this,SLOT(close()));
    inoutMenu->addAction(QIcon("images/export.png"),tr("Export database")
			,this,SLOT(close()));

    helpMenu->addAction(QIcon("images/help.png"),tr("Help") ,
			this,SLOT(close()),QKeySequence("F1"));
    helpMenu->addAction(QIcon("images/info.png"),tr("About"),
			this,SLOT(close()));

	//end menu

	//enabled/disabled dock widgets/toolbars
	ctoolbar->setVisible( GuiApp::guiAppPo->ccfg->getBoolConfigVal("toolbar_cat") );
	mtoolbar->setVisible( GuiApp::guiAppPo->ccfg->getBoolConfigVal("toolbar_act") );
	stoolbar->setVisible( GuiApp::guiAppPo->ccfg->getBoolConfigVal("toolbar_seek") );
	otoolbar->setVisible( GuiApp::guiAppPo->ccfg->getBoolConfigVal("toolbar_other") );
	htoolbar->setVisible( GuiApp::guiAppPo->ccfg->getBoolConfigVal("toolbar_help") );
	GUICOREPTR->treedw->setVisible(   GuiApp::guiAppPo->ccfg->getBoolConfigVal("win_dbtree") );
	GUICOREPTR->listdw->setVisible(   GuiApp::guiAppPo->ccfg->getBoolConfigVal("win_dblist") );
	GUICOREPTR->infodw->setVisible(   GuiApp::guiAppPo->ccfg->getBoolConfigVal("win_dbinfo") );

	GuiApp::guiAppPo->ccfg->setBoolConfigVal("mwindow_posx",pos().x() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("mwindow_posy",pos().y() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("mwindow_sizex",width() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("mwindow_sizey",height() );
	
/*	setGeometry(GuiApp::guiAppPo->ccfg->getIntConfigVal("mwindow_posx"),
	            GuiApp::guiAppPo->ccfg->getIntConfigVal("mwindow_posy"),
		    GuiApp::guiAppPo->ccfg->getIntConfigVal("mwindow_sizex"),
	            GuiApp::guiAppPo->ccfg->getIntConfigVal("mwindow_sizey"));
		    */
	
}

void AppMainWindow::closeEvent(QCloseEvent *ce)
{
        QMessageBox::information(this,"Elk�sz�n�s",QString("|")+QString(saveState().data()) + QString("Bye bye, You hit exit, or click on an unimplemented function! :-( "));

	//Save toolbar state
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("toolbar_cat",ctoolbar->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("toolbar_act",mtoolbar->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("toolbar_seek",stoolbar->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("toolbar_other",otoolbar->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("toolbar_help",htoolbar->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("win_dbtree",GUICOREPTR->treedw->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("win_dblist",GUICOREPTR->listdw->isVisible() );
	GuiApp::guiAppPo->ccfg->setBoolConfigVal("win_dbinfo",GUICOREPTR->infodw->isVisible() );
/*	
	GuiApp::guiAppPo->ccfg->setIntConfigVal("mwindow_posx",pos().x() );
	GuiApp::guiAppPo->ccfg->setIntConfigVal("mwindow_posy",pos().y() );
	GuiApp::guiAppPo->ccfg->setIntConfigVal("mwindow_sizex",width() );
	GuiApp::guiAppPo->ccfg->setIntConfigVal("mwindow_sizey",height() );
*/

	QMainWindow::closeEvent(ce);

	GuiApp::guiAppPo->ccfg->writeConfig();
}

int AppMainWindow::showStatusMsg(QString msg)
{
	statusbar->showMessage(msg);
	return 0;
}

int AppMainWindow::showStatusNode(DBNode *n)
{
	statusbar->showMessage(n->getFullPath());
	return 0;
}

AppMainWindow::~AppMainWindow()
{
}


#endif
//end code.
