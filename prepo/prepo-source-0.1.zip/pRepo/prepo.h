/*
   pRepo - Peter's Repository program 
	Complex tutorial of gSAFE ( http://hyperprog.com/gsafe/ )

   (C) 2011 Peter Deak  (hyper80@gmail.com)

   License: GPL

*/
#ifndef PREPO_HEADER_H
#define PREPO_HEADER_H

#include <QtCore>
#include <QtSql>
#include <QtGui>
#include <QtWebKit>

#include <datalib.h>
#include <hfactory.h>
#include <dialib.h>
#include <docgen.h>
#include <dconsole.h>

#include "ui_mainwindow.h"

//#define LANG_HU

#define PROGRAMNAME     "pRepo"
#define VERSION         "0.1"
#define AUTHOR          "Peter Deak"

#define DATABASEFILE    "prepo.sqllite"
#define LANGUAGEFILE    ":/prepo_hu.qm"

#ifdef LANG_HU
#define METADEFFILE     ":/metadata_hu.xml"
#else
#define METADEFFILE     ":/metadata.xml"
#endif

class MainDialog : public QDialog , public HDConsoleCommandHolder
{
    Q_OBJECT

public:
    MainDialog(QWidget *parent);
    ~MainDialog(void);

    HFactory            *myfactory;
    HSqlHandler         *globalsql;
    HDataChangeLogger   *objectchangelogger;

    QList<QPixmap *> *pixmaparray_new_edit_del;

public slots:
    int showError(QString err);

    int slotObjects(void);
    int slotViewObject(QString key);
    int slotModifyObject(QString key);
    int slotSetCValueObject(QString key);
    int slotOutObject(QString key);
    int slotTraceObject(QString key);
    int slotAlterOnObj(QString key);

    int slotPlaces(void);
    int slotPlacesAct(QString key);
    int slotAddPlaces(void);
    int slotEditPlaces(void);
    int slotDelPlace(void);

    int slotTypes(void);
    int slotTypesAct(QString key);
    int slotAddTypes(void);
    int slotEditTypes(void);
    int slotDelTypes(void);

    int slotAcc(void);
    int slotAccAct(QString key);
    int slotAddAcc(void);
    int slotEditAcc(void);
    int slotDelAcc(void);

    int slotInObj(void);
    int slotOutObj(void);
    int slotMoveObj(void);
    int slotSetCValueObj(void);
    int slotTraceObj(void);

    int slotMenuEdit(void);
    int slotMenuRefuse(void);
    int slotMenuTrace(void);

    int slotConsole(void);
    int toolbuttonclicked(void);

    int slotInfo(void);
    int slotStat(QString tblname);

public:
    int objectList(QString role="",QString mode="",QString filter="");
    int objectViewEdit(QString key,QString role,bool readonly=false);

    virtual QString donsole_command_interpreter(QString commandString);

private:
    HList *currList;
    HTable *objt;

    QString clicked_outkey;

    QStack<QWidget *> wstack;

private:
    Ui::MainWindowBase *ui;

protected:
    virtual void keyPressEvent(QKeyEvent *e);

signals:
    void setKeyTo(QString);

};

#endif
