/*
  Wallpaper Finer

  Webpage: http://hyperprog.com
  (C) 2012 Peter Deak  (hyper80@gmail.com)

  License: GPL v2.
*/

#include <QtGui/QApplication>
#include "wpfiner.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


#ifdef FORCE_LANG_HU
    QTranslator qtTranslator;
    qtTranslator.load(LANGUAGEFILE);
    a.installTranslator(&qtTranslator);
#else
#ifndef Q_WS_WIN
    QTranslator qtTranslator;
    qtTranslator.load("/usr/share/wallpaperfiner/wpfiner_" + QLocale::system().name());
    a.installTranslator(&qtTranslator);
#endif
#endif

    WpFinerMainWidget w;
    w.show();
    
    return a.exec();
}
