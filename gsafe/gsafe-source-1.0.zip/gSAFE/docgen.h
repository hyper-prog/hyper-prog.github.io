/* 
   gSAFE - LIB 
   general Sql dAtabase FrontEnd

   (C) 2009 Peter Deak  (hyper80@gmail.com)

	docgen.h + MOC
*/

#ifndef GSAFE__DOCGEN_HEADER_FILE_X_
#define GSAFE__DOCGEN_HEADER_FILE_X_

#include <QtCore>
#include <QtXml>

#include "res_p.h"

class HTable;
class HFloatTables;

/** Metadokumentum oszt�ly.
 *  Egy HTML alapu dokumentumot/dokumentumsablont t�rol, �s bizonyos XML vez�rl�elemek alapj�n
 *  olyan dokumentumot gener�l melyben a megadott metaadatok �rt�kei szerepelnek.
 *  A sablonban felhaszn�lhat�ak a [ ] | karakterek melyek rendre < > " karakterekk� konvert�l�dnak.
 *  (Hasz�ljuk ezeket azon okok miatt, hogy a sablonok megel�z� html szerkeszt�sekor az editorok sz�m�ra ezek irrelev�nsak legyenek)
 *   Felhasznalhato vez�rl�elemek:
 *		(Ha nincs meg a kert eroforras akkor nem jelenit meg semmit hacsak nincs notfound attributim)
 *		Ez egy [DATA BEGIN=|| END=|| NOTFOUND=||]htable_nev.kapcsoltfonev:datafield_nev[/DATA] megjelenitve
 *		Ez egy [RES BEGIN=|| END=|| NOTFOUND=||]eroforrasnev[/RES] ami egyedi szarmaztatott adatokat szamolo eroforras
 *		Ez egy [COND DATA=|htable_nev:datafield_nev| IS=|eq/ne| TO=|constans|]felteleles szoveg[/COND]
 *		Ez egy [COND RES=||]felteleles szoveg[/COND] ahol a res=] |true| akkor megjelenit
 *		Ez egy [ITER DATA=|hlistnev| NOTFOUND=||] itt belul tablanev helyett * karakterrel hasznalhatoak a fentiek [/ITER]		*/
class HyperDoc : public  QObject , QXmlDefaultHandler
{
	Q_OBJECT 

public:
	/** L�trehoz egy �res HyperDoc objektumot. 
	 *	@param A sablon neve. */
	HyperDoc(QString n);
	~HyperDoc();

	/** Kit�rli az aktu�lis sablont */
	void clear(); 
	/** Be�ll�thatjuk vele a sablon sz�veg�t */
	void set(QString docstr);
	/** Az aktu�lis sablonhoz hozz�adhatunk egy sz�vegr�szt (v�g�re konkaten�lja)*/
	void add(QString docstr);

	/** A HyperDoc -hoz felvett er�forr�sell�t� hivatkoz�sok t�rl�se */
	void clearResources();
	/** �j adatforr�sobjektum felv�tele 
	 *	@param ht Maga az adatforr�st�bla 
	 *	@param redefinedName Fel�lb�r�lt adatforr�s hivatkoz�si n�v. (Ha ures a t�bla sql neve lesz)
	 *	(DATA -tag) */
	void addDataSource(HTable *ht,QString redefinedName = "");
	/** Er�forr�sell�t� objektum hozz�ad�sa (RES -tag)*/
	void addResourceProvider(ResourceProvider *rp);
	/** Listaobjektumok hozz�ad�sa (ITER -tag) */
	void addIterDataTables(HFloatTables *ft);

	/** A nyers feldolgozatlan sablont adja vissza */
	QString getRawDoc();
	/** Feldolgozott c�ldokumentumot adja vissza (H�v�sakor t�rt�nik az illeszt�s) */ 
	QString generateDoc();

	/** Sablonn�v lek�rdez�se */
	QString getName(void) { return name; }
	/** Sablonn�v be�ll�t�sa */
	void setName(QString n) { name=n; }

private:
	bool startDocument(void);
	bool endDocument(void);
	bool startElement( const QString& ns, const QString& ln, const QString& name, 
                       const QXmlAttributes& atts);
	bool endElement( const QString& ns, const QString& ln, const QString& name);
	bool processingInstruction(const QString &target,const QString &data);
	bool skippedEntity(const QString &name);
	bool characters(const QString& ch);
	bool warning(const QXmlParseException& exception);
	bool error(const QXmlParseException& exception);
	bool fatalError(const QXmlParseException& exception);
	QString errorString(void) { return errstr; }

	HTable* getDataTable(QString data);
	HFloatTables* getFloatDataTable(QString data) { return getHFT(data); }

protected:
	void clearBuffer();

	QString getData(QString data);

	QString getRes(QString res);
	HFloatTables* getHFT(QString res);

	void out(QString o);

protected:
	QString name;
	QString body; //Alap sz�vegtest
	QString preprocessed;
	QString errstr;

	bool ignore;
	bool itermode;
	QString buffer,iterbuffer,iter_hft_name,iter_notfound;

	QString att_begin,att_end,att_notfound;
	HTable					   *insideIter;

public:
	QList<ResourceProvider *> *resourceProviders;
	QList<HTable *>           *dtsp;
	QList<QString>            *dtsn;
	QList<HFloatTables *>     *fts;

signals:
	/** Hiba eset�n ezt a signalt dobja fel. */
	void errorSignal(QString err);

};

#endif
