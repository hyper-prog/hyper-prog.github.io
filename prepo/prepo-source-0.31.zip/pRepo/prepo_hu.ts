<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="hu_HU">
<context>
    <name>DebugWidgetBase</name>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="14"/>
        <source>HDebugConsole</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="22"/>
        <source>SQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="35"/>
        <source>Texts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="67"/>
        <source>SyncWirte: &quot;syndebug.txt&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="93"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gSAFE/debugwidgetbase.ui" line="172"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;START:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialog</name>
    <message>
        <location filename="prepo.cpp" line="46"/>
        <source>Error: Missing datadef file!</source>
        <translation>Hiba: Hiányzó adatdefiníciós fájl!</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="60"/>
        <source>Error:Can&apos;t open the database file!</source>
        <translation>Hiba: Nem tudom megnyitni az adatbázisfájlt!</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="61"/>
        <source>New database</source>
        <translation>Új adatbázis</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="61"/>
        <source>Create new empty database structure?</source>
        <translation>Hozzak létre egy új üres adatbázisstruktúrát?</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="61"/>
        <location filename="prepo.cpp" line="262"/>
        <location filename="prepo.cpp" line="353"/>
        <location filename="prepo.cpp" line="444"/>
        <source>No</source>
        <translation>Nem</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="61"/>
        <location filename="prepo.cpp" line="262"/>
        <location filename="prepo.cpp" line="353"/>
        <location filename="prepo.cpp" line="444"/>
        <source>Yes</source>
        <translation>Igen</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="74"/>
        <source>Cannot establish the database connection...</source>
        <translation>Nem tudom kiépíteni az adatbáziskapcsolatot...</translation>
    </message>
    <message>
        <source>Creating a new empty database structure...</source>
        <translation type="obsolete">Új adatbázisstruktúra létrehozása...</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="88"/>
        <source>Error during structure creation (0)</source>
        <translation>Hiba az adatbázis létrehozásakor (0)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="90"/>
        <source>Error during structure creation (1)</source>
        <translation>Hiba az adatbázis létrehozásakor (1)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="92"/>
        <source>Error during structure creation (2)</source>
        <translation>Hiba az adatbázis létrehozásakor (2)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="94"/>
        <source>Error during structure creation (3)</source>
        <translation>Hiba az adatbázis létrehozásakor (3)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="96"/>
        <source>Error during structure creation (4)</source>
        <translation>Hiba az adatbázis létrehozásakor (4)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="98"/>
        <source>Error during structure creation (5)</source>
        <translation>Hiba az adatbázis létrehozásakor (5)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="102"/>
        <source>Settings</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="102"/>
        <source>Set the following attributes</source>
        <translation>A következő adatok beállítandóak</translation>
    </message>
    <message>
        <source>Database succesfull opened...</source>
        <translation type="obsolete">Az adatbázis sikeresen meg lett nyitva...</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="157"/>
        <source>%1: %2</source>
        <translation>%1: %2</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="158"/>
        <source>Error received</source>
        <translation>Hiba történt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="173"/>
        <source>About</source>
        <translation>Szerzői információk</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="175"/>
        <source>Peter&apos;s repository program</source>
        <translation>Péter raktárprogramja</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="176"/>
        <source>(gSAFE tutorial program)</source>
        <translation>(gSAFE bemutató program)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="177"/>
        <source>Version</source>
        <translation>Verzió</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="180"/>
        <source>Author: Peter Deak (hyper80@gmail.com)</source>
        <translation>Szerző: Deák Péter (hyper80@gmail.com)</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="190"/>
        <location filename="prepo.cpp" line="191"/>
        <source>Places</source>
        <translation>Helyek</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="209"/>
        <source>A new place</source>
        <translation>Új hely felvétele</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="210"/>
        <source>The new place</source>
        <translation>Az új hely</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="236"/>
        <source>Edit place</source>
        <translation>Hely szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="237"/>
        <source>Edit the place</source>
        <translation>A hely szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="262"/>
        <location filename="prepo.cpp" line="353"/>
        <location filename="prepo.cpp" line="444"/>
        <source>Are you sure?</source>
        <translation>Biztos vagy benne?</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="262"/>
        <source>Are you sure want to delete this place?</source>
        <translation>Biztosan törölni akarod ezt a helyet?</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="267"/>
        <source>You can&apos;t delete a place which contains objects! Sorry.</source>
        <translation>Ez a hely nem törölhető, mert eszközöket tartalmaz. Bocs.</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="282"/>
        <location filename="prepo.cpp" line="283"/>
        <source>Types</source>
        <translation>Tipusok</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="300"/>
        <source>A new type</source>
        <translation>Egy új tipus</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="301"/>
        <source>The new type</source>
        <translation>Az új tipus</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="327"/>
        <source>Edit type</source>
        <translation>Tipus szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="328"/>
        <source>Edit the type</source>
        <translation>A tipus szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="353"/>
        <source>Are you sure want to delete this type?</source>
        <translation>Biztosan le akarod törölni ezt a tipust?</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="358"/>
        <source>You can&apos;t delete a type which contains objects! Sorry.</source>
        <translation>Ez a tipus nem törölhető, mert eszközöket tartalmaz. Bocs.</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="373"/>
        <location filename="prepo.cpp" line="374"/>
        <source>Accountables</source>
        <translation>Felelősök</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="391"/>
        <source>A new accountable</source>
        <translation>Egy új felelős</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="392"/>
        <source>The new accountable</source>
        <translation>Az új felelős</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="418"/>
        <source>Edit accountable</source>
        <translation>Felelős szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="419"/>
        <source>Edit the accountable</source>
        <translation>A felelős adatainak szerkesztése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="444"/>
        <source>Are you sure want to delete this accountable?</source>
        <translation>Biztosan le akarod törölni ezt a felelőst?</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="449"/>
        <source>You can&apos;t delete an accountable which contains objects! Sorry.</source>
        <translation>Ez a felelős nem törölhető, mert tartoznak hozzá eszközök. Bocs.</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="467"/>
        <source>Error query next rep. prefix</source>
        <translation>Hiba, lekérd, előtag</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="468"/>
        <source>Error query next rep. num.</source>
        <translation>Hiba lekérd köv szám.</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="472"/>
        <location filename="prepo.cpp" line="637"/>
        <source>Error query next settings</source>
        <translation>Hiba lekérd köv beáll</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="480"/>
        <source>New object</source>
        <translation>Új eszköz</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="481"/>
        <source>Add a new object</source>
        <translation>Új eszköz felvétele</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="491"/>
        <source>Error set next rep num.</source>
        <translation>Hiba köv szam beall.</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="517"/>
        <location filename="prepo.cpp" line="640"/>
        <source>Add new type...</source>
        <translation>Új tipus felvétele...</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="519"/>
        <location filename="prepo.cpp" line="641"/>
        <source>Add new place...</source>
        <translation>Új hely felvétele...</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="521"/>
        <location filename="prepo.cpp" line="642"/>
        <source>Add new accountable...</source>
        <translation>Új felelős felvitele...</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="529"/>
        <source>Objects</source>
        <translation>Eszközök</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="540"/>
        <source>Select object to modify</source>
        <translation>Válaszd ki a módosítandó eszközt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="546"/>
        <source>Select object to modify current value</source>
        <translation>Válaszd ki az eszközt melynek módosítanád az értékét</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="553"/>
        <source>Select object to sold/refuse</source>
        <translation>Válaszd ki a sejeltezendő/eladandó eszközt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="559"/>
        <source>Select object to trace</source>
        <translation>Válaszd ki a követendő eszközt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="564"/>
        <source>Objects is in this place</source>
        <translation>Eszközök ezen a helyen</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="570"/>
        <source>Objects is in type</source>
        <translation>Eszközök ebben a tipusban</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="576"/>
        <source>Objects which assigned to this accountable</source>
        <translation>Eszközök, melyek ehhez a felelőshöz vannak rendelve</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="599"/>
        <source>Add new object</source>
        <translation>Új eszköz felvétele</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="600"/>
        <source>Move/Edit object</source>
        <translation>Mozgat/Szerkeszt eszközt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="601"/>
        <source>Sold/Refuse object</source>
        <translation>Selejtez/Elad eszközt</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="602"/>
        <source>Trace object</source>
        <translation>Eszköz követése</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="644"/>
        <source>Object</source>
        <translation>Eszköz</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="645"/>
        <source>Object&apos;s data</source>
        <translation>Eszköz adatai</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="684"/>
        <source>Error query changes</source>
        <translation>Hiba a változások lekérdezésekor</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="686"/>
        <source>Changed data</source>
        <translation>Változtatott adat</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="687"/>
        <source>Old value</source>
        <translation>Régi érték</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="688"/>
        <source>New value</source>
        <translation>Új érték</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="754"/>
        <source>Objects in the system</source>
        <translation>Eszközök a rendszerben</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="755"/>
        <location filename="prepo.cpp" line="757"/>
        <source>Active</source>
        <translation>Aktív</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="756"/>
        <source>Sum incoming value in the system</source>
        <translation>Összes bejövő érték a rendszerben</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="758"/>
        <source>Types in the system</source>
        <translation>Tipusok a rendszerben</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="759"/>
        <source>Places in the system</source>
        <translation>Helyek a rendszerben</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="760"/>
        <source>Accountables in the system</source>
        <translation>Felelősök a rendszerben</translation>
    </message>
    <message>
        <location filename="prepo.cpp" line="789"/>
        <source>Error, cannot provide the resource.</source>
        <translation>Hiba, a kért erőforrás nem biztosítható.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Peter&apos;s Repository</source>
        <translation>Péter raktárprogramja</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="28"/>
        <source>Actions</source>
        <translation>Műveletek</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="52"/>
        <source>Add/Record a new object</source>
        <translation>Eszköz rögzítése, felvétele</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="58"/>
        <source>+Object</source>
        <translation>+Eszköz</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="87"/>
        <source>Move / Transfer objects</source>
        <oldsource>Move / Transper objects</oldsource>
        <translation>Ezköz mozgatása / szerkesztése</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="90"/>
        <source>Move</source>
        <translation>Mozgás</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="119"/>
        <source>Set current price</source>
        <translation>Aktuális érték beállítása</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="122"/>
        <source>setPrice</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="151"/>
        <source>Remove / Close objects (eg: sold)</source>
        <translation>Eszköz eltávolitása, selejtezése (eladása)</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="157"/>
        <source>-Object</source>
        <translation>-Eszköz</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="186"/>
        <source>Trace objects</source>
        <translation>Eszköz követése</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="189"/>
        <source>Trace</source>
        <translation>Követ</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="225"/>
        <source>Lists</source>
        <translation>Listák</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="249"/>
        <source>Objects in this repository</source>
        <translation>A raktárban levő eszközök</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="252"/>
        <source>Objects</source>
        <translation>Eszközök</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="281"/>
        <source>Places in this repository</source>
        <translation>Helyek a raktárprogramban</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="284"/>
        <source>Places</source>
        <translation>Helyek</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="313"/>
        <source>Types in this repository</source>
        <translation>Tipusok a raktárban</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="319"/>
        <source>Types</source>
        <translation>Tipusok</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="348"/>
        <source>Accountables</source>
        <translation>Felelősök</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="351"/>
        <source>Acc</source>
        <translation>Felel</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="387"/>
        <source>Console (Debug, testing and demo purpouses)</source>
        <translation>Hibakereső konzol (Tesztelésre, demózásra)</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="390"/>
        <location filename="mainwindow.ui" line="422"/>
        <location filename="mainwindow.ui" line="464"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="419"/>
        <source>About, Author, Version</source>
        <translation>Infó, Szerzőröl, Verzióról</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="483"/>
        <source>Statistics</source>
        <translation>Statisztika</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="489"/>
        <source>Welcome</source>
        <translation>Hello</translation>
    </message>
</context>
</TS>
