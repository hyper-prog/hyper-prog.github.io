/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */
  
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtCore>
#include <QtGui>
#include <QtOpenGL>

#include "core.h"
#include "tree.h"
#include "db.h"

#define VERSION "1.0.2"

class Board;
class GLData;

class MenuHandler : public QObject
{
        Q_OBJECT

public:
        QString name;

        MenuHandler(QString n);
        ~MenuHandler(void);

public slots:
        int slotEdit(void);
        int slotRegenerate(void);
        int slotHideShow(void);
        int slotDeleteitem(void);

signals:
        void edit(QString);
        void regenerate(QString);
        void hideshow(QString);
        void deleteitem(QString);

private:
        static list<MenuHandler *> objects;

public:
        static MenuHandler* getWithName(QString name);
        static void replaceName(QString oldname,QString newname);
        static void deleteWithName(QString name);
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    MainWindow(QWidget *parent = 0);
    ~MainWindow();

        Board *board;
        QMenu *elementsMenu,*functionsMenu;

        int existingName(QString name);
public slots:
        int addTree(void);
        int addGrass(void);
        int addPalmTree(void);
        int addBigLeaves(void);

        int slotInfo(void);

        int addCommon(ElementParameters *p);

        int constructMenu(void);

        int slotEditEnv(void);
        int edit(QString name);
        int regenerate(QString name);
        int hideshow(QString name);
        int deleteitem(QString name);

        int showStatusMsg(QString m);

        int startdconsole(void);

        int slotAutorotate(void);
        int slotWindshader(void);
        int slotAmbientlight(void);
        int slotPointlight(void);

        int clearall(void);
        int save(void);
        int saveScreen(void);
        int open(void);
};


class Board : public QGLWidget
{
        Q_OBJECT

 public:

        Db db;
        GLData gldata;
        EnvParameters *env;

    long frame;
        long basetriangles,old_triangles;
        long triangles;
    int x;

        double wind_strongwave;
        double wind_degree;
        double wind_strong;
        double wind_up;
        double shaking_strong;

        bool lightamb,lightpoint,rotation,windshader;

        int vf1,vf2,vf3;
        int vr1,vr2,vr3;
        int var;

        Vertex myPos,lookVect;
        double lookHorizDir,lookVertDir;
        double stepFactor;
        double mouseFactor;
        int keyUp,keyDown,keyLeft,keyRight;

        int refX,refY;
        int centerX,centerY;
        int lastX,lastY;

        Board(QWidget *parent);

 public:
         int freeListNum(void);
         void loadTexture(int *loc,QString file);

 public slots:
        int regenerateAll(void);

        int timedRefresh(void);
        int redraw(void);

        void genList0(void);
        void genListX(void);


 protected:
        void initializeGL();
    void resizeGL(int w, int h);
    void paintGL();

        void keyPressEvent(QKeyEvent *e);
        void keyReleaseEvent(QKeyEvent *e);

        void mouseMoveEvent(QMouseEvent *e);
        void mousePressEvent(QMouseEvent *e);
        void mouseReleaseEvent(QMouseEvent *e);

signals:
        void putStatusMsg(QString msg);
};
#endif // MAINWINDOW_H
