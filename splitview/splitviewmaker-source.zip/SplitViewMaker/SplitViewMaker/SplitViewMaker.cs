using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace SplitViewMaker
{
    public partial class SplitViewMaker : Form
    {

        private void Split(string input, string output,int sliceX,int sliceY)
        {
            int w, h;
            int x, y;
            int slicenum;
            int cslice;
            string control="";
            Image source;
            GraphicsUnit unit = GraphicsUnit.Pixel;
            source = Image.FromFile(input);

            w = (int)source.GetBounds(ref unit).Width;
            h = (int)source.GetBounds(ref unit).Height;
            //MessageBox.Show("Size: " + w.ToString() + "," + h.ToString());
            
            Bitmap target = new Bitmap(sliceX, sliceY, PixelFormat.Format24bppRgb);
            Graphics targetGr;
            targetGr = Graphics.FromImage(target);

            slicenum = ((int)(w / sliceX) + (w % sliceX == 0 ? 0 : 1)) * ((int)(h / sliceY) + (h % sliceY==0 ? 0 : 1));
            cslice = 0;

            progressBar.Minimum = 1;
            progressBar.Maximum = slicenum;
            progressBar.Step = 1;
            progressBar.Value = 1;

            for (y = 0; y < h; y += sliceY)
                for (x = 0; x < w; x += sliceX)
                {
                    targetGr.FillRectangle(Brushes.Black, 0, 0, sliceX, sliceY);
                    targetGr.DrawImage(source,
                                        new Rectangle(0,0,sliceX,sliceY),
                                        x,y,sliceX,sliceY,GraphicsUnit.Pixel);
 
                    target.Save(output + "/"+"part" + cslice.ToString()+".jpg",ImageFormat.Jpeg);
                    control += ""+x+";"+y+";"+(x+sliceX)+";"+(y+sliceY)+"=part"+cslice.ToString()+".jpg"+"\n";

                    progressBar.PerformStep();
                    ++cslice;
                }

            TextWriter cfile = new StreamWriter(output + "/"+"output.splv");
            cfile.Write(control);
            cfile.Close();

            MessageBox.Show("Finished!");

        }

        // ===================================================================== //
        public SplitViewMaker()
        {
            InitializeComponent();
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            Split(inputText.Text, outputText.Text, (int)sliceX.Value, (int)sliceY.Value);
        }

        private void buttonInputBrowser_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "jpeg files (*.jpg)|*.jpg";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                inputText.Text = ofd.FileName;
            }
        }

        private void buttonOutputBrowser_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                outputText.Text = fbd.SelectedPath;
            }
        }
    }
}