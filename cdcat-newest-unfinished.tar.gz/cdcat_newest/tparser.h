//#define DoAviDebug
#include <qstring.h>
#include  <stdio.h>

#ifndef CDCAT_AVIPARSER_HEADER
#define CDCAT_AVIPARSER_HEADER

QString parseAviHeader(FILE* plik);

void fourccSwitch(unsigned long fcc, QString &ReturnData);
void fourccSwitch2(unsigned short fcc, QString &ReturnData);
void freeINFOLIST(void);

#endif
//end code.
