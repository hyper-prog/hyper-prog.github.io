#!/bin/sh
rm debugwidgetbase.h
rm hyperdoceditbase.h
rm qrc_gsafe.cpp
rm moc*.cpp
rm ui_*.h

