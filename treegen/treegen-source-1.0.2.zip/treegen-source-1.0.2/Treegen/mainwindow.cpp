/*
  TreeGenerator
  (OpenGL GLSL Environment generator)

  Copyright (C) Peter Deak (hyper80@gmail.com)
  http://hyperprog.com

  Platform: C++ Qt (http://qt.nokia.com)

  License GPL

  This program is only for test & education pusposely & fun ;-) */

#include <stdlib.h>
#include <time.h>

#include "glew/GL/glew.h"

#include <QtCore>
#include <QtGui>
#include <QtSql>
#include <QtOpenGL>

#include <QGLShaderProgram>

#include "mainwindow.h"
#include "core.h"
#include "tree.h"
#include "db.h"

#include "dconsole.h"

#include <datalib.h>
#include <guilib.h>
#include <dialib.h>
#include <hfactory.h>

MainWindow::MainWindow(QWidget *parent):
 QMainWindow(parent)
{
        //just initialize the static things
        ElementParameters *first = new ElementParameters();
        delete first;

        board = new Board(this);

        connect(board,SIGNAL(putStatusMsg(QString)),this,SLOT(showStatusMsg(QString)));
        board->setMinimumWidth(800);
        board->setMinimumHeight(600);

        setCentralWidget(board);

        QMenu *mm,*ma,*mh;
        mm = menuBar()->addMenu(tr("&Main"));
        mm->addAction("Open...",this,SLOT(open()));
        mm->addAction("Save...",this,SLOT(save()));
        mm->addAction("Capture screen to png...",this,SLOT(saveScreen()));
        mm->addSeparator();
        mm->addAction("Clear all",this,SLOT(clearall()));
        mm->addAction("Regenerate all",board,SLOT(regenerateAll()));
        mm->addSeparator();
        mm->addAction("Exit",this,SLOT(close()));

        ma = menuBar()->addMenu(tr("&Add New"));
        ma->addAction("Tree...",this,SLOT(addTree()));
        ma->addAction("PalmTree...",this,SLOT(addPalmTree()));
        ma->addAction("Undergrowth...",this,SLOT(addBigLeaves()));
        ma->addAction("Grass...",this,SLOT(addGrass()));

        elementsMenu = menuBar()->addMenu(tr("&Elements"));

        functionsMenu = menuBar()->addMenu(tr("&Functions"));

        mh = menuBar()->addMenu(tr("About"));
        mh->addAction("Information",this,SLOT(slotInfo()));

        constructMenu();
        showStatusMsg("Welcome");
        this->setWindowIcon(QIcon(":/treegen.ico"));
}

int MainWindow::slotInfo(void)
{
    QMessageBox::information(this,tr("About"),
    QString("<strong>TreeGen</strong> - %1<br>%2<br>http://hyperprog.com<br><br>%3: %4<br>gSAFE: %5<br><br>%6<br>License: GPLv2")
        .arg(tr("Environment generator program"))
        .arg(tr("(Tree/Palm tree/Grass/Ferns, etc)"))
        .arg(tr("Version"))
        .arg(VERSION)
        .arg(GSAFE_VERSION)
        .arg(tr("Author: Peter Deak (hyper80@gmail.com)")));
    return 0;
}

int MainWindow::constructMenu(void)
{
        QMenu *subm;
        elementsMenu->clear();

        elementsMenu->addAction("Environment...",this,SLOT(slotEditEnv()));

        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                QString statemenutext="-";
                if((*i)->state == 0 || (*i)->state == 1)
                        statemenutext = "Hide";
                if((*i)->state == 2)
                        statemenutext = "Show";

                subm = elementsMenu->addMenu( (*i)->name );
                subm->addAction("Edit parameters"	,MenuHandler::getWithName((*i)->name)	,SLOT(slotEdit())			);
                subm->addAction("Regenerate"		,MenuHandler::getWithName((*i)->name)	,SLOT(slotRegenerate())		);
                subm->addAction(statemenutext,MenuHandler::getWithName((*i)->name)	,SLOT(slotHideShow())		);
                subm->addAction("Delete"			,MenuHandler::getWithName((*i)->name)	,SLOT(slotDeleteitem())		);
        }

        functionsMenu->clear();

        QAction *a;

        a = functionsMenu->addAction("Autorotation",this,SLOT(slotAutorotate()));
        a->setCheckable(true);
        a->setChecked(board->rotation);

        a = functionsMenu->addAction("Custom shader (The wind blows)",this,SLOT(slotWindshader()));
        a->setCheckable(true);
        a->setChecked(board->windshader);

        a = functionsMenu->addAction("Point light (Or ambient if unchecked)",this,SLOT(slotPointlight()));
        a->setCheckable(true);
        a->setChecked(board->lightpoint);

        a = functionsMenu->addAction("Debug console...",this,SLOT(startdconsole()));
        return 0;
}

int MainWindow::showStatusMsg(QString m)
{
        statusBar()->showMessage(m);
        return 0;
}

int MainWindow::startdconsole(void)
{
        dconsole();
        return 0;
}

int MainWindow::saveScreen(void)
{
    QString fn;

    fn = QFileDialog::getSaveFileName(this,"Save screen to png file...",QString(),"Image (*.png)");
    if(fn.isEmpty())
            return 0;

    board->grabFrameBuffer().save(fn);
    return 0;

}

int MainWindow::save(void)
{
        int n;
        QString fn;

        fn = QFileDialog::getSaveFileName(this,"Save to file...",QString(),"Treegen (*.tgf)");
        if(fn.isEmpty())
                return 0;

        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(fn);
        if(!db.open())
        {
                        QMessageBox::information(NULL,"Error","Cannot create sqlite file!");
                        return -1;
        }
        sdebug("Database succesfull opened...");

        HTable *env_t = ElementParameters::factory->genHTable("envparameters");
                        env_t->submit0ResultQuery( env_t->sqlCreateString() , "Error creating env table" );
                        env_t->submit0ResultQuery( "DELETE FROM envparam;" , "Error deleting env data" );

        HTable *tree_t = ElementParameters::factory->genHTable("treeparameters");
                        tree_t->submit0ResultQuery( tree_t->sqlCreateString() , "Error creating treetable" );
                        tree_t->submit0ResultQuery( "DELETE FROM treeparam;" , "Error deleting treetable data" );

        HTable *grass_t = ElementParameters::factory->genHTable("grassparameters");
                        grass_t->submit0ResultQuery( grass_t->sqlCreateString() , "Error creating grasstable" );
                        grass_t->submit0ResultQuery( "DELETE FROM grassparams;" , "Error deleting grasstable data" );

        HTable *bigleaf_t = ElementParameters::factory->genHTable("bigleafparameters");
                        bigleaf_t->submit0ResultQuery( bigleaf_t->sqlCreateString() , "Error creating bigleafparam table" );
                        bigleaf_t->submit0ResultQuery( "DELETE FROM bigleafparam;" , "Error deleting bigleafparam data" );

        HTable *palm_t = ElementParameters::factory->genHTable("palmtreeparameters");
                        palm_t->submit0ResultQuery( palm_t->sqlCreateString() , "Error creating palmtreeparam table" );
                        palm_t->submit0ResultQuery( "DELETE FROM palmparams;" , "Error deleting palmtreeparam data" );

        board->env->link->setKey("0");
        board->env->link->insertRecord(true);

        n = 0;
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                (*i)->link->insertRecord();
                ++n;
        }

        db.close();
        return 0;
}

int MainWindow::open(void)
{
        QString fn;

        fn = QFileDialog::getOpenFileName(this,"Save to open...",QString(),"Treegen (*.tgf)");
        if(fn.isEmpty())
                return 0;

        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(fn);
        if(!db.open())
        {
                        QMessageBox::information(NULL,"Error","Cannot create sqlite file!");
                        return -1;
        }
        sdebug("Database succesfull opened...");

        clearall();


        HTable *tree_t = ElementParameters::factory->genHTable("treeparameters");
        HTable *grass_t = ElementParameters::factory->genHTable("grassparameters");
        HTable *bigleaf_t = ElementParameters::factory->genHTable("bigleafparameters");
        HTable *palm_t = ElementParameters::factory->genHTable("palmtreeparameters");

        HFloatTables *tree_ft = new HFloatTables(tree_t);
        HFloatTables *grass_ft = new HFloatTables(grass_t);
        HFloatTables *bigleaf_ft = new HFloatTables(bigleaf_t);
        HFloatTables *palm_ft = new HFloatTables(palm_t);

        tree_ft->readDBTable("");
        grass_ft->readDBTable("");
        bigleaf_ft->readDBTable("");
        palm_ft->readDBTable("");

        board->env->link->setKey("0");
        board->env->link->updateWithKey();

        db.close();

        board->env->sync();

        HTable *item=NULL;

        tree_ft->first();
        while((item=tree_ft->nextRecord()))
        {
                TreeParameters *tp = new TreeParameters();
                tp->link = new HTable(item);
                board->gldata.textures.fill_htablesfields(tp->link);
                tp->sync();

                board->db.innerdb.push_back(tp);

                QObject *join = new MenuHandler(tp->name);
                connect(join,SIGNAL(edit(QString)),this,SLOT(edit(QString)));
                connect(join,SIGNAL(regenerate(QString)),this,SLOT(regenerate(QString)));
                connect(join,SIGNAL(hideshow(QString)),this,SLOT(hideshow(QString)));
                connect(join,SIGNAL(deleteitem(QString)),this,SLOT(deleteitem(QString)));
        }
        delete tree_ft;

        palm_ft->first();
        while((item=palm_ft->nextRecord()))
        {
                PalmTreeParameters *tp = new PalmTreeParameters();
                tp->link = new HTable(item);
                board->gldata.textures.fill_htablesfields(tp->link);
                tp->sync();

                board->db.innerdb.push_back(tp);

                QObject *join = new MenuHandler(tp->name);
                connect(join,SIGNAL(edit(QString)),this,SLOT(edit(QString)));
                connect(join,SIGNAL(regenerate(QString)),this,SLOT(regenerate(QString)));
                connect(join,SIGNAL(hideshow(QString)),this,SLOT(hideshow(QString)));
                connect(join,SIGNAL(deleteitem(QString)),this,SLOT(deleteitem(QString)));
        }
        delete palm_ft;

        grass_ft->first();
        while((item=grass_ft->nextRecord()))
        {
                GrassParameters *tp = new GrassParameters();
                tp->link = new HTable(item);
                board->gldata.textures.fill_htablesfields(tp->link);
                tp->sync();

                board->db.innerdb.push_back(tp);

                QObject *join = new MenuHandler(tp->name);
                connect(join,SIGNAL(edit(QString)),this,SLOT(edit(QString)));
                connect(join,SIGNAL(regenerate(QString)),this,SLOT(regenerate(QString)));
                connect(join,SIGNAL(hideshow(QString)),this,SLOT(hideshow(QString)));
                connect(join,SIGNAL(deleteitem(QString)),this,SLOT(deleteitem(QString)));
        }
        delete grass_ft;

        bigleaf_ft->first();
        while((item=bigleaf_ft->nextRecord()))
        {
                BigLeafParameters *tp = new BigLeafParameters();
                tp->link = new HTable(item);
                board->gldata.textures.fill_htablesfields(tp->link);
                tp->sync();

                board->db.innerdb.push_back(tp);

                QObject *join = new MenuHandler(tp->name);
                connect(join,SIGNAL(edit(QString)),this,SLOT(edit(QString)));
                connect(join,SIGNAL(regenerate(QString)),this,SLOT(regenerate(QString)));
                connect(join,SIGNAL(hideshow(QString)),this,SLOT(hideshow(QString)));
                connect(join,SIGNAL(deleteitem(QString)),this,SLOT(deleteitem(QString)));
        }
        delete bigleaf_ft;
        board->genList0();

        constructMenu();
        return 0;
}

int MainWindow::slotAutorotate(void)
{
        if(board->rotation)
                board->rotation = false;
        else
                board->rotation = true;
        constructMenu();
        return 0;
}

int MainWindow::slotWindshader(void)
{
        if(board->windshader)
        {
                board->windshader = false;
                board->gldata.sprogram->release();
        }
        else
        {
                board->windshader = true;
                board->gldata.sprogram->bind();
        }
        constructMenu();
        return 0;
}

int MainWindow::slotAmbientlight(void)
{
        if(board->lightamb)
                board->lightamb = false;
        else
                board->lightamb = true;
        constructMenu();
        return 0;
}

int MainWindow::slotPointlight(void)
{
        if(board->lightpoint)
                board->lightpoint = false;
        else
                board->lightpoint = true;
        constructMenu();
        return 0;
}

int MainWindow::slotEditEnv(void)
{
    HDialog *editdialog = new HDialog(this,"Environment parameters", board->env->link,NULL,"Ok|EscC|Vert|InScroll|OkIsAccept|StrToE","Environment parameters","","",NULL,500,400);
        if(editdialog->exec())
        {
        board->env->sync();
        }
        board->genList0();
        return 0;
}

int MainWindow::edit(QString name)
{
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        HDialog *editdialog = new HDialog(this,"Element parameters", (*i)->link,NULL,"Ok|EscC|Vert|InScroll|OkIsAccept|StrToE","Element parameters","Apply","",NULL,580,680);
                        connect(editdialog,SIGNAL(tbutton1Clicked()),MenuHandler::getWithName(name),SLOT(slotRegenerate()));

                        if(editdialog->exec())
                        {
                                (*i)->sync();
                                MenuHandler::replaceName(name,(*i)->name);
                                (*i)->state = 0;
                        }
                }
        }
        constructMenu();
        return 0;
}

int MainWindow::regenerate(QString name)
{
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        (*i)->sync();
                        MenuHandler::replaceName(name,(*i)->name);
                        (*i)->state = 0;
                }
        }
        return 0;
}

int MainWindow::hideshow(QString name)
{
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        if((*i)->state == 1)				(*i)->state = 2;
                        else if((*i)->state == 2)			(*i)->state = 1;
                }
        }
        constructMenu();
        return 0;
}

int MainWindow::deleteitem(QString name)
{
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        ElementParameters *to_remove = *i;

                        board->db.innerdb.remove(to_remove);
                        delete (to_remove->link);			//htable
                        delete to_remove;					//parameters
                        MenuHandler::deleteWithName(name);	//menuhandler
                        constructMenu();
                        return 0;
                }
        }
        return 0;
}

int MainWindow::clearall(void)
{
        list<ElementParameters *>::iterator i;
        for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
        {
                ElementParameters *to_remove = *i;

                delete (to_remove->link);						//htable
                MenuHandler::deleteWithName(to_remove->name);	//menuhandler
                delete to_remove;								//parameters
        }

        board->db.innerdb.clear();
        constructMenu();
        return 0;
}


int MainWindow::addTree(void)
{	return addCommon(new TreeParameters());		}

int MainWindow::addGrass(void)
{	return addCommon(new GrassParameters());	}

int MainWindow::addPalmTree(void)
{	return addCommon(new PalmTreeParameters()); }

int MainWindow::addBigLeaves(void)
{	return addCommon(new BigLeafParameters()); }

int MainWindow::addCommon(ElementParameters *p)
{
        HTable *ttp = p->getAndIndependentHTableInstance();

        board->gldata.textures.fill_htablesfields(ttp);

        if(HDialog::run(this,"Parameters of the new element",ttp,NULL,"Ok|EscC|Vert|InScroll|OkIsAccept|StrToE","Parameters of the new element","","",NULL,580,680))
        {
                int uniq=1;
                sdebug(QString("Valid�l�s:%1").arg(ttp->validate()));

                QString newname = ttp->fieldBySqlName("name")->getValue().toString();
                while(existingName(newname))
                {
                    newname = QString("%1-%2").arg(ttp->fieldBySqlName("name")->getValue().toString()).arg(uniq);
                    uniq++;
                }
                ttp->fieldBySqlName("name")->setValue(newname,true);

                p->link = ttp;
                p->sync();

                board->db.innerdb.push_back(p);

                QObject *join = new MenuHandler(p->name);
                connect(join,SIGNAL(edit(QString)),this,SLOT(edit(QString)));
                connect(join,SIGNAL(regenerate(QString)),this,SLOT(regenerate(QString)));
                connect(join,SIGNAL(hideshow(QString)),this,SLOT(hideshow(QString)));
                connect(join,SIGNAL(deleteitem(QString)),this,SLOT(deleteitem(QString)));

                constructMenu();
        }
        return 0;
}

int MainWindow::existingName(QString name)
{

    list<ElementParameters *>::iterator i;
    for( i = board->db.innerdb.begin() ; i != board->db.innerdb.end() ; ++i)
            if( (*i)->link->fieldBySqlName("name")->getValue().toString() == name)
                return 1;
    return 0;
}

MainWindow::~MainWindow()
{

}
// ----------------------------------------------------------------------------------- //
list<MenuHandler *> MenuHandler::objects;
MenuHandler::MenuHandler(QString n)
{
        name = n;
        objects.push_back(this);
}

MenuHandler::~MenuHandler(void)
{
}

MenuHandler* MenuHandler::getWithName(QString name)
{
        list<MenuHandler *>::iterator i;
        for(i=objects.begin() ; i != objects.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        return *i;
                }
        }
        return NULL;
}

void MenuHandler::replaceName(QString oldname,QString newname)
{
        if(oldname == newname)
                return;
        list<MenuHandler *>::iterator i;
        for(i=objects.begin() ; i != objects.end() ; ++i)
        {
                if((*i)->name == oldname)
                {
                        (*i)->name = newname;
                }
        }
}

void MenuHandler::deleteWithName(QString name)
{
        list<MenuHandler *>::iterator i;
        for(i=objects.begin() ; i != objects.end() ; ++i)
        {
                if((*i)->name == name)
                {
                        MenuHandler *to_remove = *i;
                        objects.remove(to_remove);
                        delete to_remove;
                        return;
                }
        }
}

int MenuHandler::slotEdit(void)
{
        emit edit(name);
        return 0;
}

int MenuHandler::slotRegenerate(void)
{
        emit regenerate(name);
        return 0;
}

int MenuHandler::slotHideShow(void)
{
        emit hideshow(name);
        return 0;
}

int MenuHandler::slotDeleteitem(void)
{
        emit deleteitem(name);
        return 0;
}
// ----------------------------------------------------------------------------------- //
Board::Board(QWidget *parent)
: QGLWidget(parent)
{
        gldata.textures.board = this;
        gldata.textures.read_textures("./textures");

        env = new EnvParameters();
        env->initializeLinkHTable();
        gldata.textures.fill_htablesfields(env->link);


        x=1;
        updateGL();
        timedRefresh();

        lightamb=true; lightpoint = false; rotation = false; windshader=true;

        triangles = 0;
        old_triangles = 0; basetriangles = 0;
        vf1=60; vf2=1; vf3=1000;
        vr1=0; vr2=0; vr3=0;
        var=0;

        srand(time(NULL));

        wind_degree = 0;
        wind_strong = 0;
        wind_up = 0;
        shaking_strong=0;
        wind_strongwave = 0;

        frame=0;

        myPos.x = 0.0f;
        myPos.y = 160.0f;
        myPos.z = 300.0f;
        lookVect.x = 0.0;
        lookVect.y = -0.0;
        lookVect.z = -1.0;

        lookHorizDir = M_PI;
        lookVertDir = -0.7f;

        lookVect.x = sin(lookHorizDir);
        lookVect.y = sin(lookVertDir);
        lookVect.z = cos(lookHorizDir);

        stepFactor = 5.0f;
        mouseFactor = 0.2f;
        keyUp = 0;	keyDown = 0;  keyLeft = 0;  keyRight = 0;

        setFocus(Qt::OtherFocusReason);



}

void Board::keyPressEvent(QKeyEvent *e)
{
        if(e->key() == Qt::Key_A || e->key() == Qt::Key_Left )
                keyLeft = 1;
        if(e->key() == Qt::Key_D || e->key() == Qt::Key_Right)
                keyRight = 1;
        if(e->key() == Qt::Key_S || e->key() == Qt::Key_Down)
                keyDown = 1;
        if(e->key() == Qt::Key_W || e->key() == Qt::Key_Up)
                keyUp = 1;

        QWidget::keyPressEvent(e);
}

void Board::keyReleaseEvent(QKeyEvent *e)
{
        if(e->key() == Qt::Key_A || e->key() == Qt::Key_Left)
                keyLeft = 0;
        if(e->key() == Qt::Key_D || e->key() == Qt::Key_Right)
                keyRight = 0;
        if(e->key() == Qt::Key_S || e->key() == Qt::Key_Down)
                keyDown = 0;
        if(e->key() == Qt::Key_W || e->key() == Qt::Key_Up)
                keyUp = 0;

        QWidget::keyReleaseEvent(e);
}

void Board::mousePressEvent(QMouseEvent *e)
{
        QPoint center;

        lastX = e->x();
        lastY = e->y();

        refX = width() / 2;
        refY = height() / 2;
        center = mapToGlobal(QPoint(refX,refY));
        QCursor::setPos(center);

        centerX = center.x();
        centerY = center.y();

}

void Board::mouseMoveEvent(QMouseEvent *e)
{
        double p;
        int diffX,diffY;

        diffX = e->x() - refX;
        diffY = e->y() - refY;

        lookHorizDir -= diffX * (2*M_PI / 360) * mouseFactor;
        lookVertDir  -= diffY * (2*M_PI / 360) * mouseFactor;
        if(lookVertDir > (M_PI / 2))
            lookVertDir = M_PI / 2;
        if(lookVertDir < -(M_PI / 2))
            lookVertDir = - M_PI / 2;

        lookVect.y = sin(lookVertDir);
        p = cos(lookVertDir);
        lookVect.x = sin(lookHorizDir)*p;
        lookVect.z = cos(lookHorizDir)*p;
        lookVect.normalizeXYZvect();

        sdebug(QString("diff x-y:%1 %2  lookHorizDir:%3  Vert:%4 -- %5")
               .arg(diffX).arg(diffY).arg(lookHorizDir).arg(lookVertDir).arg(lookVect.toString()));
        QCursor::setPos(centerX,centerY);
        setCursor(Qt::BlankCursor);

}

void Board::mouseReleaseEvent(QMouseEvent *e)
{
/*
        int diffX,diffY;

        diffX = e->x() - lastX;
        diffY = e->y() - lastY;

        lookHorizDir += diffX * (M_PI / 180) * mouseFactor;
        lookVertDir  += diffY * (M_PI / 180) * mouseFactor;
        lookVect.x = sin(lookHorizDir);
        lookVect.y = sin(lookVertDir);
        lookVect.z = cos(lookHorizDir);
        lookVect.normalizeXYZvect();
*/
        QCursor::setPos(mapToGlobal(QPoint(lastX,lastY)));
        setCursor(Qt::ArrowCursor);
}


int Board::timedRefresh(void)
{
        wind_strongwave+=1;
        if(wind_strongwave > 360.0f)
                wind_strongwave -= 360;

        x+=3;
        if(x>=361)
                x=0;

        QVector3D windvec;

        wind_strong += -0.2  + ( (double)(rand()%1000) / 1000) * 0.4 ;
        shaking_strong += -0.4  + ( (double)(rand()%1000) / 1000) * 0.8 ;
        wind_up		+= -0.04  + ( (double)(rand()%1000) / 1000) * 0.08;

        if(wind_degree > 360)
                wind_degree -= 360;
        if(wind_degree < 0)
                wind_degree += 360;

        if(wind_strong > 16)
                wind_strong = 16;
        if(wind_strong < 0)
                wind_strong = 0;

        if(wind_up > 1)
                wind_up = 1.0;
        if(wind_up < -1)
                wind_up = -1.0;

        if(shaking_strong > 3)
                shaking_strong = 3;
        if(shaking_strong < 0)
                shaking_strong = 0;

        wind_strong = 4;
        wind_degree++;
        wind_up = 0;

        windvec.setX(sin(wind_degree*(2.0f*M_PI/360.0f)) * sin(wind_strongwave*(2*M_PI/360.0f))*wind_strong);
        windvec.setY(wind_up);
        windvec.setZ(cos(wind_degree*(2.0f*M_PI/360.0f)) * sin(wind_strongwave*(2*M_PI/360.0f))*wind_strong);

        gldata.sprogram->setUniformValue(gldata.shader_wind,windvec);
        gldata.sprogram->setUniformValue(gldata.shader_shaking,(float)(  shaking_strong*cos(wind_strongwave*10*(2*M_PI/360.0f))  ));

        //sprogram->setUniformValue(shader_t1,ltex);
        //sprogram->setUniformValue(shader_t2,lmtex);


    QTimer::singleShot(20,this,SLOT(timedRefresh()));
        //sdebug(QString("%1 fps").arg(frame*10));


        /*myPos,lookVect
        stepFactor
        lookDir=0.0f;*/
        if(keyLeft)
        {
                Vertex relvect;
                relvect.x = -lookVect.z;
                relvect.z =  lookVect.x;
                myPos.addVectWithLength(&relvect,-stepFactor);
        }
        if(keyRight)
        {
                Vertex relvect;
                relvect.x = lookVect.z;
                relvect.z = -lookVect.x;
                myPos.addVectWithLength(&relvect,-stepFactor);
        }

        if(keyDown)
                myPos.addVectWithLength(&lookVect,-stepFactor);
        if(keyUp)
                myPos.addVectWithLength(&lookVect,stepFactor);


        updateGL();

        frame=0;
        return 0;
}

int Board::redraw(void)
{
        updateGL();
        return 0;
}

int Board::regenerateAll(void)
{
        sdebug("Regenerate");

        list<ElementParameters *>::iterator i;
        for( i = db.innerdb.begin() ; i != db.innerdb.end() ; ++i)
                (*i)->state = 0;
        return 0;
}

void Board::loadTexture(int *loc,QString file)
{
        QImage img_tex;

        img_tex.load(file);
        if(img_tex.isNull())
                QMessageBox::warning(0,"Texture loading:Error!",QString("Texture loading:Error.(%1)").arg(file));
        *loc = bindTexture(img_tex,GL_TEXTURE_2D);

}

void Board::initializeGL()
{

    GLenum err = glewInit();
    if (GLEW_OK != err)
    {
        /* Problem: glewInit failed, something is seriously wrong. */
        QMessageBox::warning(this,"Glew initialization error",((const char *)glewGetErrorString(err)));
    }


    // Set up the rendering context, define display lists etc.:
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        qglClearColor(QColor(255,0,0));

        glEnable(GL_DEPTH_TEST);

        glEnable(GL_BLEND);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


        glEnable(GL_LIGHTING);
        glShadeModel(GL_SMOOTH);
        glEnable(GL_NORMALIZE);

        glCullFace(GL_FRONT_AND_BACK);


        QFile vscode();
        QFile fscode();

        gldata.sprogram = new QGLShaderProgram(context());
        gldata.sprogram->addShaderFromSourceFile(QGLShader::Vertex,"vertex_shader.c");
        gldata.sprogram->addShaderFromSourceFile(QGLShader::Fragment,"fragment_shader.c");
        sdebug(gldata.sprogram->log());
        gldata.sprogram->link();
        gldata.sprogram->bind();
        sdebug(gldata.sprogram->log());

        gldata.shader_wind = gldata.sprogram->uniformLocation("wind");
        gldata.shader_globalflex = gldata.sprogram->attributeLocation("globalflex");
        gldata.shader_localflex = gldata.sprogram->attributeLocation("localflex");
        gldata.shader_shaking = gldata.sprogram->uniformLocation("shaking");
        gldata.shader_shakedir = gldata.sprogram->attributeLocation("shakedir");
        gldata.shader_t1 = gldata.sprogram->uniformLocation("Texture0");
        gldata.shader_t2 = gldata.sprogram->uniformLocation("Texture1");

        gldata.sprogram->enableAttributeArray(gldata.shader_shakedir);

        env->sync();

        genList0();
}

void Board::resizeGL(int w, int h)
{
        glClearColor(0.8f, 0.8f, 1.0f, 0.0f);
        glViewport(0, 0, (GLint)w, (GLint)h);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Board::genList0(void)
{
                glNewList(1,GL_COMPILE);

                float matAmbientLight2[] = { 0.4f, 0.4f, 0.4f, 1.0f };
                float matDiffuseLight2[] = { 0.7f, 0.7f, 0.7f, 1.0f };
                float matSpecularLight2[]= { 0.0f, 0.0f, 0.0f, 0.0f };
                float matEmissionLight2[]= { 0.0f, 0.0f, 0.0f, 0.0f };
                float matShininessLight2[]= { 0.1f, 0.1f, 0.1f, 0.0f };

                glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,matAmbientLight2);
                glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,matDiffuseLight2);
                glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,matSpecularLight2);
                glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,matEmissionLight2);
                glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,matShininessLight2);

                TreeGenerator g(&gldata);

                g.buildGround(env);

                glEndList();
                basetriangles =  g.triangles;
}

int Board::freeListNum(void)
{
        int min=2;
        int nn;
        bool found;

        for(nn=min ; nn < 256 ; ++nn)
        {
                found = false;
                list<ElementParameters *>::iterator i;
                for( i = db.innerdb.begin() ; i != db.innerdb.end() ; ++i)
                        if((*i)->display_list == nn)
                                found = true;
                if(!found)
                        return nn;
        }
        return 0;
}


void Board::genListX(void)
{
                int lN=2;

                list<ElementParameters *>::iterator i;
                for( i = db.innerdb.begin() ; i != db.innerdb.end() ; ++i)
                {
                        if((*i)->state == 0)
                        {
                                lN = (*i)->display_list;
                                if(lN == 0)
                                        lN = freeListNum();

                                TreeGenerator g(&gldata);


                                glNewList(lN,GL_COMPILE);

                                float matAmbientLight2[] = { 0.4f, 0.4f, 0.4f, 1.0f };
                                float matDiffuseLight2[] = { 0.7f, 0.7f, 0.7f, 1.0f };
                                float matSpecularLight2[]= { 0.0f, 0.0f, 0.0f, 0.0f };
                                float matEmissionLight2[]= { 0.0f, 0.0f, 0.0f, 0.0f };
                                float matShininessLight2[]= { 0.1f, 0.1f, 0.1f, 0.0f };
                                glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,matAmbientLight2);
                                glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,matDiffuseLight2);
                                glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,matSpecularLight2);
                                glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,matEmissionLight2);
                                glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,matShininessLight2);

                                (*i)->drawMe(&g);
                                (*i)->state = 1;
                                (*i)->display_list = lN;
                                (*i)->triangles = g.triangles;
                                glEndList();
                        }
                }

}

void Board::paintGL(void)
{
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(54,(float)width()/(float)height(),1,1000);

        glEnable(GL_TEXTURE_2D);
        glMatrixMode (GL_MODELVIEW);
        glLoadIdentity();

        float global_ambient[] = { 0.85, 0.85f, 0.85f, 1.0f };
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);

        gluLookAt(0,0,100,	 0,50,0,	  0,1,0);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        TreeGenerator *gen = new TreeGenerator(&gldata);
        gen->buildSky(env);
        delete gen;

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(vf1,(float)width()/(float)height(),vf2,vf3);
        glMatrixMode (GL_MODELVIEW);

        gluLookAt(myPos.x, myPos.y,myPos.z,
                          myPos.x+lookVect.x,myPos.y+lookVect.y,myPos.z+lookVect.z,
                          0.0f, 0.1f, 0.0f);

        /*sdebug(QString("gluLookAt(%1,%2,%3,%4,%5,%6,0,1,0);")
               .arg(myPos.x).arg(myPos.y).arg(myPos.z)
               .arg(myPos.x+lookVect.x).arg(myPos.y+lookVect.y).arg(myPos.z+lookVect.z));
        */

        if(rotation)
        {
                glRotatef(vr1,1,0,0);
                glRotatef(vr2+x,0,1,0);
                glRotatef(vr3,0,0,1);
        }

        glColor3f(0.5, 1.0, 0.5);

        genListX();

        /////////////////////////////////////////////////////////////////////
        if(lightpoint)
        {
                double lpx,lpy,lpz;
                lpy = 180;
                lpx = 110*sin(x*2*(2.0f*M_PI/360.0f));
                lpz = 110*cos(x*2*(2.0f*M_PI/360.0f));

                // Create light components
                float ambientLight[]	= { 0.2f, 0.2f, 0.2f, 1.0f };
                float diffuseLight[]	= { 0.6f, 0.6f, 0.6f, 1.0f };
                float position1[]		= { lpx, lpy, lpz, 1.0f };
                //float position2[]		= { 0.0f, 0.0f, 1.0f, 0.0f ,0.0f};
                //float specularLight[]	= { 0.6f, 0.6f, 0.6f, 0.6f };

                // Assign created components to GL_LIGHT0
                glLightfv(GL_LIGHT0, GL_AMBIENT	, ambientLight	);
                glLightfv(GL_LIGHT0, GL_DIFFUSE	, diffuseLight	);
                glLightfv(GL_LIGHT0, GL_POSITION, position1		);
                //glLightfv(GL_LIGHT0, GL_POSITION, position2		);
                //glLightfv(GL_LIGHT0, GL_SPECULAR, specularLight	);

                glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION	,0.02f		);
                glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION	,0.0005f	);
                glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION,0.00006f	);

                glEnable(GL_LIGHT0);

                float matAmbientLight[]		=	{ 0.4f, 0.4f, 0.4f, 1.0f };
                float matDiffuseLight[]		=	{ 0.8f, 0.8f, 0.8f, 1.0f };
                float matSpecularLight[]	=	{ 0.0f, 0.0f, 0.0f, 0.6f };
                float matEmissionLight[]	=	{ 1.0f, 1.0f, 1.0f, 0.6f };
                float matShininessLight[]	=	{ 0.6f, 0.6f, 0.6f, 0.6f };

                glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,matAmbientLight);
                glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,matDiffuseLight);
                glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,matSpecularLight);
                glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,matEmissionLight);
                glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,matShininessLight);

                glPushMatrix();
                glTranslated(lpx,lpy,lpz);
                glColor3f(1.0,1.0,1.0);
                gluSphere(gluNewQuadric(),10,10,10);
                glPopMatrix();
        }
        else
        {
                // Create light components
                float ambientLight[]	= { 0.8f, 0.8f, 0.8f, 1.0f };
                float diffuseLight[]	= { 0.4f, 0.4f, 0.4f, 1.0f };
                float position1[]		= { 0, 500, 0, 0.0f };

                glLightfv(GL_LIGHT0, GL_AMBIENT	, ambientLight	);
                glLightfv(GL_LIGHT0, GL_DIFFUSE	, diffuseLight	);
                glLightfv(GL_LIGHT0, GL_POSITION, position1		);

                glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION	,1.0f		);
                glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION	,0.0f	);
                glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION,0.0f	);

                glEnable(GL_LIGHT0);
        }
        /////////////////////////////////////////////////////////////////////

        glCallList(1);

        triangles = basetriangles;
        list<ElementParameters *>::iterator i;
        for( i = db.innerdb.begin() ; i != db.innerdb.end() ; ++i)
                if((*i)->state == 1)
                {
                        glCallList((*i)->display_list);
                        triangles += (*i)->triangles;
                }

        glFlush();
        glDisable(GL_TEXTURE_2D);

        if(old_triangles != triangles)
        {
                emit putStatusMsg(QString("%1 triangles rendered.").arg(triangles));
                old_triangles = triangles;
        }


        ++frame;
        if(frame > 10000000)
                frame=0;
}


//end code.
