/* **********************************************************
    NtfsTame - NTFS file/directory name encoding corrector
     http://hyperprog.com

    (C) 2018 Peter Deak (hyper80@gmail.com)

    License: GPLv2  http://www.gnu.org/licenses/gpl-2.0.html
************************************************************* */

#include <iostream>
#include <string.h>
#include <windows.h>
#include <locale.h>
#include <stdio.h>
#include <list>

#define PROGRAMNAME "NtfsTame"
#define PROGRAMCMD  "ntfstame"
#define VERSION     "0.8"

using namespace std;

struct ChCh
{
    int sL,sH,tL,tH;
};

int dorealwork = 1;
int console_width_settings=80;
int col_limit = 0;
int console_width_calculated = 0;
int verbose = 0;
int recursive = 0;
int fixcounter = 0;
int drycounter = 0;
int showindex = 0;
int useccp = 0;
int dots = 0;
UINT cp_to_console = 0;

list<ChCh> chmap;

int printhelp(void)
{
    printf("%s - NTFS file/directory name encoding corrector utility\n\n",PROGRAMNAME);
    printf("  Usage: %s <command> [switches] <directory>...\n",PROGRAMCMD);
    printf("    \n");
    printf("Commands:\n");
    printf("  show - List the emtries in the directory\n");
    printf("    %s show [switches] <DIRECTORY_TO_SHOW>\n",PROGRAMCMD);
    printf("    %s show D:\\myprog\n",PROGRAMCMD);
    printf("    %s show -vv -i -width=90 \"C:\\My data\\store\"\n",PROGRAMCMD);
    printf("  fix - Fix the entries in the directory according to the map file\n");
    printf("    %s fix [switches] -map=<MAPFILE> <DIRECTORY_TO_FIX_CONTENT>\n",PROGRAMCMD);
    printf("    %s fix -r -d -map=map.txt \"C:\\My data\\store\"\n",PROGRAMCMD);
    printf("    %s fix -r -map=\"D:\\map.txt\" -ccp=852 D:\\myprog \n",PROGRAMCMD);
    printf("Switches:\n");
    printf(" -v         - Be verbose\n");
    printf(" -vv        - Be more verbose\n");
    printf(" -i         - Show indexes in show mode.\n");
    printf(" -d         - Dry run, doesn't change anything on filesystem, just print the actions.\n");
    printf(" -r         - Recousive work, processing subdirectories too.\n");
    printf(" -ccp=CODE  - Use this CODE code page in the terminal.\n");
    printf(" -map=MAPF  - Set character mapping file MAPF\n");
    printf(" -width=COL - Set console character width in \"show\" mode\n");
    printf(" -h         - Print help\n");
    printf(" -version   - Version and author informations\n");
    return 0;
}

int printversionabout(void)
{
    printf("%s - NTFS file/directory name encoding corrector utility\n",PROGRAMNAME);
    printf("Author: Peter Deak (hyper80@gmail.com) http://hyperprog.com/ntfstame\n");
    printf("Version: %s\n",VERSION);
    printf("License: GPLv2\n");
    return 0;
}

/* Trims the / and \ signs from end of string */
void trimenddir(char *str)
{
    int l;
    while((l=strlen(str)) > 1 && (str[l-1] == '/' || str[l-1] == '\\' ))
    {
        str[l-1] = '\0';
    }
}


int readmapfile(char *mapfile)
{
    char buffer[1024];
    int rmc = 0;
    FILE *mf = fopen(mapfile,"r");
    if(mf == NULL)
    {
        fprintf(stderr,"Cannot open file: %s\n",mapfile);
        return 0;
    }
    while(!feof(mf))
    {
        if(fgets(buffer,1024,mf)!=NULL)
        {
            ChCh n;
            if(sscanf(buffer,"%d,%d=>%d,%d;",&n.sH,&n.sL,&n.tH,&n.tL) == 4)
            {
                chmap.push_back(n);
                ++rmc;
            }
        }
    }
    fclose(mf);
    return rmc;
}

int scandir(WCHAR *path)
{
    HANDLE hFind;
    WCHAR nameto[512];
    WIN32_FIND_DATAW FindFileDataW;
    char conv_buf[1024];

    if(verbose > 0)
    {
        WideCharToMultiByte(cp_to_console,0,path,-1,conv_buf,512,NULL,NULL);
        printf("%s ...\n",conv_buf);
    }
    else
    {
        if(dots)
            printf(".");
    }

    WCHAR path_to_scan[1024];
    _snwprintf(path_to_scan,1024,TEXT("%s/*"),path);
    if((hFind = FindFirstFileExW(path_to_scan,FindExInfoStandard,&FindFileDataW,FindExSearchNameMatch,NULL,0)) != INVALID_HANDLE_VALUE )
    {
        bool needchange;
        do
        {
            needchange = false;
            int i,l;

            if(FindFileDataW.dwFileAttributes & FILE_ATTRIBUTE_DEVICE )
                continue;

            wcscpy(nameto,FindFileDataW.cFileName);
            l = wcslen(FindFileDataW.cFileName);
            for(i=0;i<l;++i)
            {
                WCHAR u = FindFileDataW.cFileName[i];
                for(list<ChCh>::iterator it = chmap.begin();it != chmap.end();it++)
                {
                    if(((u&0xff00)>>8) == it->sH && (u&0x00ff) == it->sL)
                    {
                        nameto[i] = it->tL | (it->tH<<8);
                        needchange = true;
                    }
                }
            }

            if(needchange && !!wcscmp(FindFileDataW.cFileName,nameto))
            {
                if(verbose == 0 && dots)
                    printf("\n");

                WideCharToMultiByte(cp_to_console,0,path,-1,conv_buf,512,NULL,NULL);
                printf("Rename in \"%s\"\n",conv_buf);
                WideCharToMultiByte(cp_to_console,0,FindFileDataW.cFileName,-1,conv_buf,512,NULL,NULL);
                printf(" \"%s\" -> ",conv_buf);
                WideCharToMultiByte(cp_to_console,0,nameto,-1,conv_buf,512,NULL,NULL);
                printf("\"%s\"\n",conv_buf);

                if(dorealwork)
                {
                    int rv;
                    WCHAR from[1024];
                    _snwprintf(from,1024,TEXT("%s/%s"),path,FindFileDataW.cFileName);
                    WCHAR to[1024];
                    _snwprintf(to,1024,TEXT("%s/%s"),path,nameto);

                    rv = _wrename(from,to);
                    if(rv != 0)
                    {
                        printf("Error on rename! ErrNo:%d %s",errno,errno==17 ?"(Target file exists)":"");
                        exit(1);
                    }
                    ++fixcounter;
                    FindClose(hFind);
                    return 1;
                }
                ++drycounter;
            }

            if(FindFileDataW.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
            {
                if(wcscmp(FindFileDataW.cFileName,TEXT(".")) && wcscmp(FindFileDataW.cFileName,TEXT("..")))
                {
                    WCHAR path_to_pass[1024];
                    _snwprintf(path_to_pass,1024,TEXT("%s/%s"),path,FindFileDataW.cFileName);
                    while(scandir(path_to_pass) > 0);
                }
            }
        }
        while(FindNextFileW(hFind, &FindFileDataW) != 0);
        FindClose(hFind);
    }
    else
    {
        if(verbose == 0 && dots)
            printf("\n");
        WideCharToMultiByte(cp_to_console,0,path,-1,conv_buf,512,NULL,NULL);
        printf("Error, reading directory: %s\n",conv_buf);
        return -1;
    }
    return 0;
}

int showdir(WCHAR *path)
{
    HANDLE hFind;
    WIN32_FIND_DATAW FindFileDataW;
    char conv_buf[1024];

    if(verbose > 0)
    {
        WideCharToMultiByte(cp_to_console,0,path,-1,conv_buf,512,NULL,NULL);
        printf("%s ...\n",conv_buf);
    }

    WCHAR path_to_scan[1024];
    _snwprintf(path_to_scan,1024,TEXT("%s/*"),path);
    if((hFind = FindFirstFileExW(path_to_scan,FindExInfoStandard,&FindFileDataW,FindExSearchNameMatch,NULL,0)) != INVALID_HANDLE_VALUE )
    {
        do
        {
            int i0,i1,i2,i3,sl,mn,l;

            if(FindFileDataW.dwFileAttributes & FILE_ATTRIBUTE_DEVICE )
                continue;

            if(!wcscmp(FindFileDataW.cFileName,TEXT(".")) || !wcscmp(FindFileDataW.cFileName,TEXT("..")))
                continue;

            l = wcslen(FindFileDataW.cFileName);
            WideCharToMultiByte(cp_to_console,0,FindFileDataW.cFileName,-1,conv_buf,512,NULL,NULL);
            for(i1=0;i1<console_width_calculated;++i1)
                printf("=");
            printf("\n");
            i0 = 0;
            i1 = 0;
            i2 = 0;
            i3 = 0;
            mn = 1;
            printf("TYPE: %s \n",(FindFileDataW.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? "Directory" : "File");
            if(verbose > 0)
                printf("LEN : %d \n",l);
            printf("NAME: %s \n",conv_buf);
            while(i1<l && i3<l)
            {
                if(showindex)
                {
                    printf("INDX-%d:",mn);
                    sl=0;
                    while(i0<l)
                    {
                        WCHAR u = FindFileDataW.cFileName[i0];
                        WCHAR utfu[5];
                        _snwprintf(utfu,5,TEXT("%c"),u);
                        WideCharToMultiByte(cp_to_console,0,utfu,-1,conv_buf,512,NULL,NULL);

                        printf("%02d    %s|",i0+1,conv_buf);
                        ++i0;
                        ++sl;

                        if(sl>=col_limit)
                            break;
                    }
                    printf("\n");
                }

                printf("CODE-%d:",mn);
                sl=0;
                while(i1<l)
                {
                    WCHAR u = FindFileDataW.cFileName[i1];
                    printf("%3d,%3d|",(u&0xff00)>>8,u&0x00ff);
                    ++i1;
                    ++sl;

                    if(sl>=col_limit)
                        break;
                }
                printf("\n");
                if(verbose > 1)
                {
                    printf("HEXA-%d:",mn);
                    sl=0;
                    while(i2<l)
                    {
                        WCHAR u = FindFileDataW.cFileName[i2];
                        printf("x%02x,x%02x|",(u&0xff00)>>8,u&0x00ff);
                        ++i2;
                        ++sl;

                        if(sl>=col_limit)
                            break;
                    }
                    printf("\n");
                }
                printf("CHAR-%d:",mn);
                sl=0;
                while(i3<l)
                {
                    WCHAR u = FindFileDataW.cFileName[i3];
                    if(isprint((u&0xff00)>>8))
                        printf("%c  ,",(u&0xff00)>>8);
                    else
                        printf("___,");

                    if(isprint(u&0x00ff))
                        printf("%c  |",u&0x00ff);
                    else
                        printf("___|");
                    //printf("%c  ,%c  |",(u&0xff00)>>8,u&0x00ff);
                    ++sl;
                    ++i3;
                    if(sl>=col_limit)
                        break;
                }
                printf("\n");
                ++mn;
            }
        }
        while(FindNextFileW(hFind, &FindFileDataW) != 0);
        FindClose(hFind);
    }
    else
    {

        WideCharToMultiByte(cp_to_console,0,path,-1,conv_buf,512,NULL,NULL);
        printf("Error, reading directory: %s\n",conv_buf);
        return -1;
    }
    return 0;
}

int main(int argi,char **argc)
{
    if(argi <= 1)
    {
        printhelp();
        return 0;
    }

    char command[512];
    char dir[512];
    char mapfile[512];

    strcpy(command,"");
    strcpy(dir,".");
    strcpy(mapfile,"");

    int spc = 0;
    char *simpleparams[2];
    simpleparams[0] = command;
    simpleparams[1] = dir;

    int p;
    for(p = 1 ; p < argi ; ++p)
    {
        if(!strcmp(argc[p],"-h") || !strcmp(argc[p],"-help"))
            return printhelp();

        if(!strcmp(argc[p],"-version"))
            return printversionabout();

        if(!strcmp(argc[p],"-v"))
        {
            verbose = 1;
            continue;
        }
        if(!strcmp(argc[p],"-vv"))
        {
            verbose = 2;
            continue;
        }
        if(!strcmp(argc[p],"-i"))
        {
            showindex = 1;
            continue;
        }
        if(!strcmp(argc[p],"-d"))
        {
            dorealwork = 0;
            continue;
        }
        if(!strcmp(argc[p],"-r"))
        {
            recursive = 1;
            continue;
        }
        if(!strcmp(argc[p],"-dots"))
        {
            dots = 1;
            continue;
        }
        if(!strncmp(argc[p],"-ccp",4))
        {
            if(argc[p][4] != '=')
            {
                fprintf(stderr,"Error, Console codepage must specified with = sign ( -ccp=1250 )\n");
                return 1;
            }
            int cp;
            if(sscanf(argc[p]+5,"%d",&cp) == 1)
            {
                cp_to_console = cp;
                useccp = 1;
            }
            continue;
        }
        if(!strncmp(argc[p],"-map",4))
        {
            if(argc[p][4] != '=')
            {
                fprintf(stderr,"Error, Character map file must specified with = sign ( -map=file.txt )\n");
                return 1;
            }
            strncpy(mapfile,argc[p]+5,512);
            continue;
        }
        if(!strncmp(argc[p],"-width",6))
        {
            if(argc[p][6] != '=')
            {
                fprintf(stderr,"Error, Console width must specified with = sign ( -width=90 )\n");
                return 1;
            }
            int w;
            if(sscanf(argc[p]+7,"%d",&w) == 1)
                console_width_settings = w;
            continue;
        }
        if(!strncmp(argc[p],"-",1))
        {
            fprintf(stderr,"Error, unknown switch: \"%s\"\n",argc[p]);
            return 1;
        }
        if(spc < 2)
        {
            strncpy(simpleparams[spc],argc[p],510);
            ++spc;
        }
        else
        {
            fprintf(stderr,"Error, too much parameter passed.\n");
            return 1;
        }
    }

    if(useccp)
    {
        SetConsoleOutputCP(cp_to_console);
    }
    else
    {
        SetConsoleOutputCP(CP_UTF8);
        cp_to_console = CP_UTF8;
    }

    if(!strcmp(command,"help"))
        return printhelp();
    if(!strcmp(command,"version") || !strcmp(command,"about"))
        return printversionabout();

    trimenddir(dir);

    if(verbose > 0)
    {
            printf("======== PARAMETERS ========\n");
            printf("Command: %s\nDirectory: %s\nMapfile: %s\nRecursive: %s\n",
                    command,dir,mapfile,recursive?"yes":"no");
            printf("Console codepage: ");
            if(cp_to_console == CP_UTF8)
                printf("utf-8 (default)");
            else
                printf("%d",cp_to_console);
            printf("\nDry run: %s\n",dorealwork?"no":"yes");
            printf("====== END PARAMETERS ======\n");
    }

    if(!strcmp(command,"show"))
    {
        col_limit = (int)((float)(console_width_settings - 7)/8.0);
        console_width_calculated = col_limit*8+7;
        WCHAR wpath[512];
        MultiByteToWideChar(GetACP(),0,dir,-1,wpath,512);
        showdir(wpath);
        return 0;
    }

    if(!strcmp(command,"fix"))
    {
        int rmc;
        rmc = readmapfile(mapfile);
        printf("%d character mappings readed.\n",rmc);
        printf("============================\n");
        if(verbose > 1)
        {
            int c;
            c=1;
            for(list<ChCh>::iterator it = chmap.begin();it != chmap.end();it++)
                printf("%d: dec %d,%d -> %d,%d hex x%x,x%x -> x%x,x%x\n",c++,it->sH,it->sL,it->tH,it->tL,it->sH,it->sL,it->tH,it->tL);
            printf("============================\n");
        }
        WCHAR wpath[512];
        MultiByteToWideChar(GetACP(),0,dir,-1,wpath,512);
        while(scandir(wpath) > 0);
        if(verbose == 0 && dots)
            printf("\n");
        printf("%d entry fixed.\n",fixcounter);
        if(!dorealwork)
            printf("You would fix %d entry.\n",drycounter);

        return 0;
    }

    fprintf(stderr,"Error, unknown command: %s\n",command);
    return 1;
}

