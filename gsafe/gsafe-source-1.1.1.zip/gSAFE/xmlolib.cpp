/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

    License: GPLv2  http://www.gnu.org/licenses/gpl-2.0.html

    xmlolib.cpp
*/

#include <QtCore>
#include <QtGui>

#include <dconsole.h>
#include <xmlolib.h>

static const char* const image_browse_data[] = { 
"20 20 13 1",
"c c #000000",
"e c #000080",
"k c #0000ff",
"j c #008080",
"i c #00ff00",
"h c #00ffff",
"g c #800000",
"a c #808080",
"d c #c0c0c0",
". c #dbd8d1",
"f c #ff0000",
"# c #ffff00",
"b c #ffffff",
"....................",
"..#..a#.............",
"..a#.ab..a..........",
"...a#a#.a#..........",
"....a#ba#...........",
"..aaab##aaaaaaaaaa..",
"....#abbbbbbbbbbbc..",
"..abda#bbbefbbghbc..",
"..#.aac#bbijbbfjbc..",
"....abddbbddbbddbc..",
"....abbbbbbbbbbbbc..",
"....abfjbbikbbfibc..",
"....abghbbafbbaebc..",
"....abddbbddbbddbc..",
"....abbbbbbbbbbbbc..",
"....accccccccccccc..",
"....................",
"....................",
"....................",
"...................."}; 

HXmloTable::HXmloTable(QWidget *parent,HBase *d)
:QDialog(parent)

{
    data = d;

    setWindowTitle("XML-XLS output...");

    QVBoxLayout *mainlayout = new QVBoxLayout(this);
    QHBoxLayout *toplayout  = new QHBoxLayout(0);
    QHBoxLayout *midlayout  = new QHBoxLayout(0);
    QHBoxLayout *buttlayout = new QHBoxLayout(0);

    QLabel      *label1          = new QLabel("The name and location of the output XML file:",this);
    QPushButton *savePushButton  = new QPushButton(this);
                 savePushButton->setText("Save");
    QPushButton *closePushButton = new QPushButton(this);
                 closePushButton->setText("Close");
                 fnedit          = new QLineEdit(this);
                 fnedit->setText("output.xml");
    QToolButton *fcToolButton    = new QToolButton(this);
                 fcToolButton->setIcon(QIcon(  QPixmap( (const char **) image_browse_data )    ));
    
    toplayout->addStretch();
    toplayout->addWidget(label1);
    toplayout->addStretch();

    midlayout->addStretch();
    midlayout->addWidget(fnedit);
    midlayout->addSpacing(10);
    midlayout->addWidget(fcToolButton);
    midlayout->addStretch();

    buttlayout->addStretch();
    buttlayout->addWidget(savePushButton);
    buttlayout->addSpacing(10);
    buttlayout->addWidget(closePushButton);
    buttlayout->addStretch();
    
    mainlayout->addSpacing(15);
    mainlayout->addLayout(toplayout);
    mainlayout->addSpacing(10);
    mainlayout->addLayout(midlayout);
    mainlayout->addStretch();
    mainlayout->addLayout(buttlayout);
    mainlayout->addSpacing(20);
    
    setSizeGripEnabled(true);

    connect(fcToolButton,SIGNAL(clicked()),this,SLOT(cf()));
    connect(savePushButton,SIGNAL(clicked()),this,SLOT(saveButton()));
    connect(closePushButton,SIGNAL(clicked()),this,SLOT(closeButton()));
    resize(300,160);
}

HXmloTable::~HXmloTable(void)
{
}

int HXmloTable::cf(void)
{
    QString o;
    o = QFileDialog::getSaveFileName(this,"The output xml file","","*.xml");
    if(!o.isEmpty())
      fnedit->setText(o);
    return 0;
}

int HXmloTable::saveButton(void)
{
    sdebug("saveB");

    if(fnedit->text().isEmpty())
        return 0;
    QFile f(fnedit->text());
    if (f.open(QIODevice::WriteOnly))
     {
      QTextStream *s = new QTextStream(&f);    // we will serialize the data into file f
      s->setCodec(QTextCodec::codecForName("UTF-8"));
      genXml(s);
      f.close();
     }
    else
    {
        error("Cannot create file!");
        return 0;
    }
    close();
    return 0;
}

int HXmloTable::closeButton(void)
{
    close();
    return 0;
}


void HXmloTable::genXml(QTextStream *out)
{
    QString tname,tnameshort;

    tname = "Generated table";
    if(data->getWhoami() == "HTable" || data->getWhoami() == "HList")
        if(! ((HTableBase *)data)->tableTitle().isEmpty() )
            tname = ((HTableBase *)data)->tableTitle();
    if(data->getWhoami() == "HPlainDataMatrix")
        if(! ((HPlainDataMatrix *)data)->getTitle().isEmpty() )
            tname = ((HPlainDataMatrix *)data)->getTitle();

    if(tname.length() > 18)
        tnameshort = tname.left(16).append("...");  
    else
        tnameshort = tname;

    if(tnameshort.isEmpty())
        tnameshort="Page";
       
    (*out) << "<?xml version=\"1.0\"?>"<<endl;
    (*out) << "<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\
                      xmlns:o=\"urn:schemas-microsoft-com:office:office\"\
                      xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\
                      xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"\
                      xmlns:html=\"http://www.w3.org/TR/REC-html40\">"<<endl;

    (*out) << "<Styles>"                                                               << endl;
    (*out) << "<Style ss:ID=\"Default\" ss:Name=\"Normal\">"                           << endl;
    (*out) << "<Alignment ss:Vertical=\"Top\" ss:WrapText=\"1\"/>"                     << endl;
    (*out) << "  <Borders/>"                                                           << endl;
    (*out) << "  <Font x:CharSet=\"238\"/>"                                            << endl;
    (*out) << "  <Interior/>"                                                          << endl;
    (*out) << "  <NumberFormat/>"                                                      << endl;
    (*out) << "  <Protection/>"                                                        << endl;
    (*out) << "</Style>"                                                               << endl;
    (*out) << "<Style ss:ID=\"s21\">"                                                  << endl;
    (*out) << "<Font x:CharSet=\"238\" x:Family=\"Swiss\" ss:Bold=\"1\"/>"             << endl;
    (*out) << "</Style>"                                                               << endl;

    (*out) << "<Style ss:ID=\"s23\">"                                                              << endl;
    (*out) << "  <Font x:CharSet=\"238\" x:Family=\"Swiss\" ss:Size=\"14\" ss:Bold=\"1\"/>"        << endl;
    (*out) << "  <Alignment ss:Vertical=\"Top\" ss:WrapText=\"0\"/>"                               << endl;
    (*out) << "</Style>"                                                                           << endl;
    (*out) << "<Style ss:ID=\"s24\">"                                                              << endl;
    (*out) << "   <Borders>"                                                                       << endl;
    (*out) << "      <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>" << endl;
    (*out) << "      <Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"   << endl;
    (*out) << "      <Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"  << endl;
    (*out) << "      <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"    << endl;
    (*out) << "   </Borders>"                                                                      << endl;
    (*out) << "</Style>"                                                                           << endl;
    (*out) << "<Style ss:ID=\"s25\">"                                                              << endl;
    (*out) << "  <Font x:CharSet=\"238\" x:Family=\"Swiss\" ss:Bold=\"1\"/>"                       << endl;
    (*out) << "   <Borders>"                                                                       << endl;
    (*out) << "      <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>" << endl;
    (*out) << "      <Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"   << endl;
    (*out) << "      <Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"  << endl;
    (*out) << "      <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>"    << endl;
    (*out) << "   </Borders>"                                                                      << endl;
    (*out) << "</Style>"                                                                           << endl;
    (*out) << "</Styles>"                                                                          << endl;
   
    //ss:Width=\"220\"


    (*out) << "<Worksheet ss:Name=\""<< tnameshort <<"\">" << endl;
    (*out) << "<Table ss:ExpandedColumnCount=\"50\" ss:ExpandedRowCount=\"50000\" x:FullColumns=\"1\" x:FullRows=\"1\">" <<endl;

    (*out) << "<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                    << endl;
    (*out) << "<Column ss:Index=\"10\" ss:AutoFitWidth=\"1\" ss:Width=\"80\"/>"                   << endl;

    (*out) << "  <Row><Cell/></Row>" <<endl;
    (*out) << "  <Row ss:StyleID=\"s23\"><Cell ss:Index=\"2\"><Data ss:Type=\"String\">" <<
                          tname <<"</Data></Cell></Row>" << endl;
        
    (*out) << "  <Row><Cell/></Row>" << endl;
    (*out) << "  <Row><Cell/></Row>" << endl;

    if(data->getWhoami() == "HTable")
    {
        HTable *data = (HTable *)this->data;

        HDataField *df=NULL;
        data->firstField();
        while((df=data->nextFieldAll()) != NULL)
        {
            if(!df->isShow())
                continue;
            (*out) <<  "  <Row ss:StyleID=\"s25\">" << endl;
            (*out) <<  "      <Cell><Data ss:Type=\"String\">" 
                << df->getExplainText()  << "</Data></Cell>" << endl;
            (*out) <<  "      <Cell  ss:StyleID=\"s24\"><Data ss:Type=\"String\">" 
                << df->dbValueToDispValue(df->getValue()).toString() << "</Data></Cell>" << endl;
            (*out) <<  "  </Row>" << endl;
        }
    }
    else if(data->getWhoami() == "HList")
    {
        HList *data = (HList *)this->data;

        int i;
        QStringList sl;

        //Head!
        sl = data->getShortTitleHeads();
        (*out) <<  "  <Row ss:StyleID=\"s25\">" << endl;
        for(i =0;i < (int)sl.size();++i)
        {
            (*out) <<  "      <Cell><Data ss:Type=\"String\">" << sl[i] << "</Data></Cell>" << endl;
        }
        (*out) <<  "  </Row>" << endl;
       
        QList<QStringList *>::Iterator iv = data->getValues()->begin();
        while(iv != data->getValues()->end())
        {
                sl = **iv;
                (*out) <<  "  <Row ss:StyleID=\"s24\">" << endl;
                for(i =0;i < (int)sl.size();++i)
                {
                    (*out) <<  "      <Cell><Data ss:Type=\"String\">" << sl[i] << "</Data></Cell>" << endl;
                }
                (*out) <<  "  </Row>" << endl;
   
                ++iv;
        }
    }
    else if(data->getWhoami() == "HPlainDataMatrix")
    {
        HPlainDataMatrix *data = (HPlainDataMatrix *)this->data;

        int i;
        QStringList sl;

        //Head!
        sl = data->getHeader();
        (*out) <<  "  <Row ss:StyleID=\"s25\">" << endl;
        for(i =0;i < (int)sl.size();++i)
        {
            (*out) <<  "      <Cell><Data ss:Type=\"String\">" << sl[i] << "</Data></Cell>" << endl;
        }
        (*out) <<  "  </Row>" << endl;
       
        data->firstRow();
        do
        {
                sl = data->currentRowStr();
                (*out) <<  "  <Row ss:StyleID=\"s24\">" << endl;
                for(i =0;i < (int)sl.size();++i)
                {
                    (*out) <<  "      <Cell><Data ss:Type=\"String\">" << sl[i] << "</Data></Cell>" << endl;
                }
                (*out) <<  "  </Row>" << endl;
        }
        while(data->nextRow());
    }
    else
        error("HXmloTable::genXml - Cannot handle item: Not supported type!");

    (*out) << "</Table>" << endl;
    (*out) << "<WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\">" << endl;
    (*out) << "<PageSetup>" << endl;
    (*out) << "<PageMargins x:Bottom=\"0.5\" x:Left=\"0.5\"" << endl;
    (*out) << "x:Right=\"0.5\" x:Top=\"0.5\"/>" << endl;
    (*out) << "</PageSetup>" << endl;
    (*out) << "</WorksheetOptions>" << endl;
    (*out) << "</Worksheet></Workbook>" << endl;
}
//end code
