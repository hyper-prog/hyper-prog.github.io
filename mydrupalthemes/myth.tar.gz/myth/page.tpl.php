<?php
/* comment
 */
?>

<?php 
	$pagebgcolor_out = 'outpagebgcolor';
	$logobgcolor_out = 'outpagebgcolor';
	$headerbgcolor_out = 'outpagebgcolor';
	$footerbgcolor_out = 'outpagebgcolor';
	$mmenubgcolor_out = 'outpagebgcolor';

	if(theme_get_setting('myth_page_stretch') == 'fluid')
	{
		$pagebgcolor_out = 'pagebgcolor';
		$logobgcolor_out = 'logobgcolor';
		$headerbgcolor_out = 'headerbgcolor';
		$footerbgcolor_out = 'footerbgcolor';
		$mmenubgcolor_out = 'mmenubgcolor';
	}
	
	$sidebar_classes = 'column sidebar';
	if(theme_get_setting('myth_sidebar_border') == 'yes')
	{
		$sidebar_classes .= ' sidebar-with-border';
	}
?>

<div id="page" class="pagebgcolor">

    <div id="mainmenu-show-area" class="<?php print $mmenubgcolor_out; ?>">
    	<div id="myth-mainmenu" class="mmenubgcolor">
            <?php print render($page['menu_top']); ?>
            <div id="fake-mmdiv"></div>
        </div>
    </div>

    <?php if ($logo): ?>
        <div id="sitelogoarea" class="<?php print $logobgcolor_out; ?>">
            <div id="thelogoarea" class="logobgcolor">
                <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
                    <div id="thelogoimage">
                        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
                        <div id="fake-mmdiv"></div>
                    </div>
                    <div id="fake-mmdiv"></div>
                </a>
                <div id="fake-mmdiv"></div>
            </div>
        </div>
    <?php endif; ?>

    <div id="mainmenu-show-area" class="<?php print $mmenubgcolor_out; ?>">
       	<div id="myth-mainmenu" class="mmenubgcolor">
            <?php print render($page['menu_logo_head']); ?>
            <div id="fake-mmdiv"></div>
        </div>
    </div>

    <div id="headerarea" class="<?php print $headerbgcolor_out; ?>">
        <div id="header" class="headerbgcolor">
            <div class="section clearfix">
                <?php if ($site_name || $site_slogan): ?>
                    <div id="name-and-slogan">
                        <?php if ($site_name): ?>
                                <div id="site-name">
                                    <strong>
                                        <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home"><span><?php print $site_name; ?></span></a>
                                    </strong>
                                </div>
                        <?php endif; ?>
                        <?php if ($site_slogan): ?>
                            <div id="site-slogan">
                                <?php print $site_slogan; ?>
                            </div>
                        <?php endif; ?>
                    </div> <!-- /#name-and-slogan -->
                <?php endif; ?>
                <?php print render($page['header']); ?>
            </div> <!-- /.section -->
        </div> <!-- /#header -->
    </div> <!-- /#headerarea -->

    <div id="mainmenu-show-area" class="<?php print $mmenubgcolor_out; ?>">
       	<div id="myth-mainmenu" class="mmenubgcolor">
            <?php print render($page['menu_head_cont']); ?>
            <div id="fake-mmdiv"></div>
        </div>
    </div>

    <?php if ($main_menu || $secondary_menu): ?>
        <div id="navigation">
            <div class="section">
                <?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'main-menu', 'class' => array('links', 'inline', 'clearfix')), 'heading' => t('Main menu'))); ?>
                <?php print theme('links__system_secondary_menu', array('links' => $secondary_menu, 'attributes' => array('id' => 'secondary-menu', 'class' => array('links', 'inline', 'clearfix')), 'heading' => t('Secondary menu'))); ?>
            </div> <!-- /.section -->
        </div> <!-- /#navigation -->
    <?php endif; ?>

    <?php print $messages; ?>

    <div id="mainouterarea" class="<?php print $pagebgcolor_out; ?>">
    <div id="mainarea" class="pagebgcolor clearfix">
        <div id="page-top" class="page-top-area">
            <div class="section">
                <?php print render($page['page_top']); ?>
            </div> <!-- /.section -->
        </div> 

        <div id="page-common-top" class="page-common-top-area">
            <div class="section">
                <?php print render($page['page_common_top']); ?>
            </div> <!-- /.section -->
        </div> 

        <?php if ($page['sidebar_first']): ?>
            <div id="sidebar-first" class="<?php print $sidebar_classes; ?>">
                <div class="section">
                    <?php print render($page['sidebar_first']); ?>
                    </div> <!-- /.section -->
            </div> <!-- /#sidebar-first -->
        <?php endif; ?>

        <div id="maincontent" class="column">
            <div class="section">
                <?php if ($page['highlighted']): ?>
                    <div id="highlighted">
                        <?php print render($page['highlighted']); ?>
                    </div>
                <?php endif; ?>
                <a id="main-content"></a>
                <?php print render($title_prefix); ?>
                <?php if ($title): ?>
                    <h1 class="title" id="page-title"><?php print $title; ?></h1>
                <?php endif; ?>
                <?php print render($title_suffix); ?>
                <?php if ($tabs): ?>
                    <div class="tabs"><?php print render($tabs); ?></div>
                <?php endif; ?>

                <?php if ($action_links): ?><ul class="action-links"><?php print render($action_links); ?></ul><?php endif; ?>

                <?php print render($page['content']); ?>
                <?php print $feed_icons; ?>
                <?php print render($page['help']); ?>
            </div> <!-- /.section -->
            <div id="fake-mmdiv"></div>
        </div> <!-- /#maincontent -->

        <?php if ($page['sidebar_second']): ?>
            <div id="sidebar-second" class="<?php print $sidebar_classes; ?>">
                <div class="section">
                    <?php print render($page['sidebar_second']); ?>
                </div> <!-- /.section -->
            </div> <!-- /#sidebar-second -->
        <?php endif; ?>
        <div id="fake-mmdiv"></div>
    </div> <!-- /#mainarea -->
    </div> <!-- mainouterarea -->

    <div id="footerarea" class="<?php print $footerbgcolor_out; ?>">
        <div id="footer" class="footerbgcolor">
            <div class="section">
                <?php print render($page['footer']); ?>
            </div> <!-- /.section -->
            <div id="fake-mmdiv"></div>
        </div> <!-- /#footer -->
    </div>
</div> <!-- /#page,  -->
