/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

	hfactory.h
*/
#ifndef GSAFE__HFACTORY_LIB_HEADER_FILE_X_
#define GSAFE__HFACTORY_LIB_HEADER_FILE_X_

#include <QtCore>
#include <QtXml>

#define TABLE  0
#define LIST   1
#define FIELDS 2

class HTable;
class HList;
class HTableBase;
class HDataField;

class Hff_node
{
public:
	QString name;
	HDataField *f;

	Hff_node(QString namep,HDataField *fp);
	~Hff_node(void);

};

class HFactory : public  QObject , QXmlDefaultHandler //, QXmlErrorHandler 
{
	Q_OBJECT

	public:
		HFactory(QString rdata);
		~HFactory(void);

        void appendTemplateData(QString rdata);
        void clearTemplateData(void);

	    HTableBase *genTable (QString part,int mode=TABLE);
		HTable     *genHTable(QString part) { return (HTable *)genTable(part,TABLE); }
		HList      *genHList (QString part) { return (HList  *)genTable(part,LIST ); }


	private:
		int ttype; //HTable || HList   = TABLE || LIST
		int level; //melyseg az XML ben
		bool fields_readed;
		bool mainblock,read_on,fieldread_on; //Foblokkban vagyek-e illetve a kivant reszben vagyok-e
		QString pname; //A kivant resz neve
		QString fname; //az epp olvasott mezo neve.
		QString fpar_att,fpar_def,fpar_sql;
		QString errstr;

		QString rawdata; //A nyers adat(XML) amin dolgozunk

		HTableBase *t; //ezt epitem...
		HDataField *f; //ezekkel...

		QList<Hff_node *> *fieldlist;

		//puffermez�k
		QString buffer,
				buffer_sql,
			    buffer_exp,
				buffer_tit,
				buffer_tail,
				buffer_def,
				buffer_func,
                buffer_valid,
				buffer_hashf,
				buffer_specsort,
				buffer_popuptitle,
				buffer_minimum,
				buffer_maximum,
				buffer_1,
				buffer_2,
				buffer_3,
				buffer_4,
				buffer_5,
				buffer_6;
		
		QStringList buffer_k,
					buffer_v,
                    buffer_notvalid;

		QStringList markers;
		bool    easy,
				editable,
				show,
				color,
				meldwithnext,
				nomiddlestretch,
				showprogress;
		int		guieditmaxwidth;
		int     r,g,b;
        int     sortc;

		void insertDF(HDataField *df);

	public:
		bool startDocument(void);
		bool endDocument(void);
		bool startElement( const QString& ns, const QString& ln, const QString& name, 
                       const QXmlAttributes& atts);
		bool endElement( const QString& ns, const QString& ln, const QString& name);
		bool characters(const QString& ch);
		QString errorString(void);

		bool warning(const QXmlParseException& exception);
		bool error(const QXmlParseException& exception);
		bool fatalError(const QXmlParseException& exception);
		
	private:
		void setHDataFieldAttributes(HDataField * d);
		void emptyBuffer(void);

    signals:
        void errorSignal(QString err);

};


#endif
