/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2010 Peter Deak  (hyper80@gmail.com)

	guilib.h +MOC
*/

#ifndef GSAFE__GUILIB_HEADER_FILE_X_
#define GSAFE__GUILIB_HEADER_FILE_X_

#include <QtCore>
#include <QtGui>

#include <datalib.h>

#define EXT_EDIT_PROCESS    "externaledit.bat"

#define NEED_UPDATE 0
#define CLICK_ON_CELL 1

/*  Gui osztalyok adatkezelesenek a modja 
    (azazhogy mit csinal a gui objektum az adatobjektumaval indulaskor es leallaskor)
        KEEP_ALL     - Nem modositja az adatosztalyt, indulaskor annak adataival all fel, befejezeskor
                       az adatokat ugy hagyja ahogy volt.
        FULL_CLEAN   - Indulaskor visszat�r�t mindent a default ertekre, es csak utana indul el/olvas fel
                       Befejezeskor szinten kipucol minden adatot, es visszallit default-ra. (alap�rtelmezett)
        START_CLEAN  - Csak indulaskor all vissza alapertelmezesre
        END_CLEAN    - Csak befejezeskor all vissza alapertelmezesre  */
#define KEEP_ALL     0
#define FULL_CLEAN   1
#define START_CLEAN  2
#define END_CLEAN    3

/*A gui objektum a felszabaditasakor szabaditsa-e fel az adatosztalyt is?
        DONT_DELETE_DATA - maradjon meg az objektum (alap�rtelmezett) 
        DELETE_DATA      - szabaditsa fel az adatobjektumot. Kapcsolt adatobjektumokat is felszabad�tja! */

#define DONT_DELETE_DATA 0  
#define DELETE_DATA      1

class QLabel;
class QLineEdit;
class QComboBox;
class QTextEdit;
class QCheckBox;
class QDateEdit;
class QToolButton;
class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QPoint;
class QKeyEvent;

class HTableBrowserElement;


class HArrayButton : public QPushButton
{
    Q_OBJECT

    public:
        static int defaultSizeX,defaultSizeY;

        HArrayButton(QString text,QWidget *parent);
        ~HArrayButton(void);

        static QLayout * abc_filt(QWidget *parent,const QObject *receiver,const char *member);

    private slots:
        int clickHandler(void);

    signals:
        void clickedValue(QString text);
};

class HSpinBox : public QFrame
{
    Q_OBJECT

    public:
        HSpinBox(QWidget *parent);
        ~HSpinBox(void);

		void setMinValue(int v) { min = v; check(); }
		void setMaxValue(int v) { max = v; check(); }
		
		int value(void)			{ return val; }

    public slots:
        int setValue(int v);  

	protected:
		int val;
		int min,max;
		QString oldtext;

		QLineEdit *le;

    protected slots:
		void check(void);
		int  leChanged(const QString& t);
		int  bUp(void);
		int  bDown(void);

	protected:
		void wheelEvent(QWheelEvent *e);
	
	signals:
		void valueChanged(int);
};

/*Egy listamegjelenito grafikus osztaly */
class HTableBrowserElementPair
{
	public:
		HTableBrowserElementPair(HTableBrowserElement *lp,HTableBrowserElement *rp)
			{ left = lp; right = rp; };

		HTableBrowserElement *left;
		HTableBrowserElement *right;
};

class HTableBrowser : public QFrame
{
	Q_OBJECT

	public:
		HTableBrowser(QWidget *parent);
		~HTableBrowser(void);

		void setColumnColor(int col,QColor c);
	
	public slots:
		//Set the query-cursor to the secified version
		void queryToStart(void);   // first element
		void queryToTop(void);     // first display element
		void queryToCurrent(void); // current cursor pos

	public:
		//Get the values of query-cursor and step to the next
		HTableBrowserElement *queryNextElement(void);
		QStringList			 *queryNextValues (void); //Have to delete the returned data!
		QString				 *queryNextKey    (void); //Have to delete the returned data!

		int numberOfElements(void);

		HTableBrowserElement *elementByIndex(int n);
        QStringList			 *valuesByIndex(int n); //Have to delete the returned data!
		QString				 *keyByIndex(int n);    //Have to delete the returned data!

		bool				  hasKey(QString key);

	public slots:
		int clear();
		int addElement(HTableBrowserElement *e);
		/*Kitorli az osszes elemet amelyiknek ad megadott string a kulcsa, visszater a kitorolt elemek szamaval */
		int removeAllElementByKey(QString key);

        /*Elobb kell beallitani mint az elemek beszurasa*/
		int setHeadTexts(QStringList h);

        /*
            Beallitja az aktualis elemet. 
            c -> Az aktualis elem kulcserteke
            t -> A felul levo elem kulcserteke (opcionalis) 
                  Ezen parameter celja, hogy ha nem kell feleslegesen ne gorgessuk at a kepernyon a poziciokat.
        */
		int setCurrentElement(QString c,QString t="");

		int setCurrentElement(int index);
		int setTopElement(int index);

        //Visszaadja az aktualis elem kulcserteket
		void sort(int keycol);
        int  cursorToBegin(void);
        int  cursorToEnd(void);

    public:
        int mouseRightClickPosX;
        int mouseRightClickPosY;

		//Visszaadja az aktualis elemet
		HTableBrowserElement * currentElement(void);
        //Visszaadja az aktualis elem kulcserteket
        QString				   currentKey(void);
		//Visszaadja a kepernyo tetejen levo elemet
		HTableBrowserElement * topElement(void);
        //Visszaadja a kepernyo tetejen levo elem kulcserteket
        QString				   topKey(void);

		void setSpecSort(int col,QString specsortname);

	//================================================================
    private:
        bool asc;
        bool asc2;
        int  keycolumn;
        int  keycolumn2;
		int sortmode;
		//0-normal
		//1-dropchar

		void q_sort    (void); 
        void q_sort_run(HTableBrowserElementPair *p);
	    bool ch(bool m,HTableBrowserElement *a,HTableBrowserElement *b);

		QStack<HTableBrowserElementPair *> *q_sort_stack;

		QString lastkey;

	protected:
        QString last_right_clicked;
		int number;
		int curc;
		HTableBrowserElement *start,*end,*top,*cur,*query_cursor;
		int col_scroll;

		QPixmap			  *pix_up,*pix_down,*pix_asc,*pix_desc,*pix_asc2,*pix_desc2;
		QFontMetrics      *fm;
		QList<int>		   colw;
		QList<QColor>	   colc;
		QList<QString>	   spec_sort;
		QStringList		   head;
		int				   rowh;
		int				   plusw;
		int				   showrow;
		QString			   seek;
		bool			   inscroll;

	protected:
		bool stepUp(void);
		bool stepDown(void);
		bool mouseNetClick(QMouseEvent *e,int rmode = NEED_UPDATE);

	protected:
		void paintEvent(QPaintEvent *e);
		void keyPressEvent(QKeyEvent *e);
		void mousePressEvent(QMouseEvent *e);
		void mouseReleaseEvent(QMouseEvent *e);
		void mouseDoubleClickEvent(QMouseEvent *e);
		void mouseMoveEvent(QMouseEvent *e);
		void wheelEvent(QWheelEvent *e);

	signals:
		void activateItem(const QString& s);
        void alternateActivateItem(const QString& s);
		void itemChanged(const QString& s);
};

class HTableBrowserElement
{
	public: 
		int index;
		QString key;
		QStringList *rows;

	public:
		/*	Letrehoz egy elemet a kulcsa es a lathato ertekeinek alapjan ahol a kulcs a k,
			az ertekek a c StringList-ben vannak */
		HTableBrowserElement(QString k,QStringList *c);
		/*	L�trehoz egy elemet a kulcs es a lathato ertekei alapjan, ahol a k a kulcs,
			az a ertek mindenkepp bekerul, akkoris ha ures (legalabb egy erteknek kell lennie)
			a tobbi ertekek csak addig kerulnek bevitelre ameddig nincs egy ures string, az utana levo reszek ervenytelenek. */
		HTableBrowserElement(QString k,QString a,QString b="",QString c="",QString d="",QString e="");
		~HTableBrowserElement(void);
	
		QString operator[](int i);
		int size(void);
		void swapWith(HTableBrowserElement *x);
        HTableBrowserElement& operator=(HTableBrowserElement& e);
        HTableBrowserElement& operator=(HTableBrowserElement* e);
        QString getCVal(int i) { return (*rows)[i]; };

	public:
		HTableBrowserElement *next,*prev;
};

/** HPlainDataMatrix megjelenito osztaly (Egy listaban megjeleniti az adatokat, mellette
	xml output gombbal, �s print preview -al. */
class HDispPlainDataMatrix : public QFrame
{
	Q_OBJECT

	protected:
		HPlainDataMatrix  *data;
		HTableBrowser *list;

	public:
		/**  parent - QWidget szulo
			 d - adatoszt�ly
			 htmlmode - legyen -e html gomb
			 keyfield - Ha duplaklikknel le akarjuk kezelni az hogy mire kattintottak
				akkor a signal (actiateItem) a kulccsal megadott sorszamu oszlop erteket adja majd vissza
				egyeb esetben a kulcs (-1 ertek) egy sima sorszam.	*/
		HDispPlainDataMatrix(QWidget *parent,HBase *d,bool htmlmode=false,int keyfield=-1);
		~HDispPlainDataMatrix(void);

	public slots:
        int dialogPrint(void);
        int dialogXml(void);
		int dialogHtmlShow(void);
		
		int slotActivateItem(const QString k);

	signals:
		void actiateItem(QString k);

};

/** HDispPlainDataMatrix -hoz egy dialogbox */
class HPlainDMD : public QDialog
{
	Q_OBJECT

	public:
		HPlainDMD(QWidget *parent,HBase *d,bool htmlmode=false);
		~HPlainDMD(void);

};

/*Egyszerre egy rekordot megjeleniteni, �s szerkeszteni k�pes automatikusan generalodo
  QFrame lesz�rmazott. Egy param�terk�nt �tadott HTable objektum vez�rli */
class HDispTable : public QFrame
{
	Q_OBJECT

	protected:

		bool ro_mask;
        int datamode;
        int deletedata;
		HTable *data;
		QVBoxLayout *layout;

	public:
		HDispTable(QWidget *parent,HTable *d,int datamodep = FULL_CLEAN,int ddata=DONT_DELETE_DATA); 
		~HDispTable(void);

        HTable *getDataClass(void) { return data;};

	public slots:

		/** Ezt a slot -ot aktivalja az adatr�teg, ha modosultak az adatai. 
		 *	Azaz, ha a gui ezen fuggvenyet meghivjak akkor az frissiti a
	     *	kepernyon levo ertekeket az adatokbol*/
		int updateDisplay(void);

        int dialogPrint(void);
        int dialogXml(void);

		int addStretchToEnd(void);

	/*A gui ezt a signal-t hasz�lja arra, hogy a mezokhoz tartozo HDispDataField
	   tipusu leszarmazottaknak atadja a friss�t�si k�relmet*/
	signals:
		void updateDisplaySignal(void);
        
};

/*T�bb rekordot tartalmaz� lista megjelen�t�s�re alkalmas oszt�ly
  QFrame lesz�rmazott. Egy param�terk�nt �tadott HList objektum vez�rli */
class HDispList : public QFrame
{
	Q_OBJECT

	protected:
        int datamode;
        int deletedata;
		HList  *data;
		HTableBrowser *list;

	public:
		HDispList(QWidget *parent,HList *d,int datamodep = FULL_CLEAN,int ddata=DONT_DELETE_DATA); 
		~HDispList(void);

        HList *getDataClass(void) { return data;};

	/*Ezt a slot -ot aktivalja az adatr�teg, ha modosultak az adatai. 
	  Azaz, ha a gui ezen fuggvenyet meghivjak akkor az frissiti a
	  kepernyon levo ertekeket az adatokbol*/
	public slots:
		int updateDisplay(void);
		int itemActivated(const QString& s);
		int litemChanged(const QString& s);


        int dialogPrint(void);
        int dialogXml(void);
        int toEnd()   { list->cursorToEnd();   return updateDisplay(); }
        int toBegin() { list->cursorToBegin(); return updateDisplay(); }

        int sortByColumn(int col);

	signals:
		void listItemChanged(void);

	protected:
		void keyPressEvent(QKeyEvent *e);

};

/////////////////////////////////////////////////////////////////////////////////
/// data fields /////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////

class HDispDataField : public QFrame
{
	Q_OBJECT

	protected:
		HDataField *data;
		bool ro_mask;
        bool tbool;

		QHBoxLayout *sublayout;
	public:	
		static QHBoxLayout *static_sublayout;

	public:
		HDispDataField(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispDataField(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int updateDisplaySlot(void);
        int timedUpdateSlot(void);

	public slots:
		int enableControlSlot(void) { enableControl(); return 0; }
		int disableControlSlot(void) { disableControl(); return 0; }

    protected:
        void paintEvent(QPaintEvent *e);

    private:
        int  blink;

};

class HDispKey : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel *explain,*key;

	public:
		HDispKey(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispKey(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int updateDisplaySlot(void);

};

class HDispSmallText : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QLineEdit *edtext;
		QLabel    *nedtext;
		QLabel    *tailtext;

	public:
		HDispSmallText(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispSmallText(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int textUpdate(const QString& n);
		int updateDisplaySlot(void);

};

class HDispLargeText : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel			*explain;
		QTextEdit		*edtext;
		QTextEdit		*nedtext;
	public:
		HDispLargeText(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispLargeText(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int textUpdate(void);
		int updateDisplaySlot(void);


};

class HDispCharHash : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QComboBox *edval;
		QLabel    *nedtext;
		QLabel    *tailtext;
	public:
		HDispCharHash(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispCharHash(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int itemSelected(int index);
		int updateDisplaySlot(void);

};

class HDispNumHash : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QComboBox *edval;
		QLabel    *nedtext;
		QLabel    *tailtext;
	public:
		HDispNumHash(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispNumHash(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int itemSelected(int index);
		int updateDisplaySlot(void);

};

class HDispNumber : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		HSpinBox  *edval;
		QLabel    *nedtext;
		QLabel    *tailtext;
	public:
		HDispNumber(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispNumber(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int valueUpdate(int value);
		int updateDisplaySlot(void);

};

class HDispStatic : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QLabel    *nedtext;
	public:
		HDispStatic(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispStatic(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int updateDisplaySlot(void);

};

class HDispCheck : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel *explain;
		QCheckBox *edval;
		QLabel    *nedtext;

	public:
		HDispCheck(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispCheck(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int valueUpdate(void);
		int updateDisplaySlot(void);
};

class HDispFloating : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QLineEdit *edtext;
		QLabel    *nedtext;
		QLabel    *tailtext;

	public:
		HDispFloating(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispFloating(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
		int textUpdate(const QString& n);
		int updateDisplaySlot(void);
};

class HDispDate : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel *explain;
		QDateEdit *edval;
		QCheckBox *unk;
		QLabel	*nedtext;
	
	public:
		HDispDate(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispDate(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

	public slots:
        int valueUnkUpdate(void);
		int valueUpdate(const QDate& d);
		int updateDisplaySlot(void);
};

class HDispTimestamp : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QLabel    *nedtext;

	public:
		HDispTimestamp(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispTimestamp(void);

		virtual void enableControl(void);
		virtual void disableControl(void);


	public slots:
		int updateDisplaySlot(void);
};

class SqlChooseDialog;
class HDispSqlChoose : public HDispDataField
{
	Q_OBJECT

	protected:
		QLabel	  *explain;
		QComboBox *edval;
		QLabel    *nedtext;
		QToolButton *rfbutt;
		QPushButton *pbutt;

		SqlChooseDialog *pupup_dialog;
		
	public:
		HDispSqlChoose(QWidget *parent,HDataField *d,bool _ro_mask=false);
		~HDispSqlChoose(void);

		virtual void enableControl(void);
		virtual void disableControl(void);

        void setToolbarbuttonSignalOn(QString text);
        void setToolbarbuttonSignalOff();

		HSqlChoose *getHSqlChoose(void) { return ((HSqlChoose *)data); };

	public slots:
		int itemSelected(int index);
		int refresh(void);
		int updateDisplaySlot(void);
		int popupSelector(void);
		int itemSelected(const QString& s);

      
};

/*Az alabbi osztaly nem a mezotipusok resze, az HDispSqlChoose-hoz tartozik,
  kiterjesztett modban o belole lesz az a felugro ablak amelyben a rekordok kozott valasztani lehet
  Az HDispSqlChoose- slotjahoz csatlakozik, es ugy adja le a kivalasztott adatot. */
class SqlChooseDialog : public QDialog
{
    Q_OBJECT

	private:
		QString popupped_key;

	public:
		SqlChooseDialog( HDispSqlChoose* p);
		~SqlChooseDialog();

		HTableBrowser* table;
		QPushButton* button;
        bool disabled_recvkey;
        bool key_received;
        QString received_key;

	protected:
        HDispSqlChoose* parent;

		QVBoxLayout* SqlChooseDialogLayout;
		QHBoxLayout* layout1;

        bool have_extra_func;
	
	public slots:
        int nullButtonPressed(void);
		int buttonPressed(void);
		int listviewitemSelected(const QString& s);
        int updateList(void);

        /* Az alabbi toolbarButtonClicked SLOT hivodik meg abban az esetben mikor a pluszban
            hozzaadott toolbargomb lenyomodik. Ez kivaltja a lentebb levo callToolButtonHandler SIGNALT
            ami vegsosoron a kezdetben megadott egyeb helyen levo kezeloSLOThoz csatolodik
            Ez az atlancolat ezert van, hogy a tavolban meghivott kezelo lefutasa utan vegre tudjak
            hivni egy listafrissitest. Ha nem lenne egy sajat kozbeiktatott slot akkor nem tudnam magam reszerol
            is megfogni az esemenyt oly modon, hogy a kezelo lefutasa utan frissithessek, nem elotte, vagy alatta.
        */
	    int toolbarButtonClicked(void);

        int receivedASelectedKey(QString key);

        int popUpMenuActivated(const QString& key);
		
		/*Popapmenu aktivalja ezeket a slotokat! Mivel a popupmenu key nelkul tudja csak hivni a slotokat 
		 * ezert ezek a  sigToExtraFunc signalokat aktivaljak ami a celslottal ossze van kapcsolva*/
		int popup_catch_0(void);
		int popup_catch_1(void);
		int popup_catch_2(void);
		int popup_catch_3(void);
		int popup_catch_4(void);

		int captureNotify(QString tblname);

    signals:
        void callToolButtonHandler(void);
		void itemSelected(const QString& s);	//ez kapcsolodik a szulohoz

		void sigToExtraFunc_0(QString key);
		void sigToExtraFunc_1(QString key);
		void sigToExtraFunc_2(QString key);
		void sigToExtraFunc_3(QString key);
		void sigToExtraFunc_4(QString key);
}; 

/////////////////////////////////////////////////////////////////////////////////////////////


class HShowPrintHtml : public QDialog
{
    Q_OBJECT

private:
	QString html;
    QTextEdit *te;

public:
    HShowPrintHtml(QWidget *parent);
    ~HShowPrintHtml(void);

public:
    void setContent(QString str);
	void setWinTitle(QString t);

public slots:
    void slotPrint(void);
    void slotStart(void);
	void slotSave(void);

};

/////////////////////////////////////////////////////////////////////////////////////////////


class HPleaseWaitWindow : public QWidget
 {
  Q_OBJECT

  private:
	int sizex,sizey;
	int lastx,lasty;
	int seq;
	int refreshTime;
  
	HPleaseWaitWindow(int sizex_=80,int sizey_=80,int refreshTime_=80);
	~HPleaseWaitWindow();

  public slots:
	void progress(void);

  protected:

	QTime t;
	void mouseMoveEvent(QMouseEvent *me);
	void mousePressEvent(QMouseEvent *me);

	//Redefine this if you would line to change my stupid animation...
	void paintEvent(QPaintEvent *pe);

  public:
	  static HPleaseWaitWindow *pww;

	  //CALL THESE:
	  static HPleaseWaitWindow * start(void);
	  static void				 step (void);
	  static void				 end  (void);
 }; 

/////////////////////////////////////////////////////////////////////////////////////////////

class HDecorDialog : public QDialog
{
	Q_OBJECT

	public:
		HDecorDialog(QWidget *parent,QString title,int no_action_closetime);

	public:
		void setTitleFont(QFont f);
		bool anywhere_click_close;
		bool dont_reset_timer;
		
		
		QColor bgcolor;
		int framewidth;
		QColor frcolor;
		int titleheight;
		int closerwidth;
		QColor titlecolor;
		QColor indcolor;
		int crossthick;
		int crossmargin;

	private slots:
		int incr_t(void);

	protected:
		void paintEvent(QPaintEvent *pe);

		void mousePressEvent(QMouseEvent *e);
		void mouseMoveEvent(QMouseEvent *e);
		void keyPressEvent(QKeyEvent *e);

	private:
		QFont  titlefont;
		QString title;
		int no_action_closetime;
		int end_t;
		int t_t;
		int t_time;
};


class HPressButtonSizeSyncronizer;

class HPressButton : public QFrame
{
	Q_OBJECT

	public:
		HPressButton(QWidget *parent,QString text,QString code="");
		~HPressButton(void);

		void setColor(int red,int green,int blue);
		void setEffect(int effectwidth);
		void setMargin(int margin);
		void setTextPointSize(int size);

    private:
		bool enablestat;
		bool hidestat;
		int cmargin; 
		int c3deffect; 

		QFont font;
		bool willmid;
		bool mid;
		bool down;
		QString textstr,idstr;

		int r,rd,g,gd,b,bd;


		void calcSize();
		//static int mx,my;
		HPressButtonSizeSyncronizer* size_sync;
	public:
		
		static HPressButtonSizeSyncronizer* createSizeSyncronizer(void);

		HPressButtonSizeSyncronizer* getSizeSyncronizer(void)    { return size_sync; }
		void setSizeSyncronizer(HPressButtonSizeSyncronizer* ss) { size_sync = ss;   }

	public slots:
		int recalcSize();
		int setHide();
		int setShow();
		int setEnabled(bool enable);


	protected:
		void paintEvent(QPaintEvent *e);

		void keyPressEvent(QKeyEvent *e);
		void keyReleaseEvent(QKeyEvent *e);

		void mousePressEvent(QMouseEvent *e);
		void mouseReleaseEvent(QMouseEvent *e);
		void mouseMoveEvent(QMouseEvent *e);

	signals:
		void clicked(void);
		void clickedCode(QString code);
};

class HPressButtonSizeSyncronizer
{
	private:
		HPressButtonSizeSyncronizer()
		{
			mx = 0;
			my = 0;
		}

	private:
		int mx,my;
	friend class HPressButton;
};

#endif
