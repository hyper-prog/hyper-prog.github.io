/*
  TreeGenerator 
  (OpenGL GLSL Environment generator)
  
  Copyright (C) Peter Deak (hyper80@gmail.com) 
  http://hyperprog.com
  
  Platform: C++ Qt (http://qt.nokia.com)
  
  License GPL
 
  This program is only for test & education pusposely & fun ;-) */
#ifndef H__DB_H
#define H__DB_H

#include <list>
#include <QtCore>

#include <datalib.h>
#include <hfactory.h>

using namespace std;

class TreeParameters;
class PalmTreeParameters;
class GrassParameters;
class BigLeafParameters;
class EnvParameters;

class TreeGenerator;
class Board;

class TextureDatabase
{
private:
        bool readed;
        QMap<QString,int> texture_map;
        QMap<QString,int> texture_status;

        QString path;

public:
        TextureDatabase(void);

        int read_textures(QString dir);
        int fill_htablesfields(HTable *t);

        int getTexidByName(QString name);

        static TextureDatabase *instance;

        Board *board;
};



class ElementParameters
{
public:
        ElementParameters(void);

        QString name;
        int state;	  //0-not generated/have to regenerate  1-show  2-hide
        int subtype;  //0-none 1-tree 2-grass
        HTable *link;

        int display_list;
        long triangles;

        static HFactory *factory;

        virtual HTable * getAndIndependentHTableInstance(void);
        virtual void     initializeLinkHTable(void);
        virtual void	 sync(void); //copy htable values to element values
        virtual void	 drawMe(TreeGenerator *gen);
};

class Db
{
public:
        Db(void);
        ~Db(void);


public:
        list<ElementParameters *> innerdb;
};

int copy_htable_to_envparameters(HTable *ht,EnvParameters *ep);
int copy_htable_to_treeparameters(HTable *ht,TreeParameters *tp);
int copy_htable_to_grassparameters(HTable *ht,GrassParameters *gp);
int copy_htable_to_bigleafparameters(HTable *ht,BigLeafParameters *bp);
int copy_htable_to_palmtreeparameters(HTable *ht,PalmTreeParameters *tp);




#endif
