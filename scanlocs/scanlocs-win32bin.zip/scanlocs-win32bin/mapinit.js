//  Copyright (C) Peter Deak ( Webpage/Contact: http://hyperprog.com )
function chdmmapinit()
{
	var image = new google.maps.MarkerImage("flag.png",
			new google.maps.Size(40, 40),
			new google.maps.Point(0,0),
			new google.maps.Point(0, 1));
	map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);

	for (var i = 0; i < mymarkers.length; i++)
	{
		var image = image;
		var myPos  = new google.maps.LatLng(mymarkers[i][1], mymarkers[i][2]);
		var myMark = new google.maps.Marker({position: myPos ,
								map: map ,
								icon: image,
								title: mymarkers[i][0] ,
								zIndex: mymarkers[i][3] });
		var info = new ShowInfos(mymarkers[i][4] , myMark);
		google.maps.event.addListener(myMark , "click" , info.invoke);
	}
}

function ShowInfos(text,marker)
{
	this.text = text;
	this.marker = marker;
	var me = this;
	this.invoke = function()
			{
				if(lastiw != null) { lastiw.close(); }
				var infowindow = new google.maps.InfoWindow({ content: me.text });
				infowindow.open(map,me.marker);
				lastiw = infowindow;
			}
}


var myOptions = {
	zoom: zoomfactor,
	center: new google.maps.LatLng(center_lat,center_long),

	mapTypeId: google.maps.MapTypeId.TERRAIN
		
 };


var map;

var lastiw = null;
		
chdmmapinit();
