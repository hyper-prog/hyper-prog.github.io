/* 
    gSAFE First tutorial 
	(general Sql dAtabase FrontEnd)

   (C) 2010 Peter Deak  (hyper80@gmail.com)
   
	License: GPL

*/
#include <QtCore>
#include <QtSql>
#include <QtGui>

#include "gsafetutorial.h"
#include "dconsole.h"
#include "datalib.h"
#include "hfactory.h"
#include "guilib.h"
#include "dialib.h"

#define DBFILE "c:\\temp\\testdb.sqllite"


//Describe the metadata in xml:
//QString templatedata=

MainDialog::MainDialog(QWidget *parent,bool createemptydb)
: QDialog(parent)
{
	HSqlHandler sqlhandler;
	
	HFactory factory;
    
    if(factory.readFromFile("metadata.xml"))
    {
        error("Can't read the meta-data definition xml file! (metadata.xml)");
        exit(1);
    };

	if(!connect(&factory,SIGNAL(errorSignal(QString)),this,SLOT(showError(QString))))
		error("Can't connect error handler!");
	
	//generate the metatable for excercises	(HTable)
		ptable = factory.genHTable("excercises");
	//generate the meta-list for excercises (HList)
		plist  = factory.genHList("excercises");
	
	HTable *typt = factory.genHTable("typetable");


	//create an empty database if needed
	if(createemptydb) 
	{
		sdebug("\n");
	
		sqlhandler.submit0ResultQuery(typt->sqlCreateString(),"Error creating database...");
		if(sqlhandler.errorStatus())
		{
			QMessageBox::information(this,"Error creating empty database...","Error (1):-(");
			return;
		}

		sqlhandler.submit0ResultQuery("INSERT INTO types VALUES(\'1\',\'Homework\');","Error inserting data");
		sqlhandler.submit0ResultQuery("INSERT INTO types VALUES(\'2\',\'Workplace\');","Error inserting data");
		sqlhandler.submit0ResultQuery("INSERT INTO types VALUES(\'3\',\'Friend\');","Error inserting data");
		
		if(sqlhandler.errorStatus())
		{
			QMessageBox::information(this,"Error creating empty database...","Error (2) :-(");
			return;
		}
		sqlhandler.submit0ResultQuery(ptable->sqlCreateString(),"Error creating empty database...");
	
		if(sqlhandler.errorStatus())
			QMessageBox::information(this,"Error creating empty database...","Error (3) :-(");
		else
			QMessageBox::information(this,"Creating empty database...","Success :-)");
	}
	//end of creating new database
	
	//build the gui with the hdialog lib
	makeGui(this,"My tasks (gSAFE tutorial)",plist,NULL,
				"EscC|Vert|StrToE|DeleteData|DestructiveClose|NonModal|InScroll","Hit doubleclick to edit!","insert","refresh list",NULL,640,480);

	connect(plist,SIGNAL(actionOnRecord(QString)),this,SLOT(editRecord(QString)));
	connect(toolbutton2,SIGNAL(clicked()),plist,SLOT(readList()));
	connect(toolbutton1,SIGNAL(clicked()),this,SLOT(insertRecord()));
		
	sdebug("Read list from the database...");

	plist->readList();

	sdebug("...finished.");
	sdebug(ptable->sqlCreateString());

}
int MainDialog::insertRecord(void)
{
	ptable->returnToDefault();
	if(HDialog::run(this,"Insert a task",ptable,NULL,"Ok|OkIsAccept|EscC|StrToE|InScroll","Task","","",NULL,400,400))
	{
		ptable->insertRecord();
		HRefreshAgent::notify("excerc");
	}
	return 0;
}

int MainDialog::editRecord(QString id)
{
	ptable->updateWithKey(id);
	if(HDialog::run(this,"Edit a task",ptable,NULL,"Ok|OkIsAccept|EscC|StrToE|InScroll","Task","","",NULL,400,400))
	{
		ptable->saveRecord();
		HRefreshAgent::notify("excerc");
	}
	return 0;
}

int MainDialog::showError(QString err)
{
	QMessageBox::warning(this,"Error received:",err);
	return 0;
}

MainDialog::~MainDialog()
{
}

int main(int argi,char **argc)
{
	bool newdb;

	QApplication app(argi,argc);
	
	//Tell the gsafe the type of sql database:
	HSqlInterface::setSqlMode("QtSqlite_Win");
		//HSqlInterface::setSqlMode("PostgreSQL");

	dconsole(); //The debug console (needless to run)

	QFile dbasefile(DBFILE);
	
	if(dbasefile.exists())		newdb = false;
	else				newdb = true;

	QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
	db.setDatabaseName(DBFILE);
    
	if(!db.open())
	{
			QMessageBox::information(NULL,"gSAFE-Qt4","Cannot establish the database connection...");
			return -1;
	}
	sdebug("Database succesfull opened...");

	//initialize the gsafe refresh agent. 
	//Notify the excercises list to refresh when insert or modify data in the table
	new HRefreshAgent();

	MainDialog *maindialog = new MainDialog(0,newdb);
	maindialog->show();

	app.exec();
	db.close();
	return 0;
}