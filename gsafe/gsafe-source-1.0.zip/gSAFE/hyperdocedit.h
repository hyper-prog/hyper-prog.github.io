/* 
    gSAFE - LIB 
    general Sql dAtabase FrontEnd

   (C) 2007 Peter Deak  (hyper80@gmail.com)

	hyperdocedit.h + MOC
*/

#ifndef GSAFE__HYPERDOCEDIT_HEADER_X_ 
#define GSAFE__HYPERDOCEDIT_HEADER_X_ 


#include <QtCore>
#include <QtGui>

#include <hyperdoceditbase.h>

#define DONT_DELETE_HYPDOC	0
#define DELETE_HYPDOC		1

#define MODE_HTML 0
#define MODE_TEXT 1

class QWidget;
class HyperDoc;
class QListBoxItem;
class QLineEdit;
class HTable;
class HFloatTables;

/** A HyperDocEdit egy HyperDoc sablon alap� dokumentumgener�l�oszt�ly sablonjait szerkeszt� oszt�ly. 
 *  A sablonok itt f�jlrendszerbeli f�jlokk�nt nyithat�k meg/menthet�k el. */
class HyperDocEdit : public	QWidget , public Ui::HyperDocEditBase
{
	Q_OBJECT

	protected:
		int dhdoc_del_mode;
		QString editedname,currentField;
		int selectedtext;
		HyperDoc *hypdoc;

		HTable       *selectedHT;
		HFloatTables *selectedHF;

	public:
		HyperDocEdit(QWidget *parent,int pdhdoc_del_mode=DONT_DELETE_HYPDOC);
		~HyperDocEdit(void);

	public slots:
		/** Be�ll�tja a HyperDoc objektumot. (Hozza a kapcsolatokat a metaadatokkal, esetlegesen a sablont is) */
		int setHyperDoc(HyperDoc *hd);
		int plainChanged(void);
		int autoChanged(void);

		virtual int openReq(void);
		virtual int saveReq(void);
		virtual int saveasReq(void);
		virtual int closeReq(void);

	protected slots:
	
		//feltolti az elso kombobox alapjan a masodikat
		int refreshConnections(void);
		//megnezi a masodik comboboxban mi az aktualis es beallitja a selectedXX valtozokat
		int refreshConnections2(void);
		//selectedXX valtozok alapjan feltolti a harmadik comboboxot
		int refreshConnections3(void);
		//fieldlistaban kivalasztott elemhez kiirja a magyarazoszoveget, ill beallitja a currentField valtozot
		int refreshConnections4(void);

		int comboTLSlot(int i);
		int comboListTLSlot(int i);
		int comboFieldsSlot(int i);
		int comboResSlot(int i);

		int text_changed(void);
		int html_changed(void);

		int toolInsertData(void);
		int toolInsertRes(void);
		int toolInsertDataRes(int mode);
		int toolInsertTable(void);
		int toolInsertCond(void);
		int toolInsertIter(void);


		int etUndo(void);
		int etRedo(void);
		
		int etCopy(void);
		int etCut(void);
		int etPaste(void);
		
		int etStrong(void);
		int etItaly(void);
		int etUnder(void);

		int etLeft(void);
		int	etCenter(void);
		int	etRight(void);
		int	etJust(void);

		int textStyle (int i);
		int textFamily(const QString &str);
		int textSize(const QString &str);


		int checkTextChanged(int state);
		int checkHtmlChanged(int state);
	
	protected:
		QString getSelected(void);
		void closeEvent(QCloseEvent *e);

	private:
		bool nowchaged;

	signals:
		/** A szerkeszt� bez�r�si k�relme eset�n k�ld egy ilyen szign�lt. 
		 *	M�s widgetekbe val� be�gyaz�sakor hasznos. */
		void closeRequest(void);
		/** Az ablakc�m megv�ltoztat�sakor k�ld egy ilyen szign�lt.
		 *	M�s widgetekbe val� be�gyaz�sakor hasznos. */
		void changeCaption(const QString& cap);

};

/** Ugyanaz mint a HyperDocEdit, csak ez az oszt�ly a sablonokat SQL
 *	adatb�zisban t�rolja/menti/nyitja meg.	*/
class HyperDocEditSql : public HyperDocEdit
{
	Q_OBJECT

	public:
		/** HyperDocEdit objektum l�trehoz�sa
		 *	@param QWidget sz�l�. (grafikus alrendszer sz�m�ra)
		 *	@param tablename Sablonokat tratalmaz� t�blan�v
		 *	@param keyfname Sablonokat tartalmaz� t�bla PRIMARY KEY mez�je (�lt. gener�ltatott)
		 *	@param expfname	Sablonnevet tartalmaz� mez�. UNIQUE
		 *	@param contentfname Mag�t a sablon tartalmaz� mez� neve	
		 *	@param pdhdoc_del_mode Last HyperDocEdit		*/
		HyperDocEditSql(QWidget *parent,QString tablename,
										QString keyfname,
										QString expfname,
										QString contentfname,
										int pdhdoc_del_mode=DONT_DELETE_HYPDOC);

		~HyperDocEditSql(void);

	public slots:
		/** Megnyitja a sablont user interakcio nelkul. 
		 *	(mode=0 key/kucs alapjan ; mode=1 name/nev alapjan) */
		virtual int shadowOpen(QString name,int mode=0);

		virtual int openReq(void);
		virtual int saveReq(void);
		virtual int saveasReq(void);
		virtual int closeReq(void);

	protected:
		QString p_table,p_key,p_exp,p_cont;

	private:
};

#endif