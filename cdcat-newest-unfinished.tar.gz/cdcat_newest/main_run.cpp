/****************************************************************************
                          Hyper's CD Catalog 
   	               A multiplatform catalog program
  
 Author    : Peter Deak (hyper80@gmail.com)
 License   : GPL
 Copyright : (C) 2006 Peter Deak

  Type : Console / Gui

  Main File - Entry point (main_run.cpp)
****************************************************************************/

#include <QtCore>

#include "base.h"
#include "fcon.h"
#include "dbase.h"
#include "main_run.h"

#include <stdio.h>
#include <string.h>

#ifdef APP_GUI_MODE
 #include <QtGui>

 #include "guimain.h"
 #include "guicore.h"
 #include "icons.h"
#endif

#ifdef APP_CONSOLE_MODE
 #include <iostream>
  using namespace std;
#endif

#include "config.h"

int main( int argi, char **argc ) 
{
	int rc = 0;

//Console mode only...
#ifdef APP_CONSOLE_MODE
#ifndef APP_MIXED_MODE
    ConsoleApp app( argi, argc );
	rc = app.exec();
	return rc;
#endif
#endif

//Gui mode only...
#ifdef APP_GUI_MODE
#ifndef APP_MIXED_MODE
	GuiApp app(argi,argc);

	init_icon_base();
	AppMainWindow *hw = new AppMainWindow();

	hw->show();
	rc = app.exec();
	delete hw;
	return rc;
#endif
#endif
}

#ifdef APP_GUI_MODE
GuiApp * GuiApp::guiAppPo = NULL;

GuiApp::GuiApp(int &argc,char ** argv)
: QApplication(argc,argv)
{
	guiAppPo = this;

	ccfg = new CConfig();
	ccfg->readConfig();
	
	//cdb  = new DataBase(ccfg);
	cdb = NULL;
	guicore = new GuiCore();

//only test DELME
	//cdb->setDBName("Szopat�DB");
	//cdb->addMedia("D:\\CDCAT","paff",1,CD,"�rd�g");
	//cdb->addMedia("D:\\docs","paff",1,CD,"�rd�g");
	//cdb->addMedia("/boot","paff",1,CD,"�rd�g");
//end

}

GuiApp::~GuiApp(void)
{
	delete guicore;
	delete cdb;
	delete ccfg;
	guiAppPo = NULL;

}
#endif

#ifdef APP_CONSOLE_MODE
ConsoleApp::ConsoleApp(int &argumenti,char **argumentc)
: QCoreApplication(argumenti,argumentc)
{
	ConsoleActionHandler *ch = new ConsoleActionHandler();

	if(argc() == 2 && !strcmp(argv()[1],"-h"))
	{
	    printhelp();
	    quit();
	    return;
	}
	if(argc() == 2 && !strcmp(argv()[1],"-v"))
	{
	    cout << "CdCat Multi Catalog Program. Version: " << VERSION << endl;
	    quit();
	    return;
	}


	CConfig *conf = new CConfig();
	if(conf->readConfig() != 0)
	{
		cerr <<  "Can't find config file, regenerate it..." << endl;
		conf->writeConfig(); // If the config file dones't exists create it!
	}


	//---------------------------------------//
	if(argc() >= 3 && !strcmp(argv()[2],"create"))
	{
	    char name[256],str[256];
	    
	    strcpy(name,"Catalog");
	    if(argc() == 4 && sscanf(argv()[3],"-n%s",str) == 1)
	        strcpy(name,str);
		     
	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	
	    db->setDBName(name);
	    db->setDBOwner("CdCat");
	    db->setComment("");

	    db->saveAsDB((argv())[1]);
	
	    delete db;
		delete conf;
	    delete ch;
	
	    cerr << "Created a new database named \"" << name << "\" in file " << argv()[1] << endl;
	    quit();
	    return;
	}
	//---------------------------------------//
	if(argc() == 3 && !strcmp(argv()[2],"mlist"))
	{
		int i;
		QList<QPointer<DBNode> > *result = NULL;
		DBNode *n;

	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	
	    db->openDB  ((argv())[1]);
		n = db->getRootNode()->child;
		for(; n != NULL ; n = n->next)
			cout << "Media " << ": "<< (qobject_cast<DBMedia *>(n->DBdata))->number 
				 <<"/"<< n->getNameOf().toLocal8Bit().constData() <<endl;

		delete db;
		delete conf;
	    delete ch;
		cerr << "Scanning of the database " << argv()[1]  << " finished." << endl;
	    quit();
	    return;
	}
	//---------------------------------------//
	if(argc() == 4 && !strcmp(argv()[2],"rebuild"))
	{

	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	
	    db->openDB  ((argv())[1]);
	    db->saveAsDB((argv())[3]);
	
	    delete db;
		delete conf;
	    delete ch;
	
	    cerr << "Rebuilded database " << argv()[1]  << " to file " << argv()[3] << endl;
	    quit();
	    return;
	}
	//---------------------------------------//
	if(argc() >= 4 && !strcmp(argv()[2],"exporthtml"))
	{
	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	

	    db->openDB  ((argv())[1]);
		if(argc() == 5 && !strcmp(argv()[4],"-medianameonly"))
			db->exportHtml(QString((argv())[3]),true);
		else
			db->exportHtml(QString((argv())[3]));

	    delete db;
		delete conf;
	    delete ch;
	
	    cerr << "Exported database " << argv()[1]  << " to .html file " << argv()[3] << endl;
	    quit();
	    return;
	}
	//---------------------------------------//
	if(argc() == 4 && !strcmp(argv()[2],"find"))
	{
		int i;
		QList<QPointer<DBNode> > *result = NULL;

	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	
	    db->openDB  ((argv())[1]);

		result = db->find(argv()[3],"","");

		if(result == NULL)
		{
			cerr << "Scan failed"<<endl;
			quit();
			return;
		}

		for(i=0;i<result->size();++i)
			cout << "Result "<<i+1<<": "<< (result->at(i)->getFullPath()).toLocal8Bit().constData()<<endl;

		delete result;
		cerr << i << " item found."<<endl;
		delete db;
		delete conf;
	    delete ch;
		cerr << "Scanning of the database " << argv()[1]  << " finished." << endl;
	    quit();
	    return;
	}
	//---------------------------------------//
	if(argc() >= 6 && !strcmp(argv()[2],"add"))
	{
	    char mname[256],dir[256],types[64];
	    int mnum,type;
	
	    strcpy(dir,".");    	    

	    if(sscanf(argv()[3],"-n%d",&mnum) != 1 ||
	       sscanf(argv()[4],"-a%s",mname) != 1 ||
	       sscanf(argv()[5],"-t%s",types) != 1   )
		{
		    cerr << "Wrong parameters. Use cdcat -h\n"<<endl;
		    quit();
		    return;
		}
		
	    if     (!strcmp(types,"CD"     )) type = CD;	
	    else if(!strcmp(types,"DVD"    )) type = DVD;	
	    else if(!strcmp(types,"HDD"    )) type = HARDDISC;		    
	    else if(!strcmp(types,"FLOPPY" )) type = FLOPPY;		    
	    else if(!strcmp(types,"NET"    )) type = NETPLACE;		    
	    else if(!strcmp(types,"FLASH"  )) type = FLASHDRV;		    
	    else if(!strcmp(types,"OTHER"  )) type = OTHERD;		    
	    else if(!strcmp(types,"AUDIOCD")) type = AUDIOCD;		    
	    else 
	    {
	        cerr << "Wrong media types. Possible is CD,DVD,HDD,FLOPPY,NET,FLASH,OTHER,AUDIOCD\n"<<endl;
		    quit();
		    return;
		
	    }		    

	    if(argc() == 7)
	        strcpy(dir,argv()[6]);

	    DataBase *db = new DataBase(conf);
	    db->setActionHandler(ch);
	
	
	    db->openDB  ((argv())[1]);
	    int i;
	    if(( i = db->addMedia(dir,mname,mnum,type)) != 0)    
	     {
	         quit();
	         return;
	     }
	    db->saveAsDB((argv())[1]);
	
	    delete db;
		delete conf;
	    delete ch;
	    cerr << "Added \"" << dir << "\" to database \"" << argv()[1] << "\" as new media named \""<< mname <<"\" ("<<mnum<<")"<< endl;
		quit();
	    return;
	}
	//---------------------------------------//	

	cerr << " Missing or incorrect argument(s)!" <<endl;
	delete conf;
	printhelp();
	quit();
	return;
}

void ConsoleApp::printhelp(void)
{
	
	cout << "CdCat Multi Catalog Program. Version: " << VERSION << endl;
	cout << "Help:" <<endl;	    
	cout << "  cdcat -h                                                            \n     Print this help.\n" <<endl;	    
	cout << "  cdcat -v                                                            \n     Print the version of CdCat\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> create [-n\"NAME\"]                            \n     Create an empty database\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> add -nNUMBER -a\"NAME\" -tTYPE [DIRECTORY]     \n     Add a new media to the database\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> mlist                                          \n     List the media names and numbers\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> exporthtml <HTMLFILE> [-medianameonly]         \n     Export the catalog to a specified html file\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> rebuild <TARGET_FILE>                          \n     Semantyc copy of the database file (Useful to convert old files)\n" <<endl;	    
	cout << "  cdcat <CATALOG_FILE> find <\"STRING\">                              \n     Search in the database with regex\n" <<endl;	    
	cout << "  " <<endl;	    
}

int ConsoleActionHandler::errorOccured(int code,QString msg,QString a1,QString a2,QString a3)
{
    int i=0;
    cout << "Error: ("<<code<< ") "<< msg.toLocal8Bit().constData() << endl;
    
    if(!a1.isEmpty())
	cerr << " "<< i++ << ")" << " " << a1.toLocal8Bit().constData() << endl;
    if(!a2.isEmpty())
	cerr << " "<< i++ << ")" << " " << a2.toLocal8Bit().constData() << endl;
    if(!a3.isEmpty())
	cerr << " "<< i++ << ")" << " " << a3.toLocal8Bit().constData() << endl;
    cin >> i;
    
    return i;
}

QString ConsoleActionHandler::textQuestion(QString msg)
{
    char in[256];
    
    cout << msg.toLocal8Bit().constData() << endl;
    cin >> in;
    
    return QString::fromLocal8Bit(in);
	
	return "";
}

int ConsoleActionHandler::chooseQuestion(QString msg,QString a1,QString a2,QString a3)
{

    int i=0;
    cout << msg.toLocal8Bit().constData() << endl;
    
    if(!a1.isEmpty())
	cout << " "<< i++ << ")" << " " << a1.toLocal8Bit().constData() << endl;
    if(!a2.isEmpty())
	cout << " "<< i++ << ")" << " " << a2.toLocal8Bit().constData() << endl;
    if(!a3.isEmpty())
	cout << " "<< i++ << ")" << " " << a3.toLocal8Bit().constData() << endl;
    cin >> i;
    
    return i;

	return 0;
}

void ConsoleActionHandler::warningMessage(QString msg)
{
    cerr << "Warning: " << msg.toLocal8Bit().constData() << endl;
}
#endif //console mode

//end code.
